-- ============================================================
-- REAPER SQUAD — SUPABASE MIGRATION v4 (FIXED)
-- FIXES:
--   • daily_scores.exercises: INTEGER → JSONB (was breaking array saves)
--   • daily_scores: added exercises_count, fixed exercises column type
--   • reaper_users: added phys_streak, login_pts, last_login, suspended
--   • user_blobs: confirmed present with correct JSONB blob_value
--   • RLS: all policies use auth.uid() guard where possible; anon policies
--     kept minimal since app uses anon key (no server-side auth)
-- Run in Supabase SQL Editor (safe to re-run — all IF NOT EXISTS / IF EXISTS)
-- ============================================================

-- ============================================================
-- 1. reaper_users
-- ============================================================
CREATE TABLE IF NOT EXISTS reaper_users (
  username       TEXT PRIMARY KEY,
  name           TEXT NOT NULL DEFAULT '',
  squad_code     TEXT NOT NULL DEFAULT 'SQXXNI',
  joined_at      BIGINT,
  created_at     TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE reaper_users
  ADD COLUMN IF NOT EXISTS total_xp      INTEGER   DEFAULT 0,
  ADD COLUMN IF NOT EXISTS streak        INTEGER   DEFAULT 0,
  ADD COLUMN IF NOT EXISTS theme         TEXT      DEFAULT 'dark',
  ADD COLUMN IF NOT EXISTS gami_av       INTEGER   DEFAULT 0,
  ADD COLUMN IF NOT EXISTS sel_physique  TEXT      DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS phys_streak   TEXT      DEFAULT NULL,   -- FIX: was missing
  ADD COLUMN IF NOT EXISTS login_pts     INTEGER   DEFAULT 20,     -- FIX: was missing
  ADD COLUMN IF NOT EXISTS last_login    TEXT      DEFAULT NULL,   -- FIX: was missing
  ADD COLUMN IF NOT EXISTS suspended     BOOLEAN   DEFAULT FALSE,  -- FIX: was missing
  ADD COLUMN IF NOT EXISTS profile_data  JSONB     DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS settings_data JSONB     DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS is_owner      BOOLEAN   DEFAULT FALSE;

-- ============================================================
-- 2. daily_scores
-- ============================================================
CREATE TABLE IF NOT EXISTS daily_scores (
  username   TEXT NOT NULL,
  date       TEXT NOT NULL,
  name       TEXT    DEFAULT '',
  squad_code TEXT    DEFAULT 'SQXXNI',
  pts        INTEGER DEFAULT 0,
  PRIMARY KEY (username, date)
);

-- FIX: exercises must be JSONB (array of objects), not INTEGER
-- Safe migration: drop old INTEGER column if it exists, add JSONB
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'daily_scores'
      AND column_name = 'exercises'
      AND data_type = 'integer'
  ) THEN
    ALTER TABLE daily_scores DROP COLUMN exercises;
  END IF;
END $$;

ALTER TABLE daily_scores
  ADD COLUMN IF NOT EXISTS exercises       JSONB     DEFAULT '[]',   -- FIX: JSONB array
  ADD COLUMN IF NOT EXISTS exercises_count INTEGER   DEFAULT 0,      -- FIX: was missing
  ADD COLUMN IF NOT EXISTS total_sets      INTEGER   DEFAULT 0,
  ADD COLUMN IF NOT EXISTS steps           INTEGER   DEFAULT 0,
  ADD COLUMN IF NOT EXISTS updated_at      TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS habits          JSONB     DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS xp_awarded      JSONB     DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS plan_ex         JSONB     DEFAULT '{}';

-- ============================================================
-- 3. squad_chat
-- ============================================================
CREATE TABLE IF NOT EXISTS squad_chat (
  id         UUID    DEFAULT gen_random_uuid() PRIMARY KEY,
  username   TEXT    NOT NULL,
  name       TEXT    NOT NULL DEFAULT '',
  squad_code TEXT    NOT NULL DEFAULT 'SQXXNI',
  text       TEXT    NOT NULL DEFAULT '',
  ts         BIGINT  NOT NULL DEFAULT extract(epoch from now()) * 1000,
  reply_to   JSONB   DEFAULT NULL
);

-- ============================================================
-- 4. kicked_users
-- ============================================================
CREATE TABLE IF NOT EXISTS kicked_users (
  username   TEXT PRIMARY KEY,
  squad_code TEXT    NOT NULL DEFAULT 'SQXXNI',
  kicked_at  BIGINT,
  by_owner   TEXT,
  disabled   BOOLEAN DEFAULT FALSE
);

-- ============================================================
-- 5. user_blobs  (fixes 404 — table must exist with correct schema)
-- ============================================================
CREATE TABLE IF NOT EXISTS user_blobs (
  username    TEXT NOT NULL,
  blob_key    TEXT NOT NULL,
  blob_value  JSONB DEFAULT '{}',
  updated_at  TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (username, blob_key)
);

-- ============================================================
-- 6. Indexes
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_daily_scores_date        ON daily_scores(date);
CREATE INDEX IF NOT EXISTS idx_daily_scores_squad       ON daily_scores(squad_code);
CREATE INDEX IF NOT EXISTS idx_daily_scores_username    ON daily_scores(username);
CREATE INDEX IF NOT EXISTS idx_squad_chat_squad         ON squad_chat(squad_code);
CREATE INDEX IF NOT EXISTS idx_squad_chat_ts            ON squad_chat(ts);
CREATE INDEX IF NOT EXISTS idx_reaper_users_squad       ON reaper_users(squad_code);
CREATE INDEX IF NOT EXISTS idx_kicked_users_squad       ON kicked_users(squad_code);
CREATE INDEX IF NOT EXISTS idx_user_blobs_username      ON user_blobs(username);

-- ============================================================
-- 7. RLS — enable on all tables
-- ============================================================
ALTER TABLE reaper_users  ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_scores  ENABLE ROW LEVEL SECURITY;
ALTER TABLE squad_chat    ENABLE ROW LEVEL SECURITY;
ALTER TABLE kicked_users  ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_blobs    ENABLE ROW LEVEL SECURITY;

-- Drop all old policies cleanly
DO $$ DECLARE r RECORD; BEGIN
  FOR r IN SELECT policyname, tablename FROM pg_policies
    WHERE tablename IN ('reaper_users','daily_scores','squad_chat','kicked_users','user_blobs')
  LOOP
    EXECUTE 'DROP POLICY IF EXISTS ' || quote_ident(r.policyname) || ' ON ' || quote_ident(r.tablename);
  END LOOP;
END $$;

-- reaper_users policies
CREATE POLICY "users_select_all" ON reaper_users
  FOR SELECT TO anon USING (true);

CREATE POLICY "users_insert_own" ON reaper_users
  FOR INSERT TO anon WITH CHECK (length(username) >= 1);

CREATE POLICY "users_update_own" ON reaper_users
  FOR UPDATE TO anon USING (true)
  WITH CHECK (is_owner = FALSE);   -- anon cannot set is_owner=true

-- daily_scores policies
CREATE POLICY "scores_select_all" ON daily_scores
  FOR SELECT TO anon USING (true);

CREATE POLICY "scores_upsert" ON daily_scores
  FOR INSERT TO anon WITH CHECK (
    pts >= 0 AND pts <= 10 AND
    date ~ '^\d{4}-\d{2}-\d{2}$'
  );

CREATE POLICY "scores_update" ON daily_scores
  FOR UPDATE TO anon USING (true)
  WITH CHECK (pts >= 0 AND pts <= 10);

-- squad_chat policies
CREATE POLICY "chat_select_all" ON squad_chat
  FOR SELECT TO anon USING (true);

CREATE POLICY "chat_insert" ON squad_chat
  FOR INSERT TO anon WITH CHECK (
    length(text) > 0 AND length(text) <= 500
  );

CREATE POLICY "chat_delete_own" ON squad_chat
  FOR DELETE TO anon USING (true);

-- kicked_users policies
CREATE POLICY "kicked_select" ON kicked_users FOR SELECT TO anon USING (true);
CREATE POLICY "kicked_insert" ON kicked_users FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "kicked_update" ON kicked_users FOR UPDATE TO anon USING (true);
CREATE POLICY "kicked_delete" ON kicked_users FOR DELETE TO anon USING (true);

-- FIX: user_blobs policies — were missing "return=minimal" Prefer header causing 404
--      Ensure all four operations are explicitly allowed for anon
CREATE POLICY "blobs_select" ON user_blobs
  FOR SELECT TO anon USING (true);

CREATE POLICY "blobs_insert" ON user_blobs
  FOR INSERT TO anon WITH CHECK (length(username) >= 1);

CREATE POLICY "blobs_update" ON user_blobs
  FOR UPDATE TO anon USING (true);

CREATE POLICY "blobs_delete" ON user_blobs
  FOR DELETE TO anon USING (true);

-- ============================================================
-- OWNER: run once manually
-- UPDATE reaper_users SET is_owner = TRUE WHERE username = 'your_owner_username';
-- ============================================================

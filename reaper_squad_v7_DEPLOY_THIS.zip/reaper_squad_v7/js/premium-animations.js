/* ═══════════════════════════════════════════════════════════════
   REAPER SQUAD — PREMIUM ANIMATIONS
   Exact match to reference screenshot quality
═══════════════════════════════════════════════════════════════ */
(function() {
  'use strict';

  /* ── FIX SCORE RING SVG VIEWBOX & STROKE ──
     Reference shows large ring (~150px), thick stroke
     viewBox "0 0 96 96" with r=44 → circumference = 2π×44 = 276.46
     stroke-width should be visually thick = use 9 in 96px viewBox
  ── */
  function fixRingSVG() {
    var ring = document.querySelector('.score-ring');
    if (!ring) return;
    // The SVG is 96×96 with r=44, let's keep that but fix visual weight
    var ringFill = document.getElementById('ringFill');
    var ringBg = ring.querySelector('.ring-bg');
    if (ringBg) {
      ringBg.setAttribute('stroke-width', '9');
      ringBg.setAttribute('stroke', 'rgba(255,255,255,0.06)');
    }
    if (ringFill) {
      ringFill.setAttribute('stroke-width', '9');
      ringFill.setAttribute('stroke', '#7c3aff');
      ringFill.setAttribute('stroke-dasharray', '276');
      ringFill.setAttribute('stroke-dashoffset', '276');
    }
    // Make the SVG larger via CSS width/height
    ring.style.width = '148px';
    ring.style.height = '148px';
    var wrap = ring.closest('.ring-wrap');
    if (wrap) {
      wrap.style.width = '148px';
      wrap.style.height = '148px';
    }
  }

  /* ── SCORE SECTION LAYOUT FIX ──
     Reference: ring takes ~44% width, stats grid ~56%
  ── */
  function fixScoreLayout() {
    var sec = document.querySelector('.score-sec');
    if (!sec) return;
    sec.style.cssText += ';display:flex!important;align-items:center!important;gap:14px!important;';
    var wrap = sec.querySelector('.ring-wrap');
    if (wrap) wrap.style.flexShrink = '0';
    var info = sec.querySelector('.score-info');
    if (info) info.style.flex = '1';
  }

  /* ── SCORE RING TEXT — fix position ── */
  function fixRingNum() {
    var num = document.getElementById('ringNum');
    if (!num) return;
    num.style.cssText = 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:2rem;font-weight:900;color:#fff;font-family:Rajdhani,sans-serif;line-height:1;text-align:center;z-index:3;-webkit-text-fill-color:#fff;';
    // Add score label above number
    var wrap = num.closest('.ring-wrap');
    if (wrap && !wrap.querySelector('.ring-label')) {
      var lbl = document.createElement('div');
      lbl.className = 'ring-label';
      lbl.style.cssText = 'position:absolute;top:30%;left:50%;transform:translateX(-50%);font-size:0.6rem;color:rgba(255,255,255,0.45);font-weight:600;white-space:nowrap;z-index:3;';
      lbl.textContent = "Today's Score";
      wrap.appendChild(lbl);
    }
  }

  /* ── RIPPLE on tappable elements ── */
  function addRipple(e) {
    var el = e.currentTarget;
    var rect = el.getBoundingClientRect();
    var ripple = document.createElement('span');
    ripple.className = 'ripple';
    var size = Math.max(rect.width, rect.height);
    ripple.style.cssText = 'width:'+size+'px;height:'+size+'px;left:'+(e.clientX-rect.left-size/2)+'px;top:'+(e.clientY-rect.top-size/2)+'px';
    el.appendChild(ripple);
    setTimeout(function(){ if (ripple.parentNode) ripple.remove(); }, 600);
  }
  function attachRipples() {
    var sel = '.bnav, .ai-cta-btn, .modal-submit, .auth-btn, .badge-item:not(.locked), .av-item, .gami-tab, .train-section-wrap';
    document.querySelectorAll(sel).forEach(function(el) {
      if (el._rip) return;
      el._rip = true;
      el.style.overflow = 'hidden';
      el.style.position = el.style.position || 'relative';
      el.addEventListener('click', addRipple, {passive:true});
    });
  }

  /* ── HABIT CARD SPARKS on check ── */
  function spawnSparks(card) {
    if (!card) return;
    var rect = card.getBoundingClientRect();
    var cx = rect.left + rect.width * 0.85; // near checkbox
    var cy = rect.top + rect.height / 2;
    var colors = ['#7c3aff','#4ade80','#a78bfa','#22d3ee'];
    for (var i = 0; i < 6; i++) {
      (function(idx){
        setTimeout(function(){
          var sp = document.createElement('div');
          var ang = (idx / 6) * Math.PI * 2 + Math.random() * 0.5;
          var dist = 18 + Math.random() * 18;
          var px = Math.cos(ang) * dist;
          var py = Math.sin(ang) * dist;
          sp.style.cssText = [
            'position:fixed','pointer-events:none','z-index:9998',
            'width:4px','height:4px','border-radius:50%',
            'background:'+colors[idx%colors.length],
            'box-shadow:0 0 5px '+colors[idx%colors.length],
            'left:'+cx+'px','top:'+cy+'px',
            'transition:transform 0.5s ease-out, opacity 0.5s ease-out',
            'will-change:transform,opacity'
          ].join(';');
          document.body.appendChild(sp);
          requestAnimationFrame(function(){
            sp.style.transform = 'translate('+px+'px,'+py+'px) scale(0)';
            sp.style.opacity = '0';
          });
          setTimeout(function(){ if(sp.parentNode) sp.remove(); }, 600);
        }, idx * 30);
      })(i);
    }
  }

  /* ── XP GAIN POPUP ── */
  window.showXpGainPopup = function(text, x, y) {
    var el = document.createElement('div');
    el.className = 'xp-gain-popup';
    el.textContent = text;
    el.style.left = (x || 180) + 'px';
    el.style.top = (y || 200) + 'px';
    document.body.appendChild(el);
    setTimeout(function(){ if(el.parentNode) el.remove(); }, 1200);
  };

  /* ── PARTICLE ORBIT around score ring ──
     Small glowing dots that float near the ring
  ── */
  function initRingParticles() {
    var wrap = document.querySelector('.ring-wrap');
    if (!wrap || wrap._particles) return;
    wrap._particles = true;
    for (var i = 0; i < 3; i++) {
      (function(idx) {
        var p = document.createElement('div');
        var size = 2 + idx;
        p.style.cssText = [
          'position:absolute','border-radius:50%',
          'width:'+size+'px','height:'+size+'px',
          'background:rgba(196,167,255,'+(0.4+idx*0.15)+')',
          'box-shadow:0 0 '+(4+idx*2)+'px rgba(124,58,255,'+(0.5+idx*0.2)+')',
          'pointer-events:none','z-index:4',
          'top:50%','left:50%',
          'transform-origin:0 0',
          'will-change:transform'
        ].join(';');
        wrap.appendChild(p);
        var radius = 62 + idx * 8;
        var speed = 8000 + idx * 2000;
        var offset = (idx / 3) * Math.PI * 2;
        var start = performance.now();
        function tick(now) {
          var t = (now - start) / speed * Math.PI * 2 + offset;
          var x = Math.cos(t) * radius;
          var y = Math.sin(t) * radius;
          p.style.transform = 'translate(calc(-50% + '+x+'px), calc(-50% + '+y+'px))';
          requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
      })(i);
    }
  }

  /* ── AMBIENT FLOATING PARTICLES (subtle, page-level) ── */
  function initAmbientParticles() {
    var container = document.getElementById('mainApp');
    if (!container || container._ambPart) return;
    container._ambPart = true;
    for (var i = 0; i < 8; i++) {
      (function(idx) {
        var p = document.createElement('div');
        var size = 1 + Math.random() * 2;
        var startX = Math.random() * 100;
        var duration = 12000 + Math.random() * 10000;
        var delay = Math.random() * 8000;
        p.style.cssText = [
          'position:fixed',
          'pointer-events:none',
          'z-index:0',
          'border-radius:50%',
          'width:'+size+'px',
          'height:'+size+'px',
          'left:'+startX+'%',
          'background:rgba(124,58,255,'+(0.2+Math.random()*0.3)+')',
          'box-shadow:0 0 '+(3+size*2)+'px rgba(124,58,255,0.4)',
          'will-change:transform,opacity'
        ].join(';');
        document.body.appendChild(p);
        function animate() {
          var startY = window.innerHeight + 10;
          var endY = -10;
          var drift = (Math.random() - 0.5) * 60;
          var start = performance.now();
          p.style.top = startY + 'px';
          p.style.opacity = '0';
          function tick(now) {
            var prog = Math.min((now - start) / duration, 1);
            var eased = prog; // linear
            var y = startY + (endY - startY) * eased;
            var x = parseFloat(p.style.left) + drift * Math.sin(prog * Math.PI);
            p.style.top = y + 'px';
            var opacity = prog < 0.1 ? prog / 0.1 : prog > 0.9 ? (1 - prog) / 0.1 : 0.25 + Math.random() * 0.1;
            p.style.opacity = Math.max(0, Math.min(0.35, opacity)).toString();
            if (prog < 1) {
              requestAnimationFrame(tick);
            } else {
              setTimeout(animate, Math.random() * 4000);
            }
          }
          requestAnimationFrame(tick);
        }
        setTimeout(animate, delay);
      })(i);
    }
  }

  /* ── HOOK HABIT TOGGLE for sparks ── */
  var _origToggle = window.toggleHabit;
  if (typeof _origToggle === 'function') {
    window.toggleHabit = function(id, el) {
      var card = el && el.closest ? el.closest('.habit-card') : null;
      _origToggle.apply(this, arguments);
      if (card) {
        setTimeout(function() {
          if (card.classList.contains('done')) {
            spawnSparks(card);
            var ptsEl = document.getElementById('hdrPtsVal');
            if (ptsEl) {
              var r = ptsEl.getBoundingClientRect();
              window.showXpGainPopup('+1 pt', r.left, r.top - 28);
            }
          }
        }, 60);
      }
    };
  }

  /* ── INIT ── */
  function init() {
    fixRingSVG();
    fixScoreLayout();
    fixRingNum();
    attachRipples();
    initRingParticles();
    setTimeout(initAmbientParticles, 1500);
  }

  /* Run after DOM and after app renders */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() { setTimeout(init, 300); });
  } else {
    setTimeout(init, 300);
  }
  setTimeout(function() {
    init();
    attachRipples();
  }, 2500);

  /* Re-attach on mutations */
  var obs = new MutationObserver(function() { attachRipples(); });
  document.addEventListener('DOMContentLoaded', function() {
    obs.observe(document.body, { childList: true, subtree: true });
  });

})();

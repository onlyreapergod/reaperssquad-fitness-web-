// Settings Panel — open/close/sync functions
// Depends on: script.js globals (THEMES, applyTheme, saveSettings)

function openSettingsPanel(){
  var p=document.getElementById('settingsPanel');
  var o=document.getElementById('settingsPanelOverlay');
  p.style.transform='translateX(0)';
  o.style.opacity='1';
  o.style.pointerEvents='auto';
  // Populate themes grid in panel
  var panelGrid=document.getElementById('themesGridPanel');
  if(panelGrid && typeof THEMES!=='undefined'){
    var curTheme=window.S&&window.S.theme||'dark';
    panelGrid.innerHTML=Object.keys(THEMES).map(function(k){
      var t=THEMES[k];
      return '<div class="theme-opt'+(curTheme===k?' active':'')+'" onclick="applyTheme(\''+k+'\')"><div class="theme-preview theme-'+k+'-preview"></div><div class="theme-opt-lbl">'+t.emoji+' '+t.label+'</div></div>';
    }).join('');
  }
  // Sync toggle states
  var notifSrc=document.getElementById('settingNotif');
  var notifPanel=document.getElementById('settingNotifPanel');
  var notifTogglePanel=document.getElementById('notifTogglePanel');
  if(notifSrc && notifPanel){
    notifPanel.checked=notifSrc.checked;
    notifTogglePanel.style.background=notifSrc.checked?'rgba(124,111,255,.5)':'rgba(255,255,255,.1)';
    notifTogglePanel.style.border=notifSrc.checked?'1px solid var(--accent)':'1px solid var(--border)';
  }
  var hapticSrc=document.getElementById('settingHaptic');
  var hapticPanel=document.getElementById('settingHapticPanel');
  var hapticTogglePanel=document.getElementById('hapticTogglePanel');
  if(hapticSrc && hapticPanel){
    hapticPanel.checked=hapticSrc.checked;
    hapticTogglePanel.style.background=hapticSrc.checked?'rgba(124,111,255,.5)':'rgba(255,255,255,.1)';
    hapticTogglePanel.style.border=hapticSrc.checked?'1px solid var(--accent)':'1px solid var(--border)';
  }
}
function closeSettingsPanel(){
  document.getElementById('settingsPanel').style.transform='translateX(100%)';
  var o=document.getElementById('settingsPanelOverlay');
  o.style.opacity='0';
  o.style.pointerEvents='none';
}
function syncSettingFromPanel(which){
  if(which==='notif'){
    var panel=document.getElementById('settingNotifPanel');
    var src=document.getElementById('settingNotif');
    var tog=document.getElementById('notifToggle');
    var togP=document.getElementById('notifTogglePanel');
    if(src){src.checked=panel.checked;}
    var active=panel.checked;
    if(tog){tog.style.background=active?'rgba(124,111,255,.5)':'rgba(255,255,255,.1)';tog.style.border=active?'1px solid var(--accent)':'1px solid var(--border)';}
    if(togP){togP.style.background=active?'rgba(124,111,255,.5)':'rgba(255,255,255,.1)';togP.style.border=active?'1px solid var(--accent)':'1px solid var(--border)';}
    if(typeof saveSettings==='function') saveSettings();
  } else if(which==='haptic'){
    var panel=document.getElementById('settingHapticPanel');
    var src=document.getElementById('settingHaptic');
    var tog=document.getElementById('hapticToggle');
    var togP=document.getElementById('hapticTogglePanel');
    if(src){src.checked=panel.checked;}
    var active=panel.checked;
    if(tog){tog.style.background=active?'rgba(124,111,255,.5)':'rgba(255,255,255,.1)';tog.style.border=active?'1px solid var(--accent)':'1px solid var(--border)';}
    if(togP){togP.style.background=active?'rgba(124,111,255,.5)':'rgba(255,255,255,.1)';togP.style.border=active?'1px solid var(--accent)':'1px solid var(--border)';}
    if(typeof saveSettings==='function') saveSettings();
  }
}

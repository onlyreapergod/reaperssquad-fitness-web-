// Survey Gate Logic — runs on app load
// Depends on: localStorage keys rs_last_survey, rs_survey_answers, tuProfile_*, currentUser

/* ── Survey Gate Logic ─────────────────────────────────────── */
(function(){
  // Don't run survey gate if we're inside an iframe (prevents recursion)
  if (window !== window.top) return;

  var INTERVAL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days

  function shouldShowSurvey() {
    var last = localStorage.getItem('rs_last_survey');
    if (!last) return true;                          // first time — mandatory
    return (Date.now() - parseInt(last)) >= INTERVAL_MS;
  }

  function hideSurveyOverlay() {
    document.getElementById('surveyOverlay').style.display = 'none';
  }

  if (shouldShowSurvey()) {
    // Load the survey iframe src NOW (was deferred to avoid 404 on initial page load)
    var surveyFrame = document.getElementById('surveyFrame');
    // Use getAttribute to check if src is actually set (surveyFrame.src always resolves to full URL)
    if (surveyFrame && surveyFrame.dataset.src && !surveyFrame.getAttribute('src')) {
      surveyFrame.src = surveyFrame.dataset.src;
    }
    document.getElementById('surveyOverlay').style.display = 'block';

    // survey.html calls window.location.href = APP_URL on finish.
    // We intercept that via postMessage OR by watching localStorage.
    var poll = setInterval(function(){
      var last = localStorage.getItem('rs_last_survey');
      if (last && (Date.now() - parseInt(last)) < 60000) {
        // Survey just saved (within last 60s) → hide overlay
        clearInterval(poll);
        hideSurveyOverlay();
      }
    }, 800);

    // Also handle iframe navigation attempts (survey redirecting to '/')
    window.addEventListener('message', function(e){
      if (e.data === 'survey_done') {
        clearInterval(poll);
        // Sync survey answers to profile
        setTimeout(function() {
          try {
            var surveyAnswers = JSON.parse(localStorage.getItem('rs_survey_answers') || 'null');
            var rsUser = JSON.parse(localStorage.getItem('rs_user') || 'null');
            var currentUser = JSON.parse(localStorage.getItem('currentUser') || 'null');
            var username = currentUser && currentUser.username;
            if (surveyAnswers && username) {
              var profileKey = 'tuProfile_' + username;
              var existing = JSON.parse(localStorage.getItem(profileKey) || '{}');
              // Map survey fields to profile fields
              if (surveyAnswers.body) {
                if (surveyAnswers.body.height) existing.height = parseInt(surveyAnswers.body.height);
                if (surveyAnswers.body.weight) existing.weight = parseInt(surveyAnswers.body.weight);
              }
              if (surveyAnswers.age) existing.age = parseInt(surveyAnswers.age);
              if (surveyAnswers.gender) existing.gender = surveyAnswers.gender;
              // Map survey goal to profile goal
              var goalMap = {
                fat_loss: 'cutting',
                muscle: 'bulking',
                aesthetics: 'cutting',
                strength: 'bulking'
              };
              if (surveyAnswers.goal) {
                existing.goal = goalMap[surveyAnswers.goal] || 'maintain';
              }
              // Map days to activity level
              var days = parseInt(surveyAnswers.days) || 3;
              existing.activity = days <= 2 ? 'light' : days <= 4 ? 'moderate' : days <= 5 ? 'moderate' : 'very';
              // Map level to sedentary if beginner
              if (surveyAnswers.level === 'beginner' && days <= 3) existing.activity = 'light';
              localStorage.setItem(profileKey, JSON.stringify(existing));
            }
          } catch(err) { console.warn('Profile sync error:', err); }
          hideSurveyOverlay();
        }, 300);
      }
    });
  }
})();

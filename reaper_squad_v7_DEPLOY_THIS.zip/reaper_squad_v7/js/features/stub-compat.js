// Stub compatibility — handles old cached references
// Also safely cleans up stale service workers
(function() {
  'use strict';

  // Stub for any old cached share-modal.js calls
  if (!window.openShareModal) window.openShareModal = function(){};
  if (!window.closeShareModal) window.closeShareModal = function(){};

  // Safe service worker update — only if SW is supported
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations().then(function(regs) {
      regs.forEach(function(reg) {
        // Trigger update check in background — never throws
        try { reg.update(); } catch(e) {}
      });
    }).catch(function() {
      // Silently ignore — incognito / blocked SW
    });
  }
})();

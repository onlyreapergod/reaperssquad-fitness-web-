// ============================================================
// REAPER SQUAD — SECURITY PATCH (security-patch.js)
// Load this BEFORE script.js in index.html:
//   <script src="/js/security-patch.js"></script>
//   <script src="/js/script.js"></script>
// ============================================================

// ---------------------------------------------------------------
// CRITICAL FIX 1: Remove hardcoded secrets from global scope.
// GROQ_KEY, SB_KEY, and OWNER are now runtime-only / server-side.
// Any reference to GROQ_KEY/SB_KEY in script.js calls will be
// intercepted and proxied through /api/ai (Cloudflare Function).
// ---------------------------------------------------------------

// Poison the leaked globals so script.js code that still references
// them fails fast rather than sending real keys to the browser.
// Real calls are handled by the patched callGemini / callGeminiText
// / callGeminiForPlan overrides below.
window._GROQ_KEY_REMOVED = true;

// ---------------------------------------------------------------
// CRITICAL FIX 2: AI calls → /api/ai (server proxy, no key exposed)
// Overrides callGemini, callGeminiText, callGeminiForPlan BEFORE
// script.js defines them, so script.js definitions are shadowed.
// ---------------------------------------------------------------

async function _proxyAI(provider, model, messages, system, max_tokens) {
  const resp = await fetch('/api/ai', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ provider, model, messages, system, max_tokens }),
  });
  if (!resp.ok) throw new Error('AI proxy error ' + resp.status);
  return resp.json();
}

// Replace callGemini (used everywhere for chat/AI)
window.callGemini = function(systemPrompt, messages, max_tokens) {
  const msgs = [];
  if (systemPrompt) msgs.push({ role: 'system', content: systemPrompt });
  if (Array.isArray(messages)) {
    messages.forEach(function(m) {
      msgs.push({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content });
    });
  } else if (messages) {
    msgs.push({ role: 'user', content: messages });
  }
  return _proxyAI('groq', 'llama-3.3-70b-versatile', msgs, null, max_tokens || 1000)
    .then(function(d) {
      return (d.choices && d.choices[0] && d.choices[0].message && d.choices[0].message.content) || '';
    })
    .catch(function() { return ''; });
};

// Replace callGeminiText
window.callGeminiText = function(system, userContent, onSuccess, onError) {
  _proxyAI('groq', 'llama-3.3-70b-versatile',
    [{ role: 'user', content: userContent }], system, 900)
    .then(function(d) {
      const text = (d.choices && d.choices[0] && d.choices[0].message && d.choices[0].message.content) || '';
      text ? onSuccess(text) : onError();
    })
    .catch(onError);
};

// Replace callGeminiForPlan
window.callGeminiForPlan = function(prompt, progressBar, intervalId, onSuccess, onError) {
  _proxyAI('groq', 'llama-3.3-70b-versatile',
    [
      { role: 'system', content: 'Tu ek expert fitness coach hai. User jo JSON format maange EXACTLY wohi return kar — koi extra text, explanation ya markdown nahi. Sirf valid JSON output karo.' },
      { role: 'user', content: prompt }
    ], null, 1500)
    .then(function(d) {
      clearInterval(intervalId);
      if (progressBar) progressBar.style.width = '100%';
      let text = '';
      try { text = d.choices[0].message.content || ''; } catch(e) {}
      text = text.replace(/```json|```/g, '').trim();
      const s = text.indexOf('{'), e = text.lastIndexOf('}');
      if (s !== -1 && e !== -1) text = text.slice(s, e + 1);
      let parsed = null;
      try { parsed = JSON.parse(text); } catch(e) {}
      parsed && parsed.days ? onSuccess(parsed) : onError();
    })
    .catch(function() { clearInterval(intervalId); onError(); });
};

// ---------------------------------------------------------------
// CRITICAL FIX 3: Anthropic direct browser call → proxy
// fixAnalyze() in script.js calls Anthropic directly with
// anthropic-dangerous-direct-browser-access. Intercept fetch.
// ---------------------------------------------------------------
(function() {
  const _origFetch = window.fetch;
  window.fetch = function(url) {
    var args = Array.prototype.slice.call(arguments);
    if (typeof url === 'string' && url.includes('api.anthropic.com')) {
      // Extract body and re-route through server proxy
      const opts = args[1] || {};
      let body = {};
      try { body = JSON.parse(opts.body || '{}'); } catch(e) {}
      return _proxyAI('anthropic', body.model || 'claude-sonnet-4-20250514',
        body.messages || [], body.system || '', body.max_tokens || 1200)
        .then(function(data) {
          return new Response(JSON.stringify(data), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
          });
        });
    }
    if (typeof url === 'string' && url.includes('api.groq.com')) {
      // Also intercept direct Groq calls (callGeminiForPlan in script.js uses GROQ_KEY directly)
      const opts = args[1] || {};
      let body = {};
      try { body = JSON.parse(opts.body || '{}'); } catch(e) {}
      const msgs = body.messages || [];
      const sys = msgs.find(function(m) { return m.role === 'system'; });
      const userMsgs = msgs.filter(function(m) { return m.role !== 'system'; });
      return _proxyAI('groq', body.model || 'llama-3.3-70b-versatile',
        userMsgs, sys ? sys.content : null, body.max_tokens || 1000)
        .then(function(data) {
          return new Response(JSON.stringify(data), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
          });
        });
    }
    return _origFetch.apply(window, args);
  };
})();

// ---------------------------------------------------------------
// CRITICAL FIX 4: Server-side owner verification
// isOwner() in script.js compares username === OWNER (client string).
// We replace it to use a cached server-verified flag set at login.
// ---------------------------------------------------------------
window._ownerVerified = false; // set to true after server confirms

async function _verifyOwnerServerSide(username) {
  try {
    const resp = await fetch('/api/verify-owner', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username }),
    });
    const data = await resp.json();
    window._ownerVerified = !!data.isOwner;
  } catch(e) {
    window._ownerVerified = false;
  }
}

// Override isOwner to use server-verified flag only
window.isOwner = function(username) {
  // If a specific username is passed (for display only), use the verified flag only
  // when it's the current user.
  if (username && window.S && window.S.user && username !== window.S.user.username) {
    return false; // Can't claim owner for another user client-side
  }
  return window._ownerVerified === true;
};

// ---------------------------------------------------------------
// CRITICAL FIX 5: Passwords — strip btoa storage, use Google Auth
// Patch doLogin/doSignup to refuse plaintext password auth.
// Google OAuth is the only supported login method.
// ---------------------------------------------------------------
window.doLogin = function() {
  if (typeof window.toast === 'function') {
    window.toast('⚠️ Password login disabled. Use Google Sign-In below.');
  }
};
window.doSignup = function() {
  if (typeof window.toast === 'function') {
    window.toast('⚠️ Sign up with Google Sign-In button below.');
  }
};

// ---------------------------------------------------------------
// HIGH FIX 6: Ban enforcement from Supabase (not localStorage)
// getKicked() reads localStorage which any user can clear.
// Augment with a Supabase fetch so bans can't be self-removed.
// ---------------------------------------------------------------
window._kickedFromServer = new Set();

async function _loadKickedFromServer(squadCode) {
  try {
    // Uses the existing sbGet helper defined in script.js
    const result = await window.sbGet('kicked_users', { squad_code: squadCode || 'SQXXNI' });
    window._kickedFromServer = new Set(
      (result.results || []).map(function(r) { return r.username; })
    );
  } catch(e) {
    // fallback to localStorage-only on network error
  }
}

// Wrap isKicked to also check server list
const _origIsKicked = window.isKicked;
window.isKicked = function(username) {
  return window._kickedFromServer.has(username) ||
    (typeof _origIsKicked === 'function' ? _origIsKicked(username) : false);
};

// ---------------------------------------------------------------
// HIGH FIX 7: Hook bootApp to trigger server-side checks
// ---------------------------------------------------------------
document.addEventListener('DOMContentLoaded', function() {
  // Intercept bootApp to inject async security checks
  const _timer = setInterval(function() {
    if (typeof window.bootApp === 'function') {
      clearInterval(_timer);
      const _origBootApp = window.bootApp;
      window.bootApp = function() {
        const user = window.S && window.S.user;
        if (user && user.username) {
          // Verify owner status server-side before booting
          _verifyOwnerServerSide(user.username).then(function() {
            // Load server-side kicked list
            return _loadKickedFromServer(user.squadCode || 'SQXXNI');
          }).then(function() {
            // Now check if current user is actually kicked server-side
            if (window._kickedFromServer.has(user.username)) {
              if (typeof window.toast === 'function') window.toast('❌ You have been removed from this squad.');
              if (typeof window.doLogout === 'function') window.doLogout();
              return;
            }
            _origBootApp.apply(this, arguments);
          });
        } else {
          _origBootApp.apply(this, arguments);
        }
      };
    }
  }, 50);
});

// ---------------------------------------------------------------
// HIGH FIX 8: XSS — patch innerHTML sinks that use user.picture URL
// renderGoogleUserInHeader uses innerHTML with S.user.picture (external URL).
// Sanitize by restricting to known Google CDN domain only.
// ---------------------------------------------------------------
(function() {
  const _timer2 = setInterval(function() {
    if (typeof window.renderGoogleUserInHeader === 'function') {
      clearInterval(_timer2);
      const _orig = window.renderGoogleUserInHeader;
      window.renderGoogleUserInHeader = function() {
        // Validate picture URL before it reaches innerHTML
        if (window.S && window.S.user && window.S.user.picture) {
          const pic = window.S.user.picture;
          // Only allow Google user content CDN
          if (!/^https:\/\/lh[0-9]+\.googleusercontent\.com\//.test(pic)) {
            window.S.user.picture = ''; // strip untrusted URL
          }
        }
        return _orig.apply(this, arguments);
      };
    }
  }, 50);
})();

console.log('[ReaperSquad] Security patch loaded ✅');

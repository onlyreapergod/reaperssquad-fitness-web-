/* ============================================================
   ☠️ REAPER SQUAD — TRAIN MODE v2.0
   Agar character/physique selected hai toh Train page pe sirf
   uska workout plan dikhao. Selection grid etc hide ho jaayein.
   ============================================================ */

(function () {
  "use strict";

  /* ──────────────────────────────────────────────────────────
     HELPER: kya koi bhi physique/character selected hai?
  ────────────────────────────────────────────────────────── */
  function getSelectedCharacter() {
    // Anime physique (male + female both)
    var sel = window._selectedPhysique;
    if (sel && sel.id) return { char: sel, type: "anime" };
    // Lady anime
    var lsel = window._selectedLadyPhysique;
    if (lsel && lsel.id) return { char: lsel, type: "lady" };
    return null;
  }

  /* ──────────────────────────────────────────────────────────
     HTML BUILDER: sirf selected character ka training plan card
  ────────────────────────────────────────────────────────── */
  function buildActivePlanView(selected) {
    var char = selected.char;
    var type = selected.type;

    // Days from state ya default
    var savedPlan  = window._currentPlan  || null;
    var savedPhys  = window._currentPhys  || char;

    var accentColor = char.color || "var(--accent)";
    var typeLabel   = char.isCali        ? "Calisthenics Skill" :
                      char.isWeightLoss  ? "Weight Loss"        :
                      type === "lady"    ? "Lady Anime Physique":
                                           char.anime || "Anime Physique";

    var streakDays = (typeof getPhysiqueStreakDays === "function")
                     ? getPhysiqueStreakDays() : 0;
    var streakHTML = streakDays >= 2
                     ? '<span style="font-size:.75rem;color:#ffd700;font-weight:800">🔥 ' + streakDays + "d streak</span>"
                     : "";

    var html = '';

    /* ── Hero card ── */
    html += '<div style="background:linear-gradient(135deg,rgba(255,255,255,.05),rgba(255,255,255,.02));border:1.5px solid ' + accentColor + '44;border-radius:20px;padding:18px 16px 14px;margin-bottom:16px;position:relative;overflow:hidden">';
    html += '<div style="position:absolute;inset:0;background:radial-gradient(ellipse at 80% 20%,' + accentColor + '18,transparent 70%);pointer-events:none"></div>';

    /* character info row */
    html += '<div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">';
    html += '<div style="font-size:3rem;line-height:1;filter:drop-shadow(0 0 12px ' + accentColor + '88)">' + (char.emoji || "💀") + '</div>';
    html += '<div style="flex:1;min-width:0">';
    html += '<div style="font-size:1rem;font-weight:900;color:' + accentColor + ';line-height:1.2;margin-bottom:2px">' + escT(char.name) + '</div>';
    html += '<div style="font-size:.68rem;color:var(--muted);margin-bottom:6px">' + escT(typeLabel) + '</div>';
    html += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">';
    html += '<span style="font-size:.6rem;background:' + accentColor + '22;border:1px solid ' + accentColor + '44;color:' + accentColor + ';border-radius:20px;padding:3px 10px;font-weight:700">⚡ Active Goal</span>';
    if (streakHTML) html += streakHTML;
    html += '</div>';
    html += '</div>'; /* end info */

    /* quit button */
    html += '<button onclick="window._tmHandleQuit()" style="background:rgba(255,60,60,.12);border:1px solid rgba(255,60,60,.3);color:#ff6b6b;border-radius:10px;padding:7px 11px;font-size:.65rem;font-weight:800;cursor:pointer;flex-shrink:0">✕ Quit</button>';
    html += '</div>'; /* end row */

    /* stat bars */
    if (char.stats) {
      var s = char.stats;
      var barItems = char.isCali
        ? [["💪", "Strength", s.strength], ["⚡", "Explosiveness", s.speed], ["🎯", "Skill", s.aesthetics]]
        : char.isWeightLoss
        ? [["🔥", "Fat Burn", s.speed], ["🏃", "Cardio", s.endurance], ["💪", "Muscle", s.strength]]
        : [["💪", "Strength", s.strength], ["🏃", "Endurance", s.endurance], ["⚡", "Speed", s.speed], ["✨", "Aesthetic", s.aesthetics]];

      html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-bottom:12px">';
      barItems.forEach(function (b) {
        html += '<div style="background:rgba(255,255,255,.03);border-radius:8px;padding:6px 9px">';
        html += '<div style="display:flex;justify-content:space-between;font-size:.6rem;color:var(--muted);margin-bottom:4px"><span>' + b[0] + ' ' + b[1] + '</span><span style="color:' + accentColor + ';font-weight:800">' + b[2] + '</span></div>';
        html += '<div style="height:5px;background:rgba(255,255,255,.06);border-radius:4px;overflow:hidden"><div style="height:100%;width:' + b[2] + '%;background:' + accentColor + ';border-radius:4px"></div></div>';
        html += '</div>';
      });
      html += '</div>';
    }

    /* ── action buttons row ── */
    html += '<div style="display:flex;gap:8px">';
    html += '<button onclick="window._tmOpenPlan()" style="flex:1;padding:11px 6px;background:linear-gradient(135deg,' + accentColor + ',var(--accent2));border:none;border-radius:12px;color:#000;font-size:.78rem;font-weight:800;cursor:pointer">💀 Workout Plan Dekho →</button>';
    html += '<button onclick="window._tmOpenSelectPage()" style="flex:0 0 auto;padding:11px 13px;background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:12px;color:var(--muted);font-size:.72rem;font-weight:700;cursor:pointer">🔄 Change</button>';
    html += '</div>';

    html += '</div>'; /* end hero card */

    /* ── Today's exercises (logged plan exercises) ── */
    html += buildTodaySection(char, accentColor);

    /* ── Streak + consistency mini-card ── */
    html += buildStreakCard(streakDays, accentColor);

    return html;
  }

  /* Today's logged plan exercises */
  function buildTodaySection(char, color) {
    if (!window.S || !window.S.user) return '';
    var username = window.S.user.username;
    var today    = (typeof dateKey === "function") ? dateKey(0) : new Date().toISOString().slice(0,10);
    var planKey  = "planEx_" + username + "_" + today;
    var exKey    = "ex_"     + username + "_" + today;

    var planEx   = (typeof lsGet === "function" ? lsGet(planKey) : null) || {};
    var exercises = (typeof lsGet === "function" ? lsGet(exKey)  : null) || [];
    var planLogged = exercises.filter(function(e){ return e.planKey; });

    if (planLogged.length === 0 && Object.keys(planEx).length === 0) {
      /* if no plan generated yet, prompt */
      return '<div style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:14px;padding:14px 16px;margin-bottom:14px;text-align:center">' +
             '<div style="font-size:1.4rem;margin-bottom:6px">📋</div>' +
             '<div style="font-size:.76rem;font-weight:700;color:var(--text);margin-bottom:4px">Aaj ka plan abhi generate nahi hua</div>' +
             '<div style="font-size:.65rem;color:var(--muted);margin-bottom:12px">"Workout Plan Dekho" pe tap karo aur AI se plan generate karo</div>' +
             '<button onclick="window._tmOpenPlan()" style="padding:9px 18px;background:linear-gradient(135deg,' + color + ',var(--accent2));border:none;border-radius:10px;color:#000;font-size:.75rem;font-weight:800;cursor:pointer">💀 Plan Banao →</button>' +
             '</div>';
    }

    var completedCount = planLogged.length;
    var html = '<div style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:14px;padding:14px 16px;margin-bottom:14px">';
    html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">';
    html += '<div style="font-size:.78rem;font-weight:800;color:var(--text)">📋 Aaj ka Progress</div>';
    html += '<div style="font-size:.65rem;color:' + color + ';font-weight:700;background:' + color + '22;border:1px solid ' + color + '44;border-radius:20px;padding:3px 10px">' + completedCount + ' done ✓</div>';
    html += '</div>';

    planLogged.slice(0, 5).forEach(function(ex) {
      html += '<div style="display:flex;align-items:center;gap:10px;padding:7px 10px;background:rgba(74,222,128,.08);border:1px solid rgba(74,222,128,.2);border-radius:9px;margin-bottom:5px">';
      html += '<div style="color:#4ade80;font-size:.9rem">✓</div>';
      html += '<div style="flex:1"><div style="font-size:.74rem;font-weight:700;color:var(--text)">' + escT(ex.name) + '</div>';
      html += '<div style="font-size:.6rem;color:var(--muted)">' + ex.sets + ' sets × ' + escT(String(ex.reps)) + '</div></div>';
      html += '</div>';
    });

    if (planLogged.length > 5) {
      html += '<div style="font-size:.62rem;color:var(--muted);text-align:center;margin-top:4px">+' + (planLogged.length - 5) + ' aur exercises ✓</div>';
    }

    html += '</div>';
    return html;
  }

  /* 7-day streak dots */
  function buildStreakCard(streakDays, color) {
    var html = '<div style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:14px;padding:13px 16px">';
    html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">';
    html += '<div style="font-size:.76rem;font-weight:800;color:var(--text)">🔥 Consistency</div>';
    html += '<div style="font-size:.85rem;font-weight:900;color:' + color + '">' + streakDays + 'd</div>';
    html += '</div>';

    /* 7 day dots */
    html += '<div style="display:flex;gap:5px;justify-content:space-between">';
    var days = ["Su","Mo","Tu","We","Th","Fr","Sa"];
    var now  = new Date();
    var dow  = now.getDay();
    for (var i = 6; i >= 0; i--) {
      var d    = new Date(now); d.setDate(d.getDate() - i);
      var dStr = d.toISOString().slice(0,10);
      var user = window.S && window.S.user ? window.S.user.username : "";
      var exData = user && typeof lsGet === "function" ? (lsGet("ex_" + user + "_" + dStr) || []) : [];
      var hbData = user && typeof lsGet === "function" ? (lsGet("hb_" + user + "_" + dStr) || {}) : {};
      var pts  = exData.length + Object.values(hbData).filter(Boolean).length;
      var active = pts >= 3;
      var isToday = i === 0;
      var dotColor = active ? color : "rgba(255,255,255,.07)";
      html += '<div style="display:flex;flex-direction:column;align-items:center;gap:3px">';
      html += '<div style="width:28px;height:28px;border-radius:50%;background:' + dotColor + ';border:' + (isToday ? "1.5px solid " + color + "88" : "1px solid rgba(255,255,255,.08)") + ';display:flex;align-items:center;justify-content:center;font-size:.55rem;color:' + (active ? "#000" : "rgba(255,255,255,.25)") + '">' + (active ? "✓" : "") + '</div>';
      html += '<span style="font-size:.45rem;color:' + (isToday ? color : "rgba(255,255,255,.3)") + ';font-weight:' + (isToday ? "800" : "400") + '">' + days[d.getDay()] + '</span>';
      html += '</div>';
    }
    html += '</div>';
    html += '</div>';
    return html;
  }

  /* Safe HTML escape */
  function escT(str) {
    return String(str)
      .replace(/&/g,"&amp;").replace(/</g,"&lt;")
      .replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }

  /* ──────────────────────────────────────────────────────────
     MAIN: patch renderTrainPage
  ────────────────────────────────────────────────────────── */
  function patchRenderTrainPage() {
    var _origRender = window.renderTrainPage;

    window.renderTrainPage = function () {
      /* Make sure physiques are loaded from localStorage */
      if (!window._selectedPhysique && typeof loadSavedPhysique === "function") {
        loadSavedPhysique();
      }
      if (!window._selectedLadyPhysique && typeof loadSavedLadyPhysique === "function") {
        loadSavedLadyPhysique();
      }

      var selected = getSelectedCharacter();

      if (!selected) {
        /* Nothing selected → normal flow */
        if (typeof _origRender === "function") _origRender();
        return;
      }

      /* ── Character IS selected → show only the plan view ── */
      var page = document.getElementById("pgTrain");
      if (!page) return;

      /* Hide ALL original train section wraps */
      var sectionWraps = page.querySelectorAll(".train-section-wrap");
      sectionWraps.forEach(function(el){ el.style.display = "none"; });

      /* Hide the hero banner sub-text that says "choose goal" */
      var heroBanner = page.querySelector(".train-hero-banner");
      if (heroBanner) {
        var heroSub = heroBanner.querySelector(".thb-sub");
        if (heroSub) heroSub.textContent = "Tera plan ready hai — grind karo 💀";
        var heroChips = heroBanner.querySelector(".thb-chips");
        if (heroChips) heroChips.style.display = "none";
      }

      /* Insert or update our custom plan container */
      var planContainer = document.getElementById("tm-plan-container");
      if (!planContainer) {
        planContainer = document.createElement("div");
        planContainer.id = "tm-plan-container";
        planContainer.style.cssText = "padding:0 14px 24px";
        page.appendChild(planContainer);
      }
      planContainer.innerHTML = buildActivePlanView(selected);
    };
  }

  /* ──────────────────────────────────────────────────────────
     GLOBAL ACTIONS wired from buttons inside the plan view
  ────────────────────────────────────────────────────────── */

  /* Open plan modal for the selected character */
  window._tmOpenPlan = function () {
    var sel = getSelectedCharacter();
    if (!sel) return;
    var char = sel.char;

    if (char.isCali) {
      /* Calisthenics — open the cali skill modal */
      if (typeof selectCaliSkill === "function") selectCaliSkill(char.id);
    } else if (char.isWeightLoss) {
      /* Weight loss — open wl modal */
      if (typeof selectWeightLossGoal === "function") selectWeightLossGoal(char.id);
    } else {
      /* Anime / lady — open physique modal */
      if (typeof selectPhysique === "function") selectPhysique(char.id);
      else if (typeof selectLadyPhysique === "function") selectLadyPhysique(char.id);
    }
  };

  /* Open the appropriate selection page so user can change character */
  window._tmOpenSelectPage = function () {
    var sel = getSelectedCharacter();
    if (!sel) return;
    if (sel.type === "lady") {
      if (typeof openLadyAnimeSelectPage === "function") openLadyAnimeSelectPage();
    } else if (sel.char && sel.char.isCali) {
      if (typeof openCaliSelectPage === "function") openCaliSelectPage();
    } else {
      if (typeof openAnimeSelectPage === "function") openAnimeSelectPage();
    }
  };

  /* Quit — clear selection then re-render to show selection grid */
  window._tmHandleQuit = function () {
    var sel = getSelectedCharacter();
    if (!sel) return;

    /* Use existing quit popup if available (anime physique) */
    if (sel.type !== "lady" && !sel.char.isCali && !sel.char.isWeightLoss) {
      if (typeof openQuitPhysiquePopup === "function") {
        openQuitPhysiquePopup();
        return;
      }
    }

    /* For lady / cali / wl — direct clear with confirm */
    if (!confirm("Character quit karna chahte ho? Teri streak aur progress local mein save hai.")) return;

    /* Clear selected */
    if (sel.type === "lady") {
      window._selectedLadyPhysique = null;
      if (window.S && window.S.user) {
        try { localStorage.removeItem("selLadyPhys_" + window.S.user.username); } catch(_){}
      }
    } else {
      window._selectedPhysique = null;
      if (window.S && window.S.user && typeof getSavedPhysiqueKey === "function") {
        try { localStorage.removeItem(getSavedPhysiqueKey()); } catch(_){}
        try { localStorage.removeItem(window.S.user && "physStreak_" + window.S.user.username); } catch(_){}
      }
    }

    /* Re-render train page in selection mode */
    _doFullTrainRender();
  };

  /* Force full original render (show all sections) */
  function _doFullTrainRender() {
    var page = document.getElementById("pgTrain");
    if (!page) return;

    /* Remove our container */
    var container = document.getElementById("tm-plan-container");
    if (container) container.remove();

    /* Show all section wraps */
    page.querySelectorAll(".train-section-wrap").forEach(function(el){
      el.style.display = "";
    });

    /* Restore hero banner */
    var heroBanner = page.querySelector(".train-hero-banner");
    if (heroBanner) {
      var heroSub = heroBanner.querySelector(".thb-sub");
      if (heroSub) heroSub.textContent = "Apna goal choose karo — AI tera personal trainer banega";
      var heroChips = heroBanner.querySelector(".thb-chips");
      if (heroChips) heroChips.style.display = "";
    }

    /* Call original render for previews, weight loss grid etc */
    var _orig = window._tmOrigRender;
    if (typeof _orig === "function") _orig();
  }

  /* ──────────────────────────────────────────────────────────
     HOOK INTO doActualQuit so quitting from AI convince popup
     also re-shows the selection grid
  ────────────────────────────────────────────────────────── */
  function hookDoActualQuit() {
    var _orig = window.doActualQuit;
    if (!_orig || window._tmQuitPatched) return;
    window._tmQuitPatched = true;
    window.doActualQuit = function () {
      _orig();
      /* After quit, remove our container so selection shows */
      setTimeout(function () {
        var container = document.getElementById("tm-plan-container");
        if (container) container.remove();
        var page = document.getElementById("pgTrain");
        if (page) {
          page.querySelectorAll(".train-section-wrap").forEach(function(el){ el.style.display = ""; });
          var heroBanner = page.querySelector(".train-hero-banner");
          if (heroBanner) {
            var heroSub = heroBanner.querySelector(".thb-sub");
            if (heroSub) heroSub.textContent = "Apna goal choose karo — AI tera personal trainer banega";
            var heroChips = heroBanner.querySelector(".thb-chips");
            if (heroChips) heroChips.style.display = "";
          }
        }
      }, 100);
    };
  }

  /* ──────────────────────────────────────────────────────────
     INIT — wait for app to boot then patch
  ────────────────────────────────────────────────────────── */
  function init() {
    /* Store orig render reference before patching */
    window._tmOrigRender = window.renderTrainPage;
    patchRenderTrainPage();
    hookDoActualQuit();

    /* Also hook goPage to re-trigger our patched version */
    var _origGoPage = window.goPage;
    if (_origGoPage && !window._tmGoPagePatched) {
      window._tmGoPagePatched = true;
      window.goPage = function (page, navEl) {
        _origGoPage(page, navEl);
        /* After navigation to train, our patched renderTrainPage is already called by goPage */
      };
    }

    console.log("☠️ Train Mode v2 loaded — selected character pe sirf plan dikhega!");
  }

  /* Run after DOM + scripts are ready */
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function () { setTimeout(init, 200); });
  } else {
    setTimeout(init, 200);
  }
})();

// share-modal.js — BULLETPROOF v3 (never throws, ever)
// Wraps every single operation in null-checks + try-catch
(function () {
  'use strict';

  function safeOn(id, event, fn) {
    try {
      var el = document.getElementById(id);
      if (el) el.addEventListener(event, fn);
    } catch (e) {}
  }

  function openShareModal() {
    try {
      var el = document.getElementById('shareModalOverlay');
      if (el) el.classList.remove('hidden');
    } catch (e) {}
  }

  function closeShareModal() {
    try {
      var el = document.getElementById('shareModalOverlay');
      if (el) el.classList.add('hidden');
    } catch (e) {}
  }

  function copyShareLink() {
    try {
      var input = document.getElementById('shareLinkInput');
      if (!input) return;
      var text = input.value || input.textContent || '';
      if (!text) return;
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).catch(function () {});
      }
    } catch (e) {}
  }

  function init() {
    try {
      safeOn('shareModalClose',  'click', closeShareModal);
      safeOn('shareCancelBtn',   'click', closeShareModal);
      safeOn('shareCopyBtn',     'click', copyShareLink);
      safeOn('shareCodeCopyBtn', 'click', copyShareLink);
      safeOn('shareBtn',         'click', openShareModal);
      safeOn('openShareModalBtn','click', openShareModal);
      safeOn('inviteBtn',        'click', openShareModal);

      var overlay = document.getElementById('shareModalOverlay');
      if (overlay) {
        overlay.addEventListener('click', function (e) {
          try { if (e.target === overlay) closeShareModal(); } catch (ex) {}
        });
      }
    } catch (e) {}
  }

  // Expose globals safely
  try {
    if (!window.openShareModal)  window.openShareModal  = openShareModal;
    if (!window.closeShareModal) window.closeShareModal = closeShareModal;
    if (!window.copyShareLink)   window.copyShareLink   = copyShareLink;
  } catch (e) {}

  // Init on DOM ready - multiple fallbacks so it ALWAYS runs
  function tryInit() {
    try { init(); } catch (e) {}
  }

  try {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', tryInit);
    } else {
      setTimeout(tryInit, 0);
    }
    // Extra safety: also run after full page load
    window.addEventListener('load', tryInit);
  } catch (e) {}
})();

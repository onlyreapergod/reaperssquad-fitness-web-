/* ============================================================
   ☠️ REAPER SQUAD — HOME SKILL PLAN v1.0
   Agar koi skill/character selected hai toh home page pe
   uska learning plan + exercises dikhao with sets/reps tracker.
   Purana "Add Exercise" system replace ho gaya hai.
   ============================================================ */

(function () {
  "use strict";

  /* ──────────────────────────────────────────────────────────
     SKILL-SPECIFIC EXERCISE PLANS
     Har cali skill ke liye dedicated exercises + sets/reps
  ────────────────────────────────────────────────────────── */
  var SKILL_PLANS = {

    /* ── HANDSTAND ── */
    handstand: {
      phases: [
        {
          name: "Phase 1 — Foundation",
          weeks: "Week 1-2",
          emoji: "🏗️",
          exercises: [
            { name: "Wrist Circles", sets: 3, reps: "30 sec", tip: "Dono directions mein", emoji: "🔄" },
            { name: "Wrist Push Ups", sets: 3, reps: "10", tip: "Knuckles pe push karo", emoji: "✊" },
            { name: "Wall Shoulder Taps", sets: 3, reps: "10 each", tip: "Wall pe haath, tap alternating", emoji: "🧱" },
            { name: "Pike Hold (Wall)", sets: 4, reps: "30 sec", tip: "Hips upar, body V shape", emoji: "⛰️" },
            { name: "Hollow Body Hold", sets: 3, reps: "20 sec", tip: "Lower back floor se touch kare", emoji: "🍌" },
          ]
        },
        {
          name: "Phase 2 — Wall HS",
          weeks: "Week 3-6",
          emoji: "🧱",
          exercises: [
            { name: "Wall Handstand (Chest to Wall)", sets: 5, reps: "30 sec", tip: "Seene wall se touch karo", emoji: "🤸" },
            { name: "HS Shoulder Shrugs (Wall)", sets: 3, reps: "10", tip: "Arms push through ears", emoji: "💪" },
            { name: "HS Leg Raises (Wall)", sets: 3, reps: "8 each", tip: "Ek paon utha ke balance", emoji: "🦵" },
            { name: "Pike Push Ups", sets: 4, reps: "8", tip: "Head floor near karo", emoji: "⛰️" },
            { name: "Tuck Compression Hold", sets: 3, reps: "15 sec", tip: "Knees chest se touch", emoji: "🎯" },
          ]
        },
        {
          name: "Phase 3 — Kick Up",
          weeks: "Week 7-10",
          emoji: "🚀",
          exercises: [
            { name: "Kick Up Practice", sets: 10, reps: "singles", tip: "Slow controlled kick — no throwing", emoji: "🦶" },
            { name: "Freestanding HS Attempts", sets: 8, reps: "singles", tip: "3-5 sec balance try karo", emoji: "⭐" },
            { name: "HS Wall Walks", sets: 3, reps: "5", tip: "Wall se aage walk karo hands pe", emoji: "🚶" },
            { name: "Pirouette Balance Drill", sets: 5, reps: "30 sec", tip: "Haath movement se balance adjust", emoji: "🌀" },
            { name: "Line HS Hold", sets: 5, reps: "max hold", tip: "Floor line pe haath rakho straight", emoji: "📏" },
          ]
        }
      ]
    },

    /* ── HUMAN FLAG ── */
    humanflag: {
      phases: [
        {
          name: "Phase 1 — Grip & Lat Base",
          weeks: "Week 1-4",
          emoji: "💪",
          exercises: [
            { name: "Dead Hang", sets: 4, reps: "45 sec", tip: "Straight arms full hang", emoji: "🏋️" },
            { name: "Pull Ups", sets: 4, reps: "8-10", tip: "Full range, slow negative", emoji: "🔝" },
            { name: "Dips (Parallel Bar)", sets: 4, reps: "10-12", tip: "Elbows 90 degree, full dip", emoji: "⬇️" },
            { name: "Side Plank", sets: 3, reps: "30 sec each", tip: "Body seedha line mein", emoji: "📐" },
            { name: "Hollow Body Hold", sets: 3, reps: "30 sec", tip: "Arms overhead, back pressed", emoji: "🍌" },
          ]
        },
        {
          name: "Phase 2 — Tuck Flag",
          weeks: "Week 5-10",
          emoji: "🏳️",
          exercises: [
            { name: "Tuck Flag Hold (Pole)", sets: 5, reps: "5-10 sec", tip: "Knees tucked chest pe, hold!", emoji: "🚩" },
            { name: "Flag Negatives", sets: 5, reps: "3 slow", tip: "Slow lower se full tuck tak", emoji: "⬇️" },
            { name: "Archer Pull Ups", sets: 3, reps: "5 each", tip: "Ek haath pull, dusra extend", emoji: "🎯" },
            { name: "Lateral Core Raises", sets: 4, reps: "10 each", tip: "Side mein legs utha, lateral core", emoji: "📐" },
            { name: "Pseudo Planche Push Ups", sets: 3, reps: "8", tip: "Haath forward, lean karo", emoji: "🔮" },
          ]
        },
        {
          name: "Phase 3 — Straddle & Full",
          weeks: "Week 11-20",
          emoji: "🚀",
          exercises: [
            { name: "Straddle Flag Hold", sets: 5, reps: "3-8 sec", tip: "Legs side mein spread, hold", emoji: "🌟" },
            { name: "Full Flag Attempts", sets: 5, reps: "max hold", tip: "Pehle straddle solid karo", emoji: "🏁" },
            { name: "Flag Pull Ups", sets: 3, reps: "3-5", tip: "Flag position mein pull!", emoji: "💀" },
            { name: "Windshield Wipers", sets: 3, reps: "8 each", tip: "Hanging leg rotation full", emoji: "🌀" },
            { name: "One Arm Dead Hang", sets: 3, reps: "10 sec each", tip: "Slow control, don't swing", emoji: "☝️" },
          ]
        }
      ]
    },

    /* ── PLANCHE ── */
    planche: {
      phases: [
        {
          name: "Phase 1 — Wrist & Scapula",
          weeks: "Week 1-6",
          emoji: "🔧",
          exercises: [
            { name: "Wrist Push Ups", sets: 3, reps: "15", tip: "Palms aage, peeche, sides", emoji: "✊" },
            { name: "Scapular Push Ups", sets: 4, reps: "12", tip: "Arms straight, scapula only move", emoji: "👐" },
            { name: "Planche Lean (Straight Arms)", sets: 5, reps: "10 sec", tip: "Toes pe, body aage lean", emoji: "🎯" },
            { name: "Pseudo Planche Push Ups", sets: 4, reps: "8", tip: "Haath hip ke paas, forward lean", emoji: "🔮" },
            { name: "L-Sit Hold", sets: 4, reps: "15 sec", tip: "Arms lock, hips flex", emoji: "💺" },
          ]
        },
        {
          name: "Phase 2 — Tuck Planche",
          weeks: "Week 7-14",
          emoji: "🐛",
          exercises: [
            { name: "Tuck Planche Hold", sets: 6, reps: "5-10 sec", tip: "Knees chest se, arms straight!", emoji: "🦋" },
            { name: "Tuck Planche Push Ups", sets: 3, reps: "3-5", tip: "Tuck position mein push", emoji: "⬆️" },
            { name: "Advanced Tuck Hold", sets: 5, reps: "5 sec", tip: "Hips lower than tuck", emoji: "🔱" },
            { name: "Ring Push Ups", sets: 4, reps: "10", tip: "Rings unstable — harder!", emoji: "💍" },
            { name: "Planche Leans (Long)", sets: 5, reps: "15 sec", tip: "Max lean angle seek karo", emoji: "⚡" },
          ]
        },
        {
          name: "Phase 3 — Full Planche",
          weeks: "Month 6-18+",
          emoji: "🦅",
          exercises: [
            { name: "Straddle Planche Hold", sets: 5, reps: "max sec", tip: "Legs spread — easier than full", emoji: "🦅" },
            { name: "Full Planche Attempts", sets: 5, reps: "max sec", tip: "Legs together — ultimate!", emoji: "💀" },
            { name: "Planche Push Ups (Straddle)", sets: 3, reps: "2-3", tip: "Straddle mein full ROM push", emoji: "🔥" },
            { name: "Ring Planche Hold", sets: 3, reps: "max sec", tip: "Rings pe — hardest form", emoji: "💍" },
            { name: "One Arm Planche Drill", sets: 3, reps: "5 sec each", tip: "Future goal — isometric drill", emoji: "☝️" },
          ]
        }
      ]
    },

    /* ── FRONT LEVER ── */
    frontlever: {
      phases: [
        {
          name: "Phase 1 — Pull Foundation",
          weeks: "Week 1-4",
          emoji: "💪",
          exercises: [
            { name: "Dead Hangs", sets: 4, reps: "1 min", tip: "Straight arm full hang", emoji: "🏋️" },
            { name: "Scapular Pull Ups", sets: 4, reps: "10", tip: "No elbow bend — lat only", emoji: "🔽" },
            { name: "Pull Ups (Slow Negative)", sets: 4, reps: "5 (5 sec lower)", tip: "5 second ka negative", emoji: "🔝" },
            { name: "German Hang", sets: 3, reps: "10 sec", tip: "Shoulder flexibility build", emoji: "🇩🇪" },
            { name: "Tuck Front Lever", sets: 5, reps: "10 sec", tip: "Knees chest, body parallel!", emoji: "🐛" },
          ]
        },
        {
          name: "Phase 2 — Straddle FL",
          weeks: "Week 5-12",
          emoji: "🏹",
          exercises: [
            { name: "Advanced Tuck FL", sets: 5, reps: "8 sec", tip: "Hips slightly lower than tuck", emoji: "🎯" },
            { name: "One Leg Extended FL", sets: 5, reps: "8 sec", tip: "Ek paon extend, dusra tuck", emoji: "🦵" },
            { name: "Straddle Front Lever", sets: 5, reps: "5-8 sec", tip: "Legs wide — easier than full!", emoji: "🌟" },
            { name: "FL Rows", sets: 4, reps: "5", tip: "FL se pull up — crazy hard", emoji: "💀" },
            { name: "Dragon Flag", sets: 3, reps: "5", tip: "Core rigidity builder for FL", emoji: "🐉" },
          ]
        },
        {
          name: "Phase 3 — Full Front Lever",
          weeks: "Month 5-12",
          emoji: "🏹",
          exercises: [
            { name: "Full Front Lever Hold", sets: 5, reps: "max sec", tip: "Body completely parallel!", emoji: "🏹" },
            { name: "FL Pull Ups", sets: 3, reps: "2-3", tip: "FL position se full pull", emoji: "💪" },
            { name: "FL to Inverted Hang", sets: 3, reps: "5", tip: "Rotation controlled karo", emoji: "🔄" },
            { name: "Ring Front Lever", sets: 3, reps: "max sec", tip: "Rings pe — ultimate challenge", emoji: "💍" },
            { name: "One Arm FL Drill", sets: 3, reps: "3 sec each", tip: "Future prep — lean to one arm", emoji: "☝️" },
          ]
        }
      ]
    },

    /* ── MUSCLE UP ── */
    muscleup: {
      phases: [
        {
          name: "Phase 1 — Pull & Push Base",
          weeks: "Week 1-4",
          emoji: "🔧",
          exercises: [
            { name: "Pull Ups", sets: 4, reps: "10+", tip: "Full ROM, dead hang start", emoji: "🔝" },
            { name: "Dips", sets: 4, reps: "12+", tip: "Full range, lockout top", emoji: "⬇️" },
            { name: "Chest to Bar Pull Ups", sets: 4, reps: "5", tip: "Chest bar se touch karo!", emoji: "💥" },
            { name: "Bar Dips", sets: 4, reps: "10", tip: "Bar pe dips — harder", emoji: "🏋️" },
            { name: "Negative Muscle Ups", sets: 5, reps: "3 slow", tip: "Top se slowly lower down", emoji: "⬇️" },
          ]
        },
        {
          name: "Phase 2 — Kipping MU",
          weeks: "Week 5-8",
          emoji: "🌀",
          exercises: [
            { name: "Kipping Swing Practice", sets: 5, reps: "10", tip: "Bar pe pendulum swing", emoji: "🌊" },
            { name: "Kipping Muscle Ups", sets: 6, reps: "singles", tip: "Hip drive use karo jump mein", emoji: "🔄" },
            { name: "False Grip Pull Ups", sets: 4, reps: "6", tip: "Wrist over bar — false grip!", emoji: "✊" },
            { name: "Transition Practice (Box)", sets: 5, reps: "5", tip: "Box pe simulate karo MU transition", emoji: "📦" },
            { name: "Ring Pull Ups", sets: 3, reps: "8", tip: "Ring instability builds strength", emoji: "💍" },
          ]
        },
        {
          name: "Phase 3 — Strict MU",
          weeks: "Month 3-8",
          emoji: "👑",
          exercises: [
            { name: "Strict Muscle Ups", sets: 5, reps: "singles", tip: "Zero kip — pure strength!", emoji: "💀" },
            { name: "Ring Muscle Ups", sets: 4, reps: "3-5", tip: "Rings pe — harder than bar", emoji: "💍" },
            { name: "Strict MU + Slow Dip", sets: 3, reps: "3", tip: "MU karo phir slow 5s dip", emoji: "⬇️" },
            { name: "L-Sit Muscle Up", sets: 3, reps: "2-3", tip: "MU + L-sit combo — elite!", emoji: "💺" },
            { name: "One Arm MU Drill", sets: 3, reps: "3 each", tip: "Assisted one arm transitions", emoji: "☝️" },
          ]
        }
      ]
    },

    /* ── PISTOL SQUAT ── */
    pistolsquat: {
      phases: [
        {
          name: "Phase 1 — Mobility & Strength",
          weeks: "Week 1-3",
          emoji: "🦵",
          exercises: [
            { name: "Ankle Circles", sets: 3, reps: "20 each", tip: "Dono directions, daily karo", emoji: "🔄" },
            { name: "Bodyweight Squats (Deep)", sets: 4, reps: "20", tip: "Full depth — heels neeche", emoji: "⬇️" },
            { name: "Box Step Downs", sets: 4, reps: "8 each", tip: "Box se slow single leg lower", emoji: "📦" },
            { name: "Assisted Pistol (TRX/Pole)", sets: 4, reps: "8 each", tip: "Support pakad ke full ROM", emoji: "🤝" },
            { name: "Cossack Squats", sets: 3, reps: "10 each", tip: "Side to side deep squats", emoji: "⚡" },
          ]
        },
        {
          name: "Phase 2 — Box Pistols",
          weeks: "Week 4-7",
          emoji: "📦",
          exercises: [
            { name: "Box Pistol Squats (High)", sets: 4, reps: "6 each", tip: "High box pe sit, single leg up", emoji: "📦" },
            { name: "Box Pistol Squats (Low)", sets: 4, reps: "6 each", tip: "Lower box — harder control", emoji: "⬇️" },
            { name: "Negative Pistol Squats", sets: 4, reps: "5 each (5 sec)", tip: "Slow lower — control", emoji: "🐌" },
            { name: "Single Leg Hip Bridge", sets: 3, reps: "12 each", tip: "Glute activation one leg", emoji: "🌉" },
            { name: "Hamstring Curls (Floor)", sets: 3, reps: "10", tip: "Feet slide pe, floor slide curls", emoji: "🦵" },
          ]
        },
        {
          name: "Phase 3 — Free Pistols",
          weeks: "Month 2-4",
          emoji: "🗡️",
          exercises: [
            { name: "Free Pistol Squats", sets: 5, reps: "5-8 each", tip: "No support — full pistol!", emoji: "🗡️" },
            { name: "Weighted Pistol Squats", sets: 3, reps: "5 each", tip: "Dumbell hold karo — harder", emoji: "🏋️" },
            { name: "Jump Pistol Squats", sets: 3, reps: "3 each", tip: "Bottom se explosive jump", emoji: "💥" },
            { name: "Shrimp Squat Attempts", sets: 3, reps: "3 each", tip: "Next level — rear foot bend", emoji: "🦐" },
            { name: "Dragon Squat", sets: 3, reps: "5 each", tip: "Rotation pistol variation", emoji: "🐉" },
          ]
        }
      ]
    },

    /* ── L-SIT ── */
    "l-sit": {
      phases: [
        {
          name: "Phase 1 — Hip Flexor & Tricep",
          weeks: "Week 1-3",
          emoji: "💪",
          exercises: [
            { name: "Tricep Dips", sets: 4, reps: "15", tip: "Lockout zaroori hai", emoji: "⬇️" },
            { name: "Leg Lifts (Floor)", sets: 3, reps: "15", tip: "Hands floor pe, legs raise", emoji: "🦵" },
            { name: "Tuck L-Sit Hold (Parallel Bars)", sets: 5, reps: "10 sec", tip: "Knees tuck karo chest tak", emoji: "🐛" },
            { name: "Hip Flexor Stretch", sets: 3, reps: "45 sec each", tip: "Kneeling lunge — deep stretch", emoji: "🧘" },
            { name: "Compression Work", sets: 4, reps: "10", tip: "Floor pe baithke legs raise", emoji: "💺" },
          ]
        },
        {
          name: "Phase 2 — L-Sit Hold",
          weeks: "Week 4-8",
          emoji: "💺",
          exercises: [
            { name: "L-Sit Hold (Bars)", sets: 6, reps: "5-15 sec", tip: "Legs straight — body L shape!", emoji: "💺" },
            { name: "L-Sit Hold (Floor)", sets: 5, reps: "5-10 sec", tip: "Floor pe harder — wrist strength", emoji: "🧱" },
            { name: "L-Sit Transitions", sets: 4, reps: "5", tip: "Tuck to L-sit to tuck", emoji: "🔄" },
            { name: "Ring L-Sit", sets: 4, reps: "5-8 sec", tip: "Rings pe — ultimate stability", emoji: "💍" },
            { name: "Straddle L-Sit", sets: 3, reps: "10 sec", tip: "Legs apart — easier variation", emoji: "✌️" },
          ]
        },
        {
          name: "Phase 3 — V-Sit Goal",
          weeks: "Month 3-6",
          emoji: "✌️",
          exercises: [
            { name: "L-Sit Extended Hold", sets: 5, reps: "30+ sec", tip: "Max time hold karo!", emoji: "⏱️" },
            { name: "V-Sit Attempts", sets: 5, reps: "3-5 sec", tip: "Legs 45+ degree upar!", emoji: "✌️" },
            { name: "L-Sit Pull Ups", sets: 3, reps: "5", tip: "L-sit mein pull up karo", emoji: "💪" },
            { name: "Manna Preparation", sets: 3, reps: "5 sec", tip: "Wrists back, legs higher", emoji: "🌙" },
            { name: "Straddle V-Sit", sets: 3, reps: "5 sec", tip: "Legs wide aur high — easier V", emoji: "🌟" },
          ]
        }
      ]
    },

    /* ── ONE ARM PULL UP ── */
    onearm_pull: {
      phases: [
        {
          name: "Phase 1 — Pull Volume",
          weeks: "Week 1-6",
          emoji: "💪",
          exercises: [
            { name: "Weighted Pull Ups", sets: 4, reps: "5", tip: "Belt pe weight add karo", emoji: "🏋️" },
            { name: "Typewriter Pull Ups", sets: 4, reps: "5 each", tip: "Top pe side to side travel", emoji: "✍️" },
            { name: "Archer Pull Ups", sets: 4, reps: "5 each", tip: "Ek haath pull, dusra extend", emoji: "🎯" },
            { name: "One Arm Dead Hang", sets: 3, reps: "15 sec each", tip: "Grip endurance build karo", emoji: "☝️" },
            { name: "Towel Pull Ups", sets: 3, reps: "6 each", tip: "Towel pe grip — harder!", emoji: "🧹" },
          ]
        },
        {
          name: "Phase 2 — Assisted OA",
          weeks: "Week 7-16",
          emoji: "🤝",
          exercises: [
            { name: "Assisted One Arm Pull Up (Band)", sets: 5, reps: "5 each", tip: "Band support lete lete reduce karo", emoji: "🎗️" },
            { name: "One Arm Negative (5 sec)", sets: 5, reps: "3 each", tip: "Slow lower — control!", emoji: "⬇️" },
            { name: "One Arm Lock-Off", sets: 4, reps: "5 sec each", tip: "Top position mein hold", emoji: "🔒" },
            { name: "Partial One Arm Pull", sets: 4, reps: "5 each", tip: "Half ROM — build step by step", emoji: "↕️" },
            { name: "Ring One Arm Rows", sets: 3, reps: "8 each", tip: "Rings pe one arm rows — easier entry", emoji: "💍" },
          ]
        },
        {
          name: "Phase 3 — Full OA Pull Up",
          weeks: "Month 6-18",
          emoji: "👑",
          exercises: [
            { name: "One Arm Pull Up (Free)", sets: 5, reps: "singles", tip: "Full ROM — king move!", emoji: "👑" },
            { name: "One Arm Chin Up", sets: 4, reps: "2-3 each", tip: "Underhand — slightly easier", emoji: "🙌" },
            { name: "One Arm MU Attempts", sets: 3, reps: "singles", tip: "Ultimate combo!", emoji: "💀" },
            { name: "Weighted OA Pull Up", sets: 3, reps: "2-3 each", tip: "Weight add karo — next level", emoji: "🏋️" },
            { name: "OA Flag Attempts", sets: 3, reps: "2-3 sec", tip: "One arm flag — elite of elite", emoji: "🚩" },
          ]
        }
      ]
    },

    /* ── GENERIC ANIME/LADY PHYSIQUE PLAN (dynamic from AI plan) ── */
    _anime_default: {
      phases: [
        {
          name: "Aaj ka Workout",
          weeks: "Today",
          emoji: "💪",
          exercises: [] // Will be filled from _currentPlan
        }
      ]
    }
  };

  /* Map cali skill IDs to plan keys */
  var SKILL_ID_MAP = {
    "handstand": "handstand",
    "humanflag": "humanflag",
    "human_flag": "humanflag",
    "frontlever": "frontlever",
    "frontlever_s": "frontlever",
    "planche": "planche",
    "planche_s": "planche",
    "muscleup": "muscleup",
    "muscleup_rings": "muscleup",
    "muscleup_str": "muscleup",
    "pistolsquat": "pistolsquat",
    "pistol": "pistolsquat",
    "l-sit": "l-sit",
    "l_sit": "l-sit",
    "lsit_s": "l-sit",
    "onearm_pull": "onearm_pull",
    "onearm_pu": "onearm_pull",
  };

  /* ──────────────────────────────────────────────────────────
     STORAGE HELPERS — Today's logs for home skill tracker
  ────────────────────────────────────────────────────────── */
  function todayKey() {
    return new Date().toISOString().slice(0, 10);
  }

  function getLogKey() {
    var user = window.S && window.S.user ? window.S.user.username : "guest";
    return "hsp_log_" + user + "_" + todayKey();
  }

  function getLogs() {
    try { return JSON.parse(localStorage.getItem(getLogKey())) || {}; } catch (e) { return {}; }
  }

  function saveLogs(data) {
    try { localStorage.setItem(getLogKey(), JSON.stringify(data)); } catch (e) {}
  }

  /* ──────────────────────────────────────────────────────────
     GET ACTIVE CHARACTER / SKILL
  ────────────────────────────────────────────────────────── */
  function getActiveSkill() {
    var sel = window._selectedPhysique;
    if (sel && sel.isCali) {
      return { type: "cali", char: sel };
    }
    var lsel = window._selectedLadyPhysique;
    if (lsel && lsel.id) {
      return { type: "lady", char: lsel };
    }
    if (sel && sel.id) {
      return { type: "anime", char: sel };
    }
    return null;
  }

  /* ──────────────────────────────────────────────────────────
     SAFE HTML ESCAPE
  ────────────────────────────────────────────────────────── */
  function esc(str) {
    return String(str || "")
      .replace(/&/g, "&amp;").replace(/</g, "&lt;")
      .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  /* ──────────────────────────────────────────────────────────
     RENDER: No skill selected state
  ────────────────────────────────────────────────────────── */
  function buildNoSkillHTML() {
    return '<div class="skill-plan-card-empty">' +
      '<div class="skill-plan-empty-skull">💀</div>' +
      '<div style="font-size:.88rem;font-weight:900;background:linear-gradient(135deg,#fff,#c4b5fd);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:6px;letter-spacing:.5px">Koi Skill Select Nahi!</div>' +
      '<div style="font-size:.7rem;color:rgba(196,181,253,0.6);margin-bottom:18px;line-height:1.6">Train section mein apna goal choose karo<br>Phir yahan tera personal AI plan ayega 🔥</div>' +
      '<button onclick="goPage(\'pgTrain\', document.querySelector(\'.bnav:nth-child(3)\'))" ' +
      'class="ai-cta-btn" style="max-width:240px;margin:0 auto;display:block">⚡ Train Section Jaao →</button>' +
      '</div>';
  }

  /* ──────────────────────────────────────────────────────────
     RENDER: Anime / Lady physique — uses AI plan if available
  ────────────────────────────────────────────────────────── */
  function buildAnimePlanHTML(char, type) {
    var color = char.color || "var(--accent)";
    var plan = window._currentPlan;
    var today = new Date().toDay ? new Date().toDay() : new Date().getDay();
    var logs = getLogs();

    var html = '<div style="margin-bottom:6px">';
    // Header
    html += '<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;padding:12px 14px;background:linear-gradient(135deg,rgba(255,255,255,.05),rgba(255,255,255,.02));border:1.5px solid ' + color + '33;border-radius:14px">';
    html += '<div style="font-size:2rem;filter:drop-shadow(0 0 8px ' + color + '88)">' + (char.emoji || "💀") + '</div>';
    html += '<div style="flex:1"><div style="font-size:.88rem;font-weight:900;color:' + color + '">' + esc(char.name) + '</div>';
    html += '<div style="font-size:.62rem;color:var(--muted)">' + esc(char.anime || "") + '</div></div>';
    html += '<button onclick="goPage(\'pgTrain\', document.querySelector(\'.bnav:nth-child(3)\'))" style="padding:6px 10px;background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:8px;color:var(--muted);font-size:.6rem;font-weight:700;cursor:pointer">🏋️ Train</button>';
    html += '</div>';

    if (!plan || !plan.days || !plan.days.length) {
      html += '<div style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:12px;padding:16px;text-align:center">';
      html += '<div style="font-size:1.4rem;margin-bottom:6px">📋</div>';
      html += '<div style="font-size:.76rem;font-weight:700;color:var(--text);margin-bottom:4px">AI Workout Plan nahi hai abhi</div>';
      html += '<div style="font-size:.64rem;color:var(--muted);margin-bottom:12px">Train section mein jaake plan generate karo!</div>';
      html += '<button onclick="window._tmOpenPlan && window._tmOpenPlan()" style="padding:9px 18px;background:linear-gradient(135deg,' + color + ',var(--accent2));border:none;border-radius:10px;color:#000;font-size:.74rem;font-weight:800;cursor:pointer">💀 Plan Generate Karo →</button>';
      html += '</div>';
    } else {
      // Show today's day from plan (cycle)
      var dayIndex = new Date().getDay() % plan.days.length;
      var dayData = plan.days[dayIndex];
      var exercises = dayData.exercises || [];

      html += '<div style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:12px;padding:12px 14px">';
      html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">';
      html += '<div style="font-size:.76rem;font-weight:800;color:var(--text)">📅 ' + esc(dayData.day) + '</div>';
      var doneCount = exercises.filter(function(ex, idx) { return logs["anime_" + idx]; }).length;
      html += '<div style="font-size:.62rem;color:' + color + ';background:' + color + '22;border:1px solid ' + color + '44;border-radius:20px;padding:3px 9px;font-weight:700">' + doneCount + '/' + exercises.length + ' done</div>';
      html += '</div>';

      exercises.forEach(function(ex, idx) {
        var key = "anime_" + idx;
        var isDone = !!logs[key];
        var setsLogged = logs[key + "_sets"] || "";
        var repsLogged = logs[key + "_reps"] || "";

        html += '<div id="hsp_exrow_' + idx + '" style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:' + (isDone ? "rgba(74,222,128,.08)" : "rgba(255,255,255,.03)") + ';border:1px solid ' + (isDone ? "rgba(74,222,128,.2)" : "rgba(255,255,255,.07)") + ';border-radius:10px;margin-bottom:6px">';
        html += '<div onclick="hspToggleEx(\'' + key + '\', ' + idx + ', \'anime\')" style="width:22px;height:22px;border-radius:50%;background:' + (isDone ? "#4ade80" : "rgba(255,255,255,.08)") + ';border:1.5px solid ' + (isDone ? "#4ade80" : "rgba(255,255,255,.15)") + ';display:flex;align-items:center;justify-content:center;font-size:.65rem;cursor:pointer;flex-shrink:0;color:#000;font-weight:900">' + (isDone ? "✓" : "") + '</div>';
        html += '<div style="flex:1;min-width:0">';
        html += '<div style="font-size:.74rem;font-weight:700;color:var(--text)">' + esc(ex.emoji || "💪") + " " + esc(ex.name) + '</div>';
        html += '<div style="font-size:.6rem;color:var(--muted)">' + ex.sets + ' sets × ' + esc(String(ex.reps || "")) + '</div>';
        html += '</div>';

        // Sets/Reps input fields
        html += '<div style="display:flex;gap:4px;align-items:center">';
        html += '<input id="hsp_sets_' + idx + '" type="number" min="0" max="20" placeholder="Sets" value="' + esc(String(setsLogged)) + '" ' +
          'style="width:42px;padding:4px 6px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);border-radius:7px;color:var(--text);font-size:.65rem;text-align:center" ' +
          'oninput="hspSaveLog(\'' + key + '\', ' + idx + ')" />';
        html += '<input id="hsp_reps_' + idx + '" type="text" placeholder="Reps" value="' + esc(String(repsLogged)) + '" ' +
          'style="width:46px;padding:4px 6px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);border-radius:7px;color:var(--text);font-size:.65rem;text-align:center" ' +
          'oninput="hspSaveLog(\'' + key + '\', ' + idx + ')" />';
        html += '</div>';
        html += '</div>';
      });

      html += '</div>';
    }

    html += '</div>';
    return html;
  }

  /* ──────────────────────────────────────────────────────────
     RENDER: Calisthenics Skill — phase-based plan
  ────────────────────────────────────────────────────────── */
  function buildCaliPlanHTML(char) {
    var color = char.color || "var(--accent)";
    var skillId = char.id || "";
    var planKey = SKILL_ID_MAP[skillId] || skillId;
    var plan = SKILL_PLANS[planKey];
    var logs = getLogs();

    // Active phase from localStorage
    var phaseKey = "hsp_phase_" + skillId;
    var activePhase = 0;
    try { activePhase = parseInt(localStorage.getItem(phaseKey) || "0") || 0; } catch (e) {}

    var html = '<div style="margin-bottom:6px">';

    // Header card
    html += '<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;padding:12px 14px;background:linear-gradient(135deg,rgba(255,255,255,.05),rgba(255,255,255,.02));border:1.5px solid ' + color + '33;border-radius:14px;position:relative;overflow:hidden">';
    html += '<div style="position:absolute;inset:0;background:radial-gradient(ellipse at 80% 20%,' + color + '14,transparent 70%);pointer-events:none"></div>';
    html += '<div style="font-size:2rem;filter:drop-shadow(0 0 10px ' + color + '88)">' + (char.emoji || "⚡") + '</div>';
    html += '<div style="flex:1;min-width:0">';
    html += '<div style="font-size:.9rem;font-weight:900;color:' + color + '">' + esc(char.name) + '</div>';
    html += '<div style="font-size:.6rem;color:var(--muted)">Calisthenics Skill • ' + esc(char.minTime || char.time || "") + '</div>';
    html += '</div>';
    html += '<button onclick="goPage(\'pgTrain\', document.querySelector(\'.bnav:nth-child(3)\'))" style="padding:6px 10px;background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:8px;color:var(--muted);font-size:.6rem;font-weight:700;cursor:pointer">🏋️ Train</button>';
    html += '</div>';

    if (!plan) {
      // No plan defined — show generic message
      html += '<div style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:12px;padding:14px;text-align:center">';
      html += '<div style="font-size:.76rem;color:var(--muted)">Is skill ka detailed plan aata hai! Train section mein plan generate karo 🔥</div>';
      html += '</div>';
      html += '</div>';
      return html;
    }

    // Phase tabs
    html += '<div style="display:flex;gap:5px;margin-bottom:10px;overflow-x:auto;padding-bottom:2px">';
    plan.phases.forEach(function(phase, pi) {
      var isActive = pi === activePhase;
      html += '<button onclick="hspSetPhase(\'' + skillId + '\', ' + pi + ')" style="flex-shrink:0;padding:6px 11px;background:' + (isActive ? "linear-gradient(135deg," + color + ",var(--accent2))" : "rgba(255,255,255,.05)") + ';border:1px solid ' + (isActive ? color : "rgba(255,255,255,.1)") + ';border-radius:20px;color:' + (isActive ? "#000" : "var(--muted)") + ';font-size:.6rem;font-weight:800;cursor:pointer;white-space:nowrap">' + phase.emoji + " " + esc(phase.name.split(" — ")[0]) + '</button>';
    });
    html += '</div>';

    // Active phase content
    var phase = plan.phases[activePhase];
    if (!phase) { html += '</div>'; return html; }

    html += '<div style="background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:14px;padding:12px 14px">';
    // Phase header
    html += '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">';
    html += '<div>';
    html += '<div style="font-size:.8rem;font-weight:800;color:var(--text)">' + phase.emoji + " " + esc(phase.name) + '</div>';
    html += '<div style="font-size:.6rem;color:var(--muted);margin-top:1px">📅 ' + esc(phase.weeks) + '</div>';
    html += '</div>';

    var totalDone = 0;
    phase.exercises.forEach(function(ex, idx) {
      if (logs[planKey + "_" + activePhase + "_" + idx]) totalDone++;
    });
    html += '<div style="font-size:.62rem;color:' + color + ';background:' + color + '22;border:1px solid ' + color + '44;border-radius:20px;padding:3px 9px;font-weight:700">' + totalDone + '/' + phase.exercises.length + '</div>';
    html += '</div>';

    // Exercises
    phase.exercises.forEach(function(ex, idx) {
      var key = planKey + "_" + activePhase + "_" + idx;
      var isDone = !!logs[key];
      var setsLogged = logs[key + "_sets"] || "";
      var repsLogged = logs[key + "_reps"] || "";

      html += '<div id="hsp_exrow_' + idx + '" style="padding:9px 11px;background:' + (isDone ? "rgba(74,222,128,.07)" : "rgba(255,255,255,.02)") + ';border:1px solid ' + (isDone ? "rgba(74,222,128,.2)" : "rgba(255,255,255,.06)") + ';border-radius:10px;margin-bottom:6px">';
      // Top row
      html += '<div style="display:flex;align-items:center;gap:8px;margin-bottom:' + (isDone ? "0" : "7") + 'px">';
      html += '<div onclick="hspToggleEx(\'' + key + '\', ' + idx + ', \'cali\')" style="width:24px;height:24px;border-radius:50%;background:' + (isDone ? "#4ade80" : "rgba(255,255,255,.06)") + ';border:1.5px solid ' + (isDone ? "#4ade80" : color + "55") + ';display:flex;align-items:center;justify-content:center;font-size:.65rem;cursor:pointer;flex-shrink:0;color:#000;font-weight:900;transition:.2s">' + (isDone ? "✓" : "") + '</div>';
      html += '<div style="flex:1;min-width:0">';
      html += '<div style="font-size:.76rem;font-weight:700;color:var(--text)">' + esc(ex.emoji) + " " + esc(ex.name) + '</div>';
      html += '<div style="font-size:.58rem;color:var(--muted)">' + ex.sets + ' sets × ' + esc(String(ex.reps)) + (ex.tip ? ' &nbsp;·&nbsp; 💡 ' + esc(ex.tip) : '') + '</div>';
      html += '</div>';
      html += '</div>';

      // Sets/Reps tracker (always visible)
      html += '<div style="display:flex;gap:6px;align-items:center;margin-top:6px">';
      html += '<div style="font-size:.58rem;color:var(--muted);flex-shrink:0">Log:</div>';
      html += '<div style="display:flex;flex-direction:column;align-items:center">';
      html += '<input id="hsp_sets_' + idx + '" type="number" min="0" max="50" placeholder="0" value="' + esc(String(setsLogged)) + '" ' +
        'style="width:44px;padding:5px 4px;background:rgba(255,255,255,.07);border:1px solid ' + color + '44;border-radius:7px;color:var(--text);font-size:.7rem;text-align:center;font-weight:700" ' +
        'oninput="hspSaveLog(\'' + key + '\', ' + idx + ')" />';
      html += '<div style="font-size:.45rem;color:var(--muted);margin-top:2px">SETS</div>';
      html += '</div>';
      html += '<div style="color:var(--muted);font-size:.7rem">×</div>';
      html += '<div style="display:flex;flex-direction:column;align-items:center">';
      html += '<input id="hsp_reps_' + idx + '" type="text" placeholder="—" value="' + esc(String(repsLogged)) + '" ' +
        'style="width:52px;padding:5px 4px;background:rgba(255,255,255,.07);border:1px solid ' + color + '44;border-radius:7px;color:var(--text);font-size:.7rem;text-align:center;font-weight:700" ' +
        'oninput="hspSaveLog(\'' + key + '\', ' + idx + ')" />';
      html += '<div style="font-size:.45rem;color:var(--muted);margin-top:2px">REPS/TIME</div>';
      html += '</div>';
      if (setsLogged) {
        html += '<div onclick="hspToggleEx(\'' + key + '\', ' + idx + ', \'cali\')" style="padding:5px 10px;background:' + (isDone ? "#4ade80" : color) + ';border:none;border-radius:8px;color:#000;font-size:.62rem;font-weight:800;cursor:pointer;flex-shrink:0">' + (isDone ? "✓ Done" : "Mark Done") + '</div>';
      }
      html += '</div>';
      html += '</div>';
    });

    html += '</div>';
    html += '</div>';
    return html;
  }

  /* ──────────────────────────────────────────────────────────
     MAIN RENDER FUNCTION
  ────────────────────────────────────────────────────────── */
  function renderHomeSkillPlan() {
    var container = document.getElementById("homeSkillPlanSection");
    if (!container) return;

    var active = getActiveSkill();

    var titleHTML = '<div class="sec-title" style="margin-top:2px">💪 Skill Plan</div>';

    if (!active) {
      container.innerHTML = titleHTML + buildNoSkillHTML();
      return;
    }

    var planHTML = "";
    if (active.type === "cali") {
      planHTML = buildCaliPlanHTML(active.char);
    } else {
      planHTML = buildAnimePlanHTML(active.char, active.type);
    }

    container.innerHTML = titleHTML + planHTML;
  }

  /* ──────────────────────────────────────────────────────────
     GLOBAL ACTION HANDLERS (called from inline HTML)
  ────────────────────────────────────────────────────────── */

  /* Toggle exercise done state */
  window.hspToggleEx = function(key, idx, mode) {
    var logs = getLogs();
    var isDone = !logs[key];
    logs[key] = isDone ? true : false;
    if (!isDone) { delete logs[key]; }
    saveLogs(logs);

    // Update score if we just marked done
    if (isDone && typeof window.updateScore === "function") {
      window.updateScore();
    }

    renderHomeSkillPlan();
  };

  /* Save sets/reps log */
  window.hspSaveLog = function(key, idx) {
    var setsEl = document.getElementById("hsp_sets_" + idx);
    var repsEl = document.getElementById("hsp_reps_" + idx);
    var logs = getLogs();
    if (setsEl) logs[key + "_sets"] = setsEl.value;
    if (repsEl) logs[key + "_reps"] = repsEl.value;
    saveLogs(logs);
  };

  /* Switch phase */
  window.hspSetPhase = function(skillId, phaseIdx) {
    var phaseKey = "hsp_phase_" + skillId;
    try { localStorage.setItem(phaseKey, String(phaseIdx)); } catch (e) {}
    renderHomeSkillPlan();
  };

  /* ──────────────────────────────────────────────────────────
     HOOK INTO goPage & app boot — re-render on home nav
  ────────────────────────────────────────────────────────── */
  function hookGoPage() {
    var _orig = window.goPage;
    if (!_orig || window._hspGoPagePatched) return;
    window._hspGoPagePatched = true;
    window.goPage = function(page, navEl) {
      _orig(page, navEl);
      if (page === "pgHome") {
        setTimeout(renderHomeSkillPlan, 80);
      }
    };
  }

  /* Re-render when skill changes */
  var _origSaveSelectedPhysique = window.saveSelectedPhysique;
  window.saveSelectedPhysique = function(char) {
    if (_origSaveSelectedPhysique) _origSaveSelectedPhysique(char);
    setTimeout(renderHomeSkillPlan, 150);
  };

  /* Hook lady physique save */
  function hookLadySave() {
    var _orig = window.saveLadyPhysique || window.saveSelectedLadyPhysique;
    if (_orig && !window._hspLadyPatched) {
      window._hspLadyPatched = true;
      window.saveLadyPhysique = window.saveSelectedLadyPhysique = function(char) {
        _orig(char);
        setTimeout(renderHomeSkillPlan, 150);
      };
    }
  }

  /* ──────────────────────────────────────────────────────────
     INIT
  ────────────────────────────────────────────────────────── */
  function init() {
    hookGoPage();
    hookLadySave();

    // Load saved physiques if not already loaded
    if (!window._selectedPhysique && typeof window.loadSavedPhysique === "function") {
      window.loadSavedPhysique();
    }
    if (!window._selectedLadyPhysique && typeof window.loadSavedLadyPhysique === "function") {
      window.loadSavedLadyPhysique();
    }

    renderHomeSkillPlan();
    console.log("💀 Home Skill Plan v1.0 loaded!");
  }

  /* Run after DOM + other scripts are ready */
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function() { setTimeout(init, 350); });
  } else {
    setTimeout(init, 350);
  }

  /* Expose render for manual calls */
  window.renderHomeSkillPlan = renderHomeSkillPlan;

})();

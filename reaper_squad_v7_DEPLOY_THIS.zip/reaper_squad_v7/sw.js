/* ============================================
   💀 REAPER SQUAD — Service Worker v3.3
   Fixed: '/' → '/index.html' (CF Pages redirect),
          safe fetch+put, skip missing files gracefully
   ============================================ */

const CACHE_NAME = 'reaper-squad-v14';
const STATIC_CACHE = 'reaper-static-v14';
const DYNAMIC_CACHE = 'reaper-dynamic-v14';

// Use absolute paths — ./ fails when SW scope != page scope on mobile.
// Use '/index.html' not '/' — Cloudflare Pages returns a redirect for '/'
// which makes res.ok === false and the cache.put is silently skipped.
const CORE_FILES = [
  '/index.html',
  '/manifest.json',
  '/css/main.css',
  '/js/cloud_sync.js',
  '/js/script.js',
  '/js/train_mode.js',
  '/js/home_skill_plan.js',
  '/js/features/survey-gate.js',
  '/js/features/stub-compat.js',
  '/js/features/lady-select.js',
  '/js/features/settings-panel.js',
  '/js/data/lady-physiques.js',
  '/icon-192.png',
  '/favicon.svg'
];

// ── INSTALL ──────────────────────────────────
self.addEventListener('install', event => {
  console.log('💀 Reaper SW v3.3: Installing...');
  event.waitUntil(
    caches.open(STATIC_CACHE).then(cache => {
      // Fetch each file individually with no-cache headers so Cloudflare
      // delivers the real asset, not a redirect or edge-cached stale copy.
      // Promise.allSettled means ONE missing file never aborts the install.
      return Promise.allSettled(
        CORE_FILES.map(url =>
          fetch(new Request(url, {
            cache: 'no-store',
            credentials: 'same-origin'
          })).then(res => {
            if (res.ok) {
              // cache.put never throws on a valid response
              return cache.put(url, res);
            }
            // Non-ok (redirect, 404, etc.) — log and skip gracefully
            console.warn('SW: Skipped (HTTP ' + res.status + '):', url);
          }).catch(err => {
            // Network error (offline during install, blocked, etc.) — skip
            console.warn('SW: Could not fetch:', url, err.message);
          })
        )
      );
    }).then(() => {
      console.log('💀 Reaper SW: Core files cached (best effort)!');
      return self.skipWaiting();
    })
  );
});

// ── ACTIVATE ─────────────────────────────────
self.addEventListener('activate', event => {
  console.log('💀 Reaper SW: Activating...');
  event.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(
        keys
          .filter(key => key !== STATIC_CACHE && key !== DYNAMIC_CACHE)
          .map(key => {
            console.log('💀 Reaper SW: Deleting old cache:', key);
            return caches.delete(key);
          })
      );
    }).then(() => self.clients.claim())
  );
});

// ── FETCH ─────────────────────────────────────
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Skip non-GET, chrome-extension, and data URLs
  if (event.request.method !== 'GET') return;
  if (url.protocol === 'chrome-extension:') return;
  if (url.protocol === 'data:') return;

  // Skip all external/cross-origin requests
  if (url.hostname !== self.location.hostname) return;

  // Skip HTML navigation — let Cloudflare Pages handle directly
  const acceptHeader = event.request.headers.get('accept') || '';
  if (event.request.mode === 'navigate' || acceptHeader.includes('text/html')) return;

  // Skip survey.html
  if (url.pathname === '/survey.html' || url.pathname === '/survey') return;

  // Network first for API calls
  if (
    url.hostname.includes('supabase') ||
    url.hostname.includes('anthropic') ||
    url.hostname.includes('groq') ||
    url.pathname.includes('/auth/') ||
    url.pathname.includes('/rest/v1/')
  ) {
    event.respondWith(
      fetch(event.request).catch(() => {
        return new Response(JSON.stringify({ error: 'offline' }), {
          status: 503,
          headers: { 'Content-Type': 'application/json' }
        });
      })
    );
    return;
  }

  // Cache first for static assets, network fallback
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;

      return fetch(event.request).then(response => {
        if (!response || response.status !== 200 || response.type === 'opaque') {
          return response;
        }
        const clone = response.clone();
        caches.open(DYNAMIC_CACHE).then(cache => cache.put(event.request, clone));
        return response;
      }).catch(() => {
        if (acceptHeader.includes('text/html')) {
          return caches.match('/index.html') || caches.match('/');
        }
        return new Response('', { status: 404, statusText: 'Not Found' });
      });
    })
  );
});

// ── PUSH NOTIFICATIONS ────────────────────────
self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {};
  const title = data.title || '💀 Reaper Squad';
  const options = {
    body: data.body || 'Uth bhai, grind time hai!',
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    vibrate: [200, 100, 200],
    data: { url: data.url || '/' },
    actions: [{ action: 'open', title: '🔥 Open App' }]
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const url = event.notification.data.url || '/';
  event.waitUntil(clients.openWindow(url));
});

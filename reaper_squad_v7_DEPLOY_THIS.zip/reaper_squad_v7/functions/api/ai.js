// Cloudflare Pages Function: /api/ai
// Routes all AI API calls server-side. GROQ_KEY and ANTHROPIC_KEY are
// set as encrypted environment variables in the Cloudflare Pages dashboard.

const ALLOWED_ORIGINS = [
  'https://reapersquad.pages.dev',   // replace with your actual domain
];

const RATE_LIMIT = new Map(); // in-memory; use KV for multi-instance

function rateLimitCheck(ip) {
  const now = Date.now();
  const window = 60_000; // 1 minute
  const maxReq = 20;
  const entry = RATE_LIMIT.get(ip) || { count: 0, start: now };
  if (now - entry.start > window) {
    RATE_LIMIT.set(ip, { count: 1, start: now });
    return false;
  }
  if (entry.count >= maxReq) return true; // blocked
  entry.count++;
  RATE_LIMIT.set(ip, entry);
  return false;
}

export async function onRequestPost(context) {
  const { request, env } = context;
  const origin = request.headers.get('Origin') || '';

  // CORS: only allow listed origins
  if (!ALLOWED_ORIGINS.includes(origin)) {
    return new Response('Forbidden', { status: 403 });
  }

  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  if (rateLimitCheck(ip)) {
    return new Response(JSON.stringify({ error: 'Rate limit exceeded. Wait 1 minute.' }), {
      status: 429,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
    });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return new Response('Bad request', { status: 400 });
  }

  const { provider, model, messages, system, max_tokens } = body;

  // Whitelist allowed models only
  const GROQ_MODELS = ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'gemma2-9b-it'];
  const CLAUDE_MODELS = ['claude-sonnet-4-20250514'];

  const corsHeaders = {
    'Access-Control-Allow-Origin': origin,
    'Content-Type': 'application/json',
  };

  try {
    if (provider === 'groq') {
      if (!GROQ_MODELS.includes(model)) {
        return new Response(JSON.stringify({ error: 'Model not allowed' }), { status: 400, headers: corsHeaders });
      }
      const groqResp = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${env.GROQ_KEY}`,
        },
        body: JSON.stringify({ model, messages, max_tokens: Math.min(max_tokens || 1000, 2000) }),
      });
      const data = await groqResp.json();
      return new Response(JSON.stringify(data), { status: groqResp.status, headers: corsHeaders });

    } else if (provider === 'anthropic') {
      if (!CLAUDE_MODELS.includes(model)) {
        return new Response(JSON.stringify({ error: 'Model not allowed' }), { status: 400, headers: corsHeaders });
      }
      const anthResp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'anthropic-version': '2023-06-01',
          'x-api-key': env.ANTHROPIC_KEY,
        },
        body: JSON.stringify({
          model,
          system,
          messages,
          max_tokens: Math.min(max_tokens || 1200, 2000),
        }),
      });
      const data = await anthResp.json();
      return new Response(JSON.stringify(data), { status: anthResp.status, headers: corsHeaders });

    } else {
      return new Response(JSON.stringify({ error: 'Unknown provider' }), { status: 400, headers: corsHeaders });
    }
  } catch (err) {
    return new Response(JSON.stringify({ error: 'Upstream error' }), { status: 502, headers: corsHeaders });
  }
}

// Handle preflight
export async function onRequestOptions(context) {
  const origin = context.request.headers.get('Origin') || '';
  if (!ALLOWED_ORIGINS.includes(origin)) return new Response('Forbidden', { status: 403 });
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age': '86400',
    },
  });
}

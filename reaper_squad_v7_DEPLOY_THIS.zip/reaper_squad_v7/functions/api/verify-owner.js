// Cloudflare Pages Function: /api/verify-owner
// Called once at login to verify owner status server-side.
// OWNER_USERNAME is set as an encrypted env var in the CF Pages dashboard.

const ALLOWED_ORIGINS = [
  'https://reapersquad.pages.dev', // replace with your actual domain
];

export async function onRequestPost(context) {
  const { request, env } = context;
  const origin = request.headers.get('Origin') || '';

  if (!ALLOWED_ORIGINS.includes(origin)) {
    return new Response('Forbidden', { status: 403 });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return new Response('Bad request', { status: 400 });
  }

  const { username } = body || {};
  if (!username || typeof username !== 'string') {
    return new Response(JSON.stringify({ isOwner: false }), {
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
    });
  }

  const ownerUsername = env.OWNER_USERNAME || '';
  const isOwner = username.trim().toLowerCase() === ownerUsername.trim().toLowerCase();

  return new Response(JSON.stringify({ isOwner }), {
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
  });
}

export async function onRequestOptions(context) {
  const origin = context.request.headers.get('Origin') || '';
  if (!ALLOWED_ORIGINS.includes(origin)) return new Response('Forbidden', { status: 403 });
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}

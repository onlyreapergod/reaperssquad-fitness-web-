# Reaper Squad — Phase 2 Security Audit

**Migration:** Phase 1 (anon-key hardened) → Phase 2 (Supabase Auth + auth.uid() RLS)
**Date:** June 2026

> **Integration note (added when this audit package was merged into the
> reaper_squad_v12_fixed project):** the SQL and code below describe the
> audit's *original* recommendations. The actual files added to this repo
> (`supabase/phase2_001_auth_rls.sql`, `supabase/phase2_002_enforce_not_null.sql`,
> `functions/api/kick-user.js`, `js/auth/auth-supabase.js`) were adapted to
> match this project's real schema and Cloudflare Pages (not Supabase Edge
> Functions) deployment — see the comments at the top of each file for exact
> differences (e.g. `kicked_users` PK is `username` not `username+squad_code`,
> `squad_chat` uses a `ts` BIGINT column not `created_at`, `user_blobs` uses
> `blob_value` not `value`). **None of script.js's actual login/signup/kick UI
> has been switched over to this yet** — see `SECURITY_README.md` → "Phase 2"
> for what's been wired in vs. what's still a deliberate manual step.
>
> **Migration chain / execution order (`supabase/`):** run in filename order —
> `phase2_001` → `phase2_002` → `phase2_003` → `phase2_004` → `phase2_010` →
> `phase2_011` → `phase2_012` → `phase2_013` → `phase2_014` →
> `phase2_017_reaper_users_recovery_FINAL.sql`. `phase2_015_schema_recovery.sql`
> has been removed from the chain — `phase2_017` supersedes it and must be used
> instead (see "Phase 2 Patch — phase2_017" below for why).

---

## Summary

| Table         | Phase 1 Risk Level | Phase 2 Risk Level |
|---------------|-------------------|-------------------|
| reaper_users  | HIGH              | LOW               |
| daily_scores  | HIGH              | LOW               |
| squad_chat    | HIGH              | LOW               |
| kicked_users  | HIGH              | LOW               |
| user_blobs    | HIGH              | LOW               |

---

## Finding-by-Finding Audit

---

### F-01 · reaper_users: USING(true) on UPDATE allowed updating any user's row
**Phase 1 fix:** `USING(length(username) >= 1)` — marginally better, still exploitable.
**Phase 2 fix:** `USING(auth.uid() = user_id)` — cryptographically bound to session token.
**STATUS: PASS** — A user can only UPDATE their own row. Bypassing this requires a valid stolen JWT.

---

### F-02 · reaper_users: is_owner self-escalation
**Phase 1 fix:** `WITH CHECK(is_owner = FALSE)` — blocks escalation but any row's value must be false, not the row-at-rest value.
**Phase 2 fix:** `WITH CHECK(is_owner = (SELECT is_owner FROM reaper_users WHERE user_id = auth.uid()))` — enforces the value cannot change from whatever the DB already holds. service_role is the only path to change it.
**STATUS: PASS** — Self-escalation to owner blocked at RLS layer and server trigger.

---

### F-03 · reaper_users: suspended flag self-clearance
**Phase 1 fix:** `WITH CHECK(suspended = FALSE)` — prevents clearing own suspension, but is a static check, not a "preserve current value" check.
**Phase 2 fix:** Same subquery pattern as is_owner — value is frozen to whatever the DB holds; service_role required to change it.
**STATUS: PASS**

---

### F-04 · reaper_users: Missing DELETE policy (users could be hard-deleted)
**Phase 1 fix:** No DELETE policy created for anon → denied.
**Phase 2 fix:** No DELETE policy for authenticated → denied. service_role only.
**STATUS: PASS**

---

### F-05 · daily_scores: Any anon could update any user's score (USING(true))
**Phase 1 fix:** `USING(length(username) >= 1)` — still exploitable by any anon knowing a username.
**Phase 2 fix:** `USING(auth.uid() = user_id)` + trigger enforces user_id on insert.
**STATUS: PASS** — Score row ownership is now cryptographically enforced.

---

### F-06 · daily_scores: Missing DELETE policy
**Phase 1 fix:** No DELETE policy for anon → denied.
**Phase 2 fix:** No DELETE policy for authenticated → denied. Scores are permanent records; service_role required.
**STATUS: PASS**

---

### F-07 · squad_chat: Any anon could delete any user's messages (DELETE USING(true))
**Phase 1 fix:** `USING(length(username) >= 1)` — still exploitable; any anon can delete any message.
**Phase 2 fix:** `USING(auth.uid() = user_id)` — user can only delete their own messages.
**STATUS: PASS** — True per-user message ownership enforced.

---

### F-08 · squad_chat: No UPDATE policy (keep denied)
**Phase 1 status:** No policy = denied. Correct.
**Phase 2 status:** No policy = denied. Correct.
**STATUS: PASS** — Editing chat messages is not supported by design.

---

### F-09 · kicked_users: INSERT/UPDATE/DELETE all had WITH CHECK(true) / USING(true)
**Phase 1 fix:** Basic length checks, owner verification pushed to edge layer with no enforcement in DB.
**Phase 2 fix:** Zero RLS policies for INSERT/UPDATE/DELETE — only service_role (via edge function `kick-user/index.ts`) can touch this table. anon and authenticated are denied by absence of policy. Caller identity is verified via JWT + is_owner check inside the edge function before any write.
**STATUS: PASS** — Kick management is now fully server-side with identity verification.

---

### F-10 · user_blobs: UPDATE/DELETE USING(true) — any anon could overwrite/delete any blob
**Phase 1 fix:** `USING(length(username) >= 1)` — still exploitable.
**Phase 2 fix:** All four operations gated by `auth.uid() = user_id`. SELECT also scoped to own blobs only (was public SELECT in Phase 1 — this is a security improvement beyond the original audit).
**STATUS: PASS** — Blob data is private to the owning user. No cross-user read or write possible.

---

## Additional Improvements (Beyond Original Audit)

### A-01 · user_blobs SELECT was public (SELECT TO anon USING(true) — Phase 1)
Phase 1 left blobs readable by all anon users. Phase 2 changes to `SELECT TO authenticated USING(auth.uid() = user_id)`. Workout plans and profile data are now private.
**STATUS: FIXED (bonus)**

### A-02 · anon role retains INSERT/UPDATE/DELETE grants at table level
Phase 1 only used RLS to block writes — it did not REVOKE the underlying grants. An attacker who found a RLS policy misconfiguration could still attempt writes.
Phase 2 explicitly runs `REVOKE INSERT, UPDATE, DELETE ... FROM anon` on all five tables.
**STATUS: FIXED (bonus)**

### A-03 · Duplicate score rows per (user, date) possible
No unique constraint existed. Phase 2 adds `UNIQUE(user_id, date)` on daily_scores.
**STATUS: FIXED (bonus)**

### A-04 · client-side username trust
The old flow accepted `username` from client state (e.g., localStorage or component state) in INSERT payloads. The new auth.js `sendChatMessage` fetches username from the DB using the authenticated session before inserting — it is never read from the client.
**STATUS: FIXED (bonus)**

---

## Remaining Considerations

### R-01 · Backfill gap: existing users without auth.users rows
Any `reaper_users` row that has no matching `auth.users` entry will have `user_id = NULL` after the backfill in Step 3. These users cannot log in until they go through a password-reset / re-registration flow. Suggested approach: send a re-registration email to all users whose `user_id` remains NULL after the backfill. Track with:
```sql
SELECT username FROM reaper_users WHERE user_id IS NULL;
```

### R-02 · JWT secret rotation
Phase 2 RLS relies entirely on JWT validity. Ensure `SUPABASE_JWT_SECRET` is rotated and not exposed in any client bundle or public repository.

### R-03 · Service role key exposure
The `kick-user` edge function uses `SUPABASE_SERVICE_ROLE_KEY`. Confirm it is set only as a Supabase secret (`supabase secrets set SUPABASE_SERVICE_ROLE_KEY=...`) and never shipped to the client.

### R-04 · squad_code ownership on kicked_users
Phase 2 verifies the kicking owner's `squad_code` against the target, but if a user is in multiple squads this needs expansion. Currently assumes one squad per user.

### R-05 · NOT NULL enforcement (migration 002)
Do not run `002_enforce_not_null.sql` until all existing users are backfilled and the new auth flow is live. Running it prematurely will break existing sessions.

---

## Deployment Order

```
1. Run migrations/001_phase2_supabase_auth.sql
2. Verify backfill coverage (queries at bottom of 001)
3. Deploy lib/auth.js (replace all existing auth calls)
4. Deploy supabase/functions/kick-user/index.ts
5. Set SUPABASE_SERVICE_ROLE_KEY secret:
     supabase secrets set SUPABASE_SERVICE_ROLE_KEY=<your key>
6. Test signup → score insert → chat → blob upsert → kick in staging
7. Run migrations/002_enforce_not_null.sql
8. Set is_owner via service_role for squad owner:
     UPDATE reaper_users SET is_owner = TRUE WHERE username = '<owner>';
   (from Supabase dashboard SQL editor, not from client)
```

---

## Phase 2 Patch — phase2_010_final_patch.sql

Added June 2026. Supersedes `phase2_009_final_patch.sql` entirely.

**What it does (in order):**

- **F0** — Pre-flight guard: aborts if any target index exists but is marked INVALID, and validates that `daily_scores_user_id_date_unique_idx` is non-partial before attempting constraint promotion.
- **F1** — Adds `daily_scores_pts_range_check` (`pts >= 0 AND pts <= 10`) at the storage layer via `NOT VALID` + `VALIDATE`. Applies to `service_role` too — not bypassable via RLS.
- **F2** — Acquires session-level advisory lock `(42, 1)` and immediately self-checks that it is visible on the *current* backend pid. Aborts with a clear error if a transaction-mode connection pooler (PgBouncer/Supavisor) is detected.
- **F3** — Creates and idempotently tops-up two backup tables before any delete: `daily_scores_dupes_non_null_backup_p2009` (duplicate rows keyed by `user_id, date`) and `daily_scores_dupes_null_backup_p2009` (legacy rows keyed by `username, date`). Safe to re-run; only inserts rows not already in the backup.
- **F4** — Deduplicates `daily_scores` for both `user_id IS NOT NULL` (keeps highest `pts`) and `user_id IS NULL` rows. Each runs in its own autocommit block.
- **F5** — Releases the advisory lock immediately after dedup, *before* index builds, so lock window is short.
- **F6** — Creates `daily_scores_user_id_date_unique_idx` (non-partial, promoted to a `pg_constraint` entry) and `daily_scores_username_date_legacy_unique_idx` (partial, `WHERE user_id IS NULL`) using `CREATE UNIQUE INDEX CONCURRENTLY IF NOT EXISTS`. Validates both with deterministic `pg_index`/`pg_class` checks.
- **F7** — Replaces `scores_insert_own` and `scores_update_own` RLS policies. `WITH CHECK` now enforces `auth.uid() = user_id`, `pts` range, date format + recency window, and that submitted `username` matches the auth session's username in `reaper_users` (closes the spoofing vector from FIX-6).

**Key fixes over phase2_009:**

- FIX-8 (Critical): Backup gap on retry — backup is always topped-up before each delete, not skipped if table exists.
- FIX-9 (Critical): Advisory lock is released before `CONCURRENTLY` index builds, so it never stalls application writers for the duration of long index builds.
- FIX-10 (High): Rollback plan no longer includes phantom steps referencing `reaper_users_dupes_backup_phase2_007`, which this patch doesn't create or depend on.
- FIX-11 (Medium): Self-check aborts immediately if a transaction-mode pooler is detected.

**Run requirements:**

- Direct or session-mode database connection (not PgBouncer/Supavisor transaction-mode pooling)
- `autocommit ON` (psql `-f` or Supabase SQL Editor — both default to this)
- Run after `phase2_008_audit_fixes_v2` completes (or standalone on a fresh DB)

**Rollback:** See commented `R1–R6` block at the bottom of the file. Never touches `reaper_users`.

---

## Phase 2 Patch — phase2_017_reaper_users_recovery_FINAL.sql

Added July 2026. Runs last in the chain, after `phase2_014_db_health_security_perf.sql`.

**Supersedes:** `phase2_015_schema_recovery.sql`, which has been **removed from this
repo** and must not be run. `phase2_017_reaper_users_recovery_FINAL.sql` is a strict
superset of it — same `reaper_users` column/constraint/RLS/trigger recovery, plus
one correctness fix (below) — so keeping both around would only invite someone to
run the stale one by mistake.

**What it does:** fixes the Google Login 400-during-profile-fetch bug by adding
every `reaper_users` column `getMyProfile()` already queries (`ADD COLUMN IF NOT
EXISTS` only — nothing is dropped or retyped), guarded UNIQUE constraints on
`username`/`user_id`, the `auth.uid()`-based RLS policies for `reaper_users`, the
`user_id` auto-populate trigger, and — only if `daily_scores.user_id` already
exists — the server-computed `total_xp`/`streak`/`rank`/`rank_xp` trigger.

**FIX-016** (the one behavioral change vs. the removed `phase2_015`): restores
`compute_mission_bonus()` to the sargable TEXT-comparison date filter
(`date >= (CURRENT_DATE - 29)::TEXT ...`) that `phase2_014` (Step P2) deliberately
switched to for index use on `idx_daily_scores_date`. `phase2_015` had re-declared
that function with the older `date::DATE BETWEEN ...` form, which would silently
undo `phase2_014`'s P2 fix if run afterward — the normal, documented order. This
is fixed in `phase2_017`, making it safe to run at any point in the chain relative
to `phase2_014`.

**Does not touch:** `daily_scores`, `squad_chat`, `kicked_users`, or `user_blobs`
structure/policies, and does not enforce `user_id NOT NULL` on `reaper_users`
(still deferred to `phase2_002_enforce_not_null.sql`, run only after backfill is
verified complete).

**Run requirements:**

- Supabase SQL Editor or `psql -f`, autocommit ON.
- Safe to re-run — every step is `IF NOT EXISTS` / `CREATE OR REPLACE` guarded.
- Before running on production, verify the actual current `reaper_users` column
  list per the AUDIT NOTE at the top of the file itself.

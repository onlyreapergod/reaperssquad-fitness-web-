# admin/

No standalone client-side admin module currently exists. Admin/owner logic
(isOwner(), kick handling) is embedded inside core/script.js, auth/auth-supabase.js,
data-layer/cloud_sync.js, and core/patches/security-patch.js. The only dedicated
admin surface is functions/api/kick-user.js and functions/api/verify-owner.js,
which remain in functions/api/ because Cloudflare Pages Functions route by file
path (moving them would change a live API endpoint). This folder is reserved for
a future extraction of that logic into its own module.

/* ═══════════════════════════════════════════════════════════════
   REAPER SQUAD — PREMIUM ANIMATIONS
   Exact match to reference screenshot quality
═══════════════════════════════════════════════════════════════ */
(function() {
  'use strict';

  /* ── FIX SCORE RING SVG VIEWBOX & STROKE ──
     Reference shows large ring (~150px), thick stroke
     viewBox "0 0 96 96" with r=44 → circumference = 2π×44 = 276.46
     stroke-width should be visually thick = use 9 in 96px viewBox
  ── */
  function fixRingSVG() {
    var ring = document.querySelector('.score-ring');
    if (!ring) return;
    // The SVG is 96×96 with r=44, let's keep that but fix visual weight
    var ringFill = document.getElementById('ringFill');
    var ringBg = ring.querySelector('.ring-bg');
    if (ringBg) {
      ringBg.setAttribute('stroke-width', '9');
      ringBg.setAttribute('stroke', 'rgba(255,255,255,0.06)');
    }
    if (ringFill) {
      ringFill.setAttribute('stroke-width', '9');
      ringFill.setAttribute('stroke', '#7c3aff');
      ringFill.setAttribute('stroke-dasharray', '276');
      ringFill.setAttribute('stroke-dashoffset', '276');
    }
    // Make the SVG larger via CSS width/height
    ring.style.width = '148px';
    ring.style.height = '148px';
    var wrap = ring.closest('.ring-wrap');
    if (wrap) {
      wrap.style.width = '148px';
      wrap.style.height = '148px';
    }
  }

  /* ── SCORE SECTION LAYOUT FIX ──
     Reference: ring takes ~44% width, stats grid ~56%
  ── */
  function fixScoreLayout() {
    var sec = document.querySelector('.score-sec');
    if (!sec) return;
    sec.style.cssText += ';display:flex!important;align-items:center!important;gap:14px!important;';
    var wrap = sec.querySelector('.ring-wrap');
    if (wrap) wrap.style.flexShrink = '0';
    var info = sec.querySelector('.score-info');
    if (info) info.style.flex = '1';
  }

  /* ── SCORE RING TEXT — fix position ── */
  function fixRingNum() {
    var num = document.getElementById('ringNum');
    if (!num) return;
    num.style.cssText = 'position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);font-size:2rem;font-weight:900;color:#fff;font-family:Rajdhani,sans-serif;line-height:1;text-align:center;z-index:3;-webkit-text-fill-color:#fff;';
    // Add score label above number
    var wrap = num.closest('.ring-wrap');
    if (wrap && !wrap.querySelector('.ring-label')) {
      var lbl = document.createElement('div');
      lbl.className = 'ring-label';
      lbl.style.cssText = 'position:absolute;top:30%;left:50%;transform:translateX(-50%);font-size:0.6rem;color:rgba(255,255,255,0.45);font-weight:600;white-space:nowrap;z-index:3;';
      lbl.textContent = "Today's Score";
      wrap.appendChild(lbl);
    }
  }

  /* ── RIPPLE on tappable elements ── */
  function addRipple(e) {
    var el = e.currentTarget;
    var rect = el.getBoundingClientRect();
    var ripple = document.createElement('span');
    ripple.className = 'ripple';
    var size = Math.max(rect.width, rect.height);
    ripple.style.cssText = 'width:'+size+'px;height:'+size+'px;left:'+(e.clientX-rect.left-size/2)+'px;top:'+(e.clientY-rect.top-size/2)+'px';
    el.appendChild(ripple);
    setTimeout(function(){ if (ripple.parentNode) ripple.remove(); }, 600);
  }
  function attachRipples() {
    var sel = '.bnav, .ai-cta-btn, .modal-submit, .auth-btn, .badge-item:not(.locked), .av-item, .gami-tab, .train-section-wrap';
    document.querySelectorAll(sel).forEach(function(el) {
      if (el._rip) return;
      el._rip = true;
      el.style.overflow = 'hidden';
      el.style.position = el.style.position || 'relative';
      el.addEventListener('click', addRipple, {passive:true});
    });
  }

  /* ── XP GAIN POPUP ── */
  window.showXpGainPopup = function(text, x, y) {
    var el = document.createElement('div');
    el.className = 'xp-gain-popup';
    el.textContent = text;
    el.style.left = (x || 180) + 'px';
    el.style.top = (y || 200) + 'px';
    document.body.appendChild(el);
    setTimeout(function(){ if(el.parentNode) el.remove(); }, 1200);
  };

  /* ── One-time <style> injection for the CSS-driven particle animations ──
     PERF FIX (audit Finding 1): the ring-orbit dots and ambient particles
     used to be driven by 11 separate perpetual requestAnimationFrame loops
     that wrote inline `transform`/`top`/`opacity` every frame. That is
     replaced below with plain CSS @keyframes animations, which the browser
     runs on the compositor thread instead of main-thread JS every frame.
  ── */
  function injectPerfKeyframes() {
    if (document.getElementById('rsPerfKeyframes')) return;
    var style = document.createElement('style');
    style.id = 'rsPerfKeyframes';
    style.textContent =
      '@keyframes rsOrbitSpin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}' +
      '@keyframes rsFloatUp{' +
        '0%{transform:translate(0,0);opacity:0}' +
        '10%{opacity:var(--rs-op,0.3)}' +
        '50%{transform:translate(var(--rs-drift,0px),calc(var(--rs-rise,0px) * -0.5))}' +
        '90%{opacity:var(--rs-op,0.3)}' +
        '100%{transform:translate(0,calc(var(--rs-rise,0px) * -1));opacity:0}' +
      '}';
    document.head.appendChild(style);
  }

  /* ── PARTICLE ORBIT around score ring ──
     Small glowing dots that float near the ring.
     Implemented as a rotating "pivot" element (CSS animation, GPU-composited)
     with the visible dot statically offset from its center — the pivot's
     rotation sweeps the dot through the same circular path that the old
     per-frame cos/sin loop produced, with no JS running per frame.
  ── */
  function initRingParticles() {
    var wrap = document.querySelector('.ring-wrap');
    if (!wrap || wrap._particles) return;
    wrap._particles = true;
    injectPerfKeyframes();
    for (var i = 0; i < 3; i++) {
      (function(idx) {
        var size = 2 + idx;
        var radius = 62 + idx * 8;
        var speed = 8000 + idx * 2000; // ms per revolution (matches original)
        var offset = (idx / 3) * Math.PI * 2; // phase offset
        var delayMs = -(offset / (Math.PI * 2)) * speed; // negative delay = start mid-cycle

        var pivot = document.createElement('div');
        pivot.style.cssText = [
          'position:absolute','top:50%','left:50%','width:0','height:0',
          'animation:rsOrbitSpin '+speed+'ms linear infinite',
          'animation-delay:'+delayMs+'ms',
          'will-change:transform'
        ].join(';');

        var dot = document.createElement('div');
        dot.style.cssText = [
          'position:absolute','border-radius:50%',
          'width:'+size+'px','height:'+size+'px',
          'background:rgba(196,167,255,'+(0.4+idx*0.15)+')',
          'box-shadow:0 0 '+(4+idx*2)+'px rgba(124,58,255,'+(0.5+idx*0.2)+')',
          'pointer-events:none','z-index:4',
          'transform:translate('+radius+'px, -50%)'
        ].join(';');

        pivot.appendChild(dot);
        wrap.appendChild(pivot);
      })(i);
    }
  }

  /* ── AMBIENT FLOATING PARTICLES (subtle, page-level) ──
     Rises from just below the viewport to just above it, with a gentle
     sideways drift, fading in/out at the ends — same path shape as the
     original per-frame version, now expressed as a single CSS animation
     (transform + opacity only, no `top` writes, so no layout/paint work
     is triggered while it runs).
  ── */
  function initAmbientParticles() {
    var container = document.getElementById('mainApp');
    if (!container || container._ambPart) return;
    container._ambPart = true;
    injectPerfKeyframes();
    for (var i = 0; i < 8; i++) {
      (function(idx) {
        var p = document.createElement('div');
        var size = 1 + Math.random() * 2;
        var startX = Math.random() * 100;
        var duration = 12000 + Math.random() * 10000;
        var delay = Math.random() * 8000;
        var startY = window.innerHeight + 10;
        var rise = startY + 10; // total vertical travel to endY = -10
        var drift = (Math.random() - 0.5) * 60;
        var peakOpacity = Math.max(0, Math.min(0.35, 0.25 + Math.random() * 0.1));
        p.style.cssText = [
          'position:fixed',
          'pointer-events:none',
          'z-index:0',
          'border-radius:50%',
          'width:'+size+'px',
          'height:'+size+'px',
          'left:'+startX+'%',
          'top:'+startY+'px',
          'background:rgba(124,58,255,'+(0.2+Math.random()*0.3)+')',
          'box-shadow:0 0 '+(3+size*2)+'px rgba(124,58,255,0.4)',
          'opacity:0',
          '--rs-rise:'+rise+'px',
          '--rs-drift:'+drift+'px',
          '--rs-op:'+peakOpacity,
          'animation:rsFloatUp '+duration+'ms linear infinite',
          'animation-delay:'+delay+'ms',
          'will-change:transform,opacity'
        ].join(';');
        document.body.appendChild(p);
      })(i);
    }
  }

  /* ── INIT ── */
  function init() {
    fixRingSVG();
    fixScoreLayout();
    fixRingNum();
    attachRipples();
    initRingParticles();
    setTimeout(initAmbientParticles, 1500);
  }

  /* Run after DOM and after app renders */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() { setTimeout(init, 300); });
  } else {
    setTimeout(init, 300);
  }
  setTimeout(function() {
    init();
    attachRipples();
  }, 2500);

  /* Re-attach on mutations */
  var obs = new MutationObserver(function() { attachRipples(); });
  document.addEventListener('DOMContentLoaded', function() {
    obs.observe(document.body, { childList: true, subtree: true });
  });

})();

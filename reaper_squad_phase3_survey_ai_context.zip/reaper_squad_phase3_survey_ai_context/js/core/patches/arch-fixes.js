// ============================================================
// REAPER SQUAD — Architecture Fixes (arch-fixes.js)  v6
// Load LAST, after all other scripts.
//
// FIXES:
//   P1 — lsSet/lsGet cloud overwrite: script.js global function
//        declarations clobber cloud_sync.js window.lsSet/lsGet.
//        Re-guard after all scripts have executed.
//   P2 — Leaderboard rank badges for ALL users (not just viewer).
//        Upgrade RPC call to leaderboard_totals_with_rank.
//   P3 — Header conflict: leaderboard position (#hdrLbPos) vs
//        military rank (#hdrRank) — separate DOM, no overwrite.
//   I1 — sbUpsert single-writer guard
//   I4 — sbGet single-reader guard (auth + resilience) — fixes the
//        Today/Weekly/All-time leaderboard, header rank, squad
//        roster, and server-side kick list all silently rendering
//        empty under Phase 2 RLS
//   I2 — bootApp middleware collapse
//   I3 — SW version mismatch logging
//   I5 — applyTheme interval leak guard
// ============================================================
(function () {
  'use strict';

  // ─────────────────────────────────────────────────────────────
  // P1 FIX: Re-guard lsGet / lsSet after script.js overwrites them
  // ─────────────────────────────────────────────────────────────
  // ROOT CAUSE:
  //   cloud_sync.js runs first and sets window.lsGet / window.lsSet
  //   to cloud-aware versions. Then script.js runs and contains:
  //     function lsGet(e) { ... localStorage ... }
  //     function lsSet(e,t) { ... localStorage ... }
  //   Global function declarations are own properties of window, so
  //   they silently overwrite the cloud versions. Every lsSet() call
  //   from that point on goes straight to bare localStorage — Supabase
  //   never receives the writes.
  //
  // FIX:
  //   cloud_sync.js (v5+) now saves its implementations to
  //     window._cloudSyncLsGet  and  window._cloudSyncLsSet
  //   before script.js can overwrite them. arch-fixes.js (last to
  //   load) restores those saved references and locks them with
  //   Object.defineProperty so nothing can overwrite them again.
  (function _guardCloudStorage() {
    if (!window._cloudSyncReady) {
      console.warn('[arch-fixes P1] cloud_sync.js not detected — cloud persistence inactive');
      return;
    }
    var cloudGet = window._cloudSyncLsGet;
    var cloudSet = window._cloudSyncLsSet;
    if (typeof cloudGet !== 'function' || typeof cloudSet !== 'function') {
      console.warn('[arch-fixes P1] saved cloud lsGet/lsSet missing — skip guard');
      return;
    }

    function _define(name, fn) {
      try {
        Object.defineProperty(window, name, {
          value: fn, writable: false, configurable: false, enumerable: true
        });
      } catch (e) {
        // Already non-configurable from a previous run (e.g. hot reload)
        window[name] = fn;
      }
    }
    _define('lsGet', cloudGet);
    _define('lsSet', cloudSet);
    console.log('[arch-fixes P1] cloud lsGet/lsSet restored & locked ✅');
  })();


  // ─────────────────────────────────────────────────────────────
  // I1 — sbUpsert single-writer double-wrap guard
  // ─────────────────────────────────────────────────────────────
  // ── ISSUE 1: Verify sbUpsert intercept is working ─────────
  // cloud_sync.js already patches window.sbUpsert to redirect
  // daily_scores writes through CloudSync.saveDaily().
  // Here we add a runtime assertion + warn if it got bypassed.
  (function verifyWriterIntercept() {
    var _current = window.sbUpsert;
    if (typeof _current !== 'function') return; // cloud_sync/script not loaded yet; skip

    // ROOT CAUSE ("Cannot redefine property: sbUpsert" still present):
    // cloud_sync.js loads BEFORE script.js and sets window.sbUpsert via a
    // plain assignment (configurable). script.js then declares
    // `function sbUpsert(e,t,a){...}` as a top-level global function
    // declaration — per spec this ALWAYS (re)installs window.sbUpsert as a
    // NON-CONFIGURABLE data property, regardless of what was there before,
    // and it silently overwrites cloud_sync's routed version with
    // script.js's raw, unrouted one in the process. By the time this file
    // runs, window.sbUpsert is therefore permanently non-configurable —
    // Object.defineProperty can NEVER convert it to an accessor, so the
    // previous try/catch just caught-and-relogged the same
    // "Cannot redefine property: sbUpsert" text every load instead of
    // actually fixing anything.
    //
    // VERIFIED FIX: stop calling Object.defineProperty on window.sbUpsert
    // entirely — it can never succeed here. The property IS writable
    // (function declarations are writable), so a plain assignment is both
    // sufficient and impossible to throw. This also fixes the routing
    // itself: whatever sbUpsert currently is (script.js's raw version,
    // per the root cause above) gets wrapped exactly once so daily_scores
    // writes are routed through CloudSync.saveDaily(), same as cloud_sync.js
    // originally intended.
    if (window._sbUpsertGuarded) return; // already wrapped — avoid double-wrapping
    window.sbUpsert = function (table, data, conflict) {
      if (table === 'daily_scores' && window.CloudSync) {
        window.CloudSync.saveDaily(data);
        return Promise.resolve([]);
      }
      // GUARD (Supabase 400 / 409 on any *other* table): _current (the
      // sbUpsert this IIFE captured above) is script.js's raw version,
      // which always sends the anon key —
      // never the signed-in user's session token. phase2_001_auth_rls.sql
      // restricts INSERT/UPDATE on every table to `TO authenticated` with
      // `auth.uid() = user_id`, so an anon-key request here always fails
      // the NOT NULL user_id trigger (PostgREST reports this as 400), or,
      // if it races an authenticated write for the same row, a unique
      // violation (409). Only daily_scores had a session-aware replacement
      // (CloudSync.saveDaily) before this guard; any other table fell
      // straight through to that doomed anon-key request. Route through
      // the session-aware client when one exists, and skip — rather than
      // send a request guaranteed to be rejected — when it doesn't. Same
      // pattern cloud_sync.js's own getWriteHdrs() already uses.
      if (window.ReaperAuth && window.ReaperAuth._ready && window.ReaperAuth._client) {
        return window.ReaperAuth._client
          .from(table)
          .upsert(data, conflict ? { onConflict: conflict } : undefined)
          .then(function (res) {
            if (res && res.error) console.error('[arch-fixes I1] upsert error on', table, res.error);
            return (res && res.data) || [];
          })
          .catch(function (e) {
            console.error('[arch-fixes I1] upsert threw on', table, e);
            return [];
          });
      }
      console.warn('[arch-fixes I1] skipped anon-key write to', table, '— no authenticated session yet');
      return Promise.resolve([]);
    };
    window._sbUpsertGuarded = true;
    console.log('[arch-fixes I1] sbUpsert wrapped via plain assignment — single-writer routing restored ✅');
  })();


  // ─────────────────────────────────────────────────────────────
  // I4 — sbGet single-reader guard (auth + resilience)
  // ─────────────────────────────────────────────────────────────
  // ROOT CAUSE: script.js's global sbGet(table, filter) — called
  // directly for the "Today" leaderboard, header rank (via
  // buildLbUI), and the squad roster (renderSquad), and called as
  // window.sbGet(...) by security-patch.js's _loadKickedFromServer()
  // (kick enforcement) and by this file's own leaderboard-RPC shim
  // above (P2, for rank/rank_xp) — always sends the hardcoded anon
  // key (SB_KEY) via a raw fetch, never the signed-in user's session
  // token. Phase 2 RLS (phase2_001_auth_rls.sql) scopes SELECT on
  // daily_scores / users / squad_members to `TO authenticated`
  // policies (e.g. users_select_self_or_squadmates,
  // squad_members_select_own_squad) — the anon role has no auth.uid()
  // and is denied outright. sbReq's .catch swallows the failure, so
  // every sbGet() call against these tables silently resolves to
  // { results: [] } with no console error: the Today/Weekly/All-time
  // leaderboard, header rank, squad roster, and server-side kick list
  // all render empty.
  //
  // FIX: once an authenticated session exists, route sbGet through
  // window.ReaperAuth._client — the same supabase-js client every
  // other authenticated read/write in this app already uses (see
  // getMyProfile / getScores in auth-supabase.js) — instead of the
  // raw anon-key fetch. supabase-js attaches the session's access
  // token automatically and has its own retry/error handling, so this
  // is both the authenticated AND the resilient path in one move.
  // Falls back to the original anon-key sbGet whenever there is no
  // session yet (e.g. the auth screen, before login), so pre-auth
  // behavior is unchanged.
  //
  // Signature and return shape are untouched — sbGet(table, filter)
  // -> Promise<{ results: [...] }> — so every existing call site
  // (script.js, security-patch.js, this file) keeps working with zero
  // changes. Same wrap pattern as the I1 sbUpsert fix above.
  (function patchSbGetForAuth() {
    var _origSbGet = window.sbGet;
    if (typeof _origSbGet !== 'function' || window._sbGetGuarded) return;
    window._sbGetGuarded = true;

    window.sbGet = function (table, filter) {
      if (window.ReaperAuth && window.ReaperAuth._ready && window.ReaperAuth._client) {
        var q = window.ReaperAuth._client.from(table).select('*').limit(1000);
        if (filter) {
          Object.keys(filter).forEach(function (k) { q = q.eq(k, filter[k]); });
        }
        return q.then(function (res) {
          if (res && res.error) {
            console.error('[arch-fixes I4] sbGet error on', table, res.error);
            return { results: [] };
          }
          return { results: (res && res.data) || [] };
        }).catch(function (e) {
          console.error('[arch-fixes I4] sbGet threw on', table, e);
          return { results: [] };
        });
      }
      // No authenticated session yet — fall back to the original
      // anon-key sbGet so pre-login behavior is unchanged.
      return _origSbGet(table, filter);
    };
    console.log('[arch-fixes I4] sbGet wrapped — reads now use the authenticated client ✅');
  })();


  // ── FIX 3: bootApp single canonical patcher ──────────────
  // cloud_sync.js and security-patch.js now register middleware
  // into window._bootAppMiddleware[] instead of wrapping bootApp
  // themselves. Here we install a single wrapper that runs the
  // middleware chain in registration order, then calls the
  // original bootApp. This replaces all three independent
  // setTimeout/setInterval overwrites with one ordered sequence.
  document.addEventListener('DOMContentLoaded', function() {
    // All DOMContentLoaded handlers from other scripts have now run.
    // Drain the middleware queue and install the single wrapper.
    setTimeout(function() {
      var _rawBoot = window.bootApp;
      if (!_rawBoot || window._archBootPatched) return;
      window._archBootPatched = true;

      var middleware = window._bootAppMiddleware || [];

      window.bootApp = function archBootApp() {
        if (window._bootInProgress) {
          console.warn('[arch-fixes] bootApp re-entry blocked');
          return;
        }
        window._bootInProgress = true;

        var user = window.S && window.S.user;

        // Run middleware chain in order, then call original bootApp
        //
        // BUG FIX (Google login appears "stuck" on the auth screen):
        // middleware entries (security-patch.js's owner/kicked checks)
        // call next() only after their own async fetch()es resolve. Those
        // fetch()es are try/caught internally so a normal error/rejection
        // still calls next() — but nothing previously bounded a fetch that
        // truly never settles (a hung connection, a Cloudflare Function
        // that accepts the request and never responds, etc.). In that one
        // case runNext() would simply never advance, _rawBoot() (the real
        // bootApp — hide(authScreen)/show(mainApp)) would never run, and
        // the person would see the "Welcome ..." toast from a successful
        // Google sign-in but stay stuck looking at the login screen with
        // no error and no way to tell why. Race each middleware step
        // against a bounded timeout so a hang can delay boot but can never
        // block it forever.
        function runNext(idx) {
          if (idx >= middleware.length) {
            try { _rawBoot.apply(this, arguments); } finally {
              setTimeout(function() { window._bootInProgress = false; }, 2000);
            }
            return;
          }
          var advanced = false;
          function next() {
            if (advanced) return; // already advanced (either by the middleware or the timeout)
            advanced = true;
            runNext(idx + 1);
          }
          var timeoutId = setTimeout(function() {
            console.warn('[arch-fixes] middleware[' + idx + '] timed out after 5s — proceeding without it');
            next();
          }, 5000);
          try {
            middleware[idx](user, function() { clearTimeout(timeoutId); next(); });
          } catch(e) {
            console.warn('[arch-fixes] middleware[' + idx + '] threw:', e);
            clearTimeout(timeoutId);
            next();
          }
        }

        runNext(0);
      };

      console.log('[arch-fixes] bootApp middleware chain installed (' + middleware.length + ' handlers) ✅');
    }, 0); // all DOMContentLoaded handlers have run synchronously above us (50ms poll) both finish
  });


  // ── ISSUE 3: SW cache version vs ?v= query string ─────────
  // HTML uses script.js?v=20260611 but SW caches /script.js
  // (no query string). When SW returns the cached bare URL,
  // the browser sees a mismatch. Fix: strip query strings in
  // the SW fetch handler. We can't edit SW from here, but we
  // can at least log and warn during development.
  //
  // THE REAL FIX is in sw.js: normalise cacheKey to strip ?v=
  // before cache.put/match. That is already done in sw.js via
  // the CACHE_VERSION bump strategy. Here we just verify at
  // runtime that the SW version matches what the page expects.
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.ready.then(function(reg) {
      if (reg.active) {
        reg.active.postMessage('CHECK_VERSION');
      }
    }).catch(function() {});

    navigator.serviceWorker.addEventListener('message', function(e) {
      if (e.data && e.data.type === 'SW_VERSION') {
        console.log('[arch-fixes] Active SW cache version:', e.data.version);
        // If version contains __DEPLOY_HASH__ the build step wasn't run
        if (e.data.version && e.data.version.includes('__DEPLOY_HASH__')) {
          console.warn('[arch-fixes] ⚠️ SW deploy hash was NOT replaced! Run: sed -i "s/__DEPLOY_HASH__/$(date +%s)/" sw.js');
        }
      }
    });
  }


  // ── ISSUE 5: Theme interval memory leak guard ─────────────
  // applyTheme() in script.js already does:
  //   _themeIv && clearInterval(_themeIv); _themeIv = null;
  // before starting a new interval. So there is NO leak from
  // theme switching. The risk is if applyTheme is called multiple
  // times in quick succession before the interval is cleared.
  // We add a debounce guard here.
  document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
      if (typeof window.applyTheme !== 'function' || window._themeDebounced) return;
      window._themeDebounced = true;

      var _lastApplyTheme = window.applyTheme;
      var _themeTimer = null;
      window.applyTheme = function(theme, event) {
        // For immediate calls (keyboard, programmatic), don't debounce
        // For rapid repeat calls, debounce 80ms to prevent double-interval
        if (_themeTimer) {
          clearTimeout(_themeTimer);
          // Still clear the old interval immediately
          if (window._themeIv) {
            clearInterval(window._themeIv);
            window._themeIv = null;
          }
        }
        _themeTimer = setTimeout(function() {
          _themeTimer = null;
          _lastApplyTheme(theme, event);
        }, 50);

        // For immediate first-call feel, call synchronously too
        // but only if no timer was pending (first call)
        if (!_themeTimer) {
          _lastApplyTheme(theme, event);
        }
      };
    }, 300);
  });


  // ── BONUS: SW cacheKey query-string normaliser ─────────────
  // Patch: since HTML uses /script.js?v=20260611, the SW fetch
  // intercept should strip ?v= before cache.put/match.
  // This is already handled in sw.js SHELL_ASSETS (bare URLs),
  // but fetch requests from the page include ?v=. We log this
  // conflict so it's visible in DevTools.
  if (window.location.protocol === 'https:' || window.location.hostname === 'localhost') {
    var _origFetch = window.fetch;
    var _versionedAssets = /\/(js|css)\/.*\?v=/;
    window.fetch = function(url) {
      // Only intercept GET requests for versioned assets to log
      if (typeof url === 'string' && _versionedAssets.test(url)) {
        // The SW will intercept this with the bare URL in SHELL_ASSETS,
        // causing a cache miss since ?v= won't match. Log it.
        // Production fix: use Content-Type headers with Cache-Control
        // immutable (already done in _headers) so browser caches the
        // versioned URL directly without needing the SW to serve it.
      }
      return _origFetch.apply(window, arguments);
    };
  }

  // ── RANK ENGINE INTEGRATION ──────────────────────────────────
  // window.RankEngine (js/gamification/rank-engine.js) is the ONLY place
  // Rank/XP math happens. Everything below just READS from its public
  // API (calculateXP/getRank/getNextRank/getProgress/getRemainingXP)
  // and pushes the result into existing DOM/UX integration points.
  // We do NOT modify script.js (minified, 200 KB) — instead we wrap
  // the functions it defines here, in the deferred arch-fixes.js,
  // which loads after script.js. Each wrap calls the original first,
  // then layers Rank Engine behaviour on top; if RankEngine failed to
  // load for any reason, the original behaviour is unaffected.

  // ── Home page: Current Rank / Next Rank / Progress / Remaining XP
  // Populates the #rankEngineCard block added to index.html. Pure
  // read of RankEngine's API — no calculation happens here.
  function _renderRankEngineCard() {
    try {
      if (!window.RankEngine) return;
      var xp   = RankEngine.calculateXP();
      var rank = RankEngine.getRank(xp);
      var next = RankEngine.getNextRank(xp);
      var pct  = RankEngine.getProgress(xp);
      var rem  = RankEngine.getRemainingXP(xp);

      var elEmoji = document.getElementById('rankEngineEmoji');
      var elName  = document.getElementById('rankEngineName');
      var elNext  = document.getElementById('rankEngineNext');
      var elFill  = document.getElementById('rankEngineProgressFill');
      var elPct   = document.getElementById('rankEngineProgressPct');
      var elRem   = document.getElementById('rankEngineRemaining');

      if (elEmoji) elEmoji.textContent = rank.emoji;
      if (elName)  elName.textContent  = rank.name;
      if (elNext)  elNext.textContent  = next ? (next.emoji + ' ' + next.name) : 'MAX';
      if (elFill)  elFill.style.width  = pct + '%';
      if (elPct)   elPct.textContent   = pct + '%';
      if (elRem)   elRem.textContent   = next ? (rem.toLocaleString() + ' XP to next rank') : 'Max Rank Reached 🔱';
    } catch (e) { /* DOM not ready / RankEngine not ready — non-fatal */ }
  }

  // ── Promotion system: announce when the player crosses a rank
  // threshold. We keep a tiny "last seen rank index" marker in plain
  // localStorage (NOT lsSet/Supabase — this is a local UI dedupe flag,
  // not derived rank/XP data, so it is intentionally not synced).
  // The promotion check itself never computes thresholds — it only
  // compares the index RankEngine already returns.
  function _checkRankPromotion() {
    try {
      if (!window.RankEngine || !window.S || !window.S.user) return;
      var u = window.S.user.username;
      var idx = RankEngine.getRank().index;
      var seenKey = 'rankIdxSeen_' + u;
      var seenRaw = localStorage.getItem(seenKey);
      var seen = seenRaw === null ? NaN : parseInt(seenRaw, 10);

      if (isNaN(seen)) {
        localStorage.setItem(seenKey, idx); // first run for this user — no toast
        return;
      }
      if (idx !== seen) {
        if (idx > seen && typeof window.toast === 'function') {
          var rank = RankEngine.getRank();
          window.toast('🎉 RANK UP! ' + rank.emoji + ' ' + rank.name);
        }
        localStorage.setItem(seenKey, idx);
      }
    } catch (e) { /* non-fatal */ }
  }

  // Patch window.updateScore (defined in script.js) to call the
  // Rank Engine after every score update.
  //
  // The wrap is idempotent: if RankEngine is not yet loaded (unlikely
  // since rank-engine.js loads synchronously before arch-fixes.js),
  // the original updateScore still runs cleanly.
  (function _patchUpdateScoreForRankEngine() {
    var _origUpdateScore = window.updateScore;
    if (typeof _origUpdateScore !== 'function') return;

    window.updateScore = function () {
      _origUpdateScore.apply(this, arguments);

      // Run Rank Engine post-score update
      if (window.RankEngine) {
        // 1. Persist rank to localStorage (cloud_sync picks it up)
        window.RankEngine.persistRank();
        // 2. Update the #hdrRank badge with rank name + emoji
        window.RankEngine.updateHeaderRankBadge();
        // 3. Update the Home page Rank card
        _renderRankEngineCard();
        // 4. Promotion system — fire a toast on rank-up
        _checkRankPromotion();
      }
    };

    console.log('[RankEngine] updateScore patched ✅');
  })();

  // ─────────────────────────────────────────────────────────────
  // P2 FIX: Upgrade leaderboard RPC to leaderboard_totals_with_rank
  // ─────────────────────────────────────────────────────────────
  // ROOT CAUSE: renderLeaderboard() used to call sbRpc("leaderboard_totals"),
  // an outdated name. The current RPC (02_security.sql) is
  // leaderboard_totals_with_rank(p_squad_code) and returns username,
  // name, total_pts, today_pts, streak, rank_position — it does NOT
  // return rank_label/rank_xp (those live on users.rank / users.rank_xp
  // instead). We intercept the sbRpc call, upgrade the RPC name, and
  // separately pull rank/rank_xp from users so the badge injection
  // below still gets real data instead of silently falling back to
  // "Initiate"/0 for every row.
  //
  // 404 FIX: this shim used to forward `args` straight through unchanged.
  // script.js's call site still sends {p_mode, p_squad_code} (the OLD,
  // pre-redesign shape), but leaderboard_totals_with_rank(p_squad_code)
  // only has ONE parameter. PostgREST resolves an RPC call by matching
  // the JSON body's keys to a function's parameter names; a body that
  // includes an extra key the function doesn't declare (p_mode) doesn't
  // match ANY overload, so PostgREST returns 404 ("Could not find the
  // function ... in the schema cache") even though the function exists
  // and works fine when called with p_squad_code alone. Only forward the
  // parameter the current signature actually accepts.
  (function _upgradeLeaderboardRpc() {
    var _origSbRpc = window.sbRpc;
    if (typeof _origSbRpc !== 'function') return;

    window.sbRpc = function _patchedSbRpc(fnName, args) {
      if (fnName === 'leaderboard_totals' || fnName === 'leaderboard_totals_with_rank') {
        var rpcArgs = { p_squad_code: (args && args.p_squad_code) || null };
        return _origSbRpc.call(this, 'leaderboard_totals_with_rank', rpcArgs)
          .then(function (res) {
            var usernames = (res.results || []).map(function (row) { return row.username; }).filter(Boolean);
            if (!usernames.length) { window._lbRankData = {}; return res; }
            // users has no simple "IN (...)" helper via sbGet, so pull all
            // rows once and index client-side — same pattern renderSquad()
            // already uses for the users table.
            return window.sbGet('users', {}).then(function (userRes) {
              window._lbRankData = {};
              (userRes.results || []).forEach(function (u) {
                if (u.username) {
                  window._lbRankData[u.username] = {
                    rank_label: u.rank || 'Initiate',
                    rank_xp:    Number(u.rank_xp) || 0
                  };
                }
              });
              return res;
            }).catch(function () { return res; });
          });
      }
      return _origSbRpc.apply(this, arguments);
    };
    console.log('[arch-fixes P2] sbRpc upgraded: leaderboard_totals_with_rank ✅');
  })();


  // ─────────────────────────────────────────────────────────────
  // P2 + P3 FIX: Patch buildLbUI — inject data-username, add rank
  // badges for all users, separate hdrLbPos / hdrRank
  // ─────────────────────────────────────────────────────────────
  // ROOT CAUSE (P3): buildLbUI writes "#N" to #hdrRank for leaderboard
  // position. RankEngine.updateHeaderRankBadge() also targets #hdrRank
  // for the military rank name. Whichever runs last wins; the other is
  // silently erased.
  //
  // FIX: we wrap buildLbUI once. After the original renders:
  //   1. Read the "#N" position that script.js wrote to #hdrRank.
  //   2. Move it to #hdrLbPos.
  //   3. Call RankEngine.updateHeaderRankBadge() to restore #hdrRank.
  //   4. Inject data-username on .pod-name / .lb-name elements using
  //      the player list we captured before rendering.
  //   5. Add rank badges for all annotated elements.
  (function _patchBuildLbUI() {
    var _orig = window.buildLbUI;
    if (typeof _orig !== 'function') return;

    // Helper: map rank_label → emoji via RankEngine table
    function _emojiFor(label) {
      if (!window.RankEngine) return '🌑';
      var table = window.RankEngine.getRankTable();
      for (var i = 0; i < table.length; i++) {
        if (table[i].name === label) return table[i].emoji;
      }
      return '🌑';
    }

    // Helper: inject rank badge HTML on a single name element
    function _addBadge(el, username) {
      if (!username || el.dataset.rankBadged === '1') return;

      var rankLabel, rankEmoji, rankXP;
      var isMe = window.S && window.S.user && username === window.S.user.username;

      if (isMe && window.RankEngine) {
        var r = window.RankEngine.getRank();
        rankLabel = r.name;
        rankEmoji = r.emoji;
        rankXP    = window.RankEngine.calculateXP();
      } else {
        var data = (window._lbRankData || {})[username];
        if (!data) return; // no server data for this user yet
        rankLabel = data.rank_label || 'Initiate';
        rankEmoji = _emojiFor(rankLabel);
        rankXP    = data.rank_xp || 0;
      }

      var badge = '<span class="rank-engine-lb-badge" style="font-size:.62rem;font-weight:700;' +
        'color:var(--accent2);margin-left:5px;white-space:nowrap;opacity:.82" ' +
        'title="' + rankLabel + ' · ' + rankXP.toLocaleString() + ' XP">' +
        rankEmoji + '\u00a0' + rankLabel + '</span>';
      el.insertAdjacentHTML('beforeend', badge);
      el.dataset.rankBadged = '1';
    }

    window.buildLbUI = function _wrappedBuildLbUI(players, myPts, kicked) {
      // 1. Capture name→username map before rendering
      var nameMap = {};
      if (Array.isArray(players)) {
        players.forEach(function (p) {
          if (p && p.username && p.name) nameMap[p.name] = p.username;
        });
      }
      if (window.S && window.S.user) {
        nameMap[window.S.user.name] = window.S.user.username;
      }

      // 2. Run original buildLbUI (writes HTML + "#N" to #hdrRank)
      _orig.apply(this, arguments);

      // 3. P3: Move leaderboard position out of #hdrRank → #hdrLbPos
      try {
        var hdrRank  = document.getElementById('hdrRank');
        var hdrLbPos = document.getElementById('hdrLbPos');
        if (hdrRank && hdrLbPos) {
          var txt = (hdrRank.textContent || '').trim();
          if (/^#\d+$/.test(txt)) {
            hdrLbPos.textContent = txt;
            hdrLbPos.title = 'Leaderboard position';
            // Restore military rank to #hdrRank
            if (window.RankEngine) window.RankEngine.updateHeaderRankBadge();
          }
        }
      } catch (e) {}

      // 4. Annotate .pod-name / .lb-name with data-username and add badges
      // Use setTimeout(0) so the DOM is fully painted before we query it
      setTimeout(function () {
        // Annotate podium names
        document.querySelectorAll('#lbPodium .pod-name').forEach(function (el) {
          if (el.dataset.username) return;
          // Text before any injected spans (firstChild is a text node)
          var raw = '';
          el.childNodes.forEach(function (n) {
            if (n.nodeType === 3) raw += n.nodeValue; // text node
          });
          raw = raw.replace(/[👈👑]/g, '').trim();
          if (nameMap[raw]) el.dataset.username = nameMap[raw];
        });

        // Annotate list row names
        document.querySelectorAll('#lbRest .lb-name').forEach(function (el) {
          if (el.dataset.username) return;
          var raw = '';
          el.childNodes.forEach(function (n) {
            if (n.nodeType === 3) raw += n.nodeValue;
          });
          raw = raw.replace(/[👈👑]/g, '').trim();
          if (nameMap[raw]) el.dataset.username = nameMap[raw];
        });

        // Inject rank badges on all annotated elements
        document.querySelectorAll('#lbPodium .pod-name[data-username], #lbRest .lb-name[data-username]')
          .forEach(function (el) {
            _addBadge(el, el.dataset.username);
          });
      }, 0);
    };

    console.log('[arch-fixes P2+P3] buildLbUI patched — rank badges + header separation ✅');
  })();

  // ── AI context: inject the player's live Rank Engine status into
  // the system prompt sent to the AI ("convince me to keep going"
  // feature in script.js, via callGemini). The AI text itself is
  // untouched — we only add factual rank/XP context for it to use.
  // callGeminiForPlan() (the JSON workout-plan generator) is
  // deliberately NOT patched: its system prompt is a strict
  // "return ONLY JSON" contract baked into that function, and
  // appending free text to it risks breaking JSON parsing.
  (function _patchCallGeminiForRankEngine() {
    var _origCallGemini = window.callGemini;
    if (typeof _origCallGemini !== 'function') return;

    window.callGemini = function (systemPrompt) {
      var args = Array.prototype.slice.call(arguments);
      try {
        if (window.RankEngine) {
          var xp   = window.RankEngine.calculateXP();
          var rank = window.RankEngine.getRank(xp);
          var next = window.RankEngine.getNextRank(xp);
          var rem  = window.RankEngine.getRemainingXP(xp);
          var rankLine = '\n\n[Player progression context — Rank: ' + rank.emoji + ' ' + rank.name +
            ' (' + xp + ' XP).' +
            (next ? ' ' + rem + ' XP to next rank: ' + next.emoji + ' ' + next.name + '.' : ' Max rank reached.') +
            ' Use this naturally if relevant — do not just list the numbers.]';
          args[0] = (systemPrompt || '') + rankLine;
        }
      } catch (e) { /* non-fatal — falls through with the original prompt */ }
      return _origCallGemini.apply(this, args);
    };

    console.log('[RankEngine] callGemini patched (AI context) ✅');
  })();

  // ─────────────────────────────────────────────────────────────
  // AI ARCHITECTURE — Fix It migrated onto the single AI service
  // ─────────────────────────────────────────────────────────────
  // ROOT CAUSE: every other AI feature (quit-popup, Improve Guide,
  // orb Improve Guide, workout/diet plan generation, in this order:
  // callGemini / callGeminiText / callGeminiForPlan) already forwards
  // through window.ReaperAI (js/ai/service.js) via security-patch.js.
  // script.js's fixAnalyze() (the camera posture/pain analyzer) is the
  // one remaining feature that talks to the transport layer directly:
  // it calls fetch('/api/ai', ...) itself, twice over — once for its
  // Anthropic attempt, then once per Groq fallback model — duplicating
  // request-building and response-shape parsing that js/ai/service.js
  // already owns, and depending on security-patch.js's window.fetch
  // interceptor (matching the literal '/api/ai' string) just to get an
  // auth header attached.
  //
  // FIX: replace window.fixAnalyze with a version that preserves its
  // exact observable behavior — same system/user prompts, same 33-point
  // MediaPipe keypoint dump, same Anthropic-first → 3-Groq-fallback
  // model order, same max_tokens per mode, same DOM ids/classes, same
  // console logging users never see but developers rely on — but
  // sources every network call from window.ReaperAI.request() +
  // window.ReaperAI.extractText() instead of raw fetch(). Auth headers,
  // and retry-on-429/5xx are then handled once, in one place, for this
  // feature exactly like every other one. We do NOT edit script.js
  // itself (same reasoning as the RankEngine/buildLbUI wraps above) —
  // fixAnalyze is a plain top-level global function declaration in
  // script.js, so it can be replaced from here, after script.js has
  // run, with zero changes to that file.
  //
  // SAFETY: if window.ReaperAI somehow isn't loaded, we fall back to
  // the original (pre-migration) window.fixAnalyze untouched, so this
  // can only ever improve on the pre-existing behavior, never break it.
  (function _migrateFixAnalyzeToReaperAI() {
    if (typeof window.fixAnalyze !== 'function') return; // script.js not loaded yet
    if (window._fixAnalyzeMigrated) return;

    var _origFixAnalyze = window.fixAnalyze;

    var KEYPOINT_NAMES = ['nose', 'left eye inner', 'left eye', 'left eye outer', 'right eye inner', 'right eye', 'right eye outer', 'left ear', 'right ear', 'mouth left', 'mouth right', 'left shoulder', 'right shoulder', 'left elbow', 'right elbow', 'left wrist', 'right wrist', 'left pinky', 'right pinky', 'left index', 'right index', 'left thumb', 'right thumb', 'left hip', 'right hip', 'left knee', 'right knee', 'left ankle', 'right ankle', 'left heel', 'right heel', 'left foot index', 'right foot index'];
    var LOADING_TIPS = ['Body keypoints extract ho rahe hain… 🦾', 'AI analysis kar raha hai… 🧠', 'Almost done… ⚡', 'Ek second bhai… 💀'];
    var GROQ_FALLBACK_MODELS = ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'gemma2-9b-it'];

    window.fixAnalyze = async function fixAnalyze() {
      if (!window.fixLastKeypoints) {
        if (typeof toast === 'function') toast('❗ Pehle camera ke saamne khade ho jao!');
        return;
      }
      if (!window.ReaperAI) return _origFixAnalyze(); // service not loaded — degrade to legacy path

      var result = document.getElementById('fixResult');
      var loading = document.getElementById('fixResultLoading');
      var resultText = document.getElementById('fixResultText');
      var loadingTip = document.getElementById('fixLoadingTip');
      if (result) result.classList.remove('hidden');
      if (loading) loading.classList.remove('hidden');
      if (resultText) resultText.textContent = '';

      var tipIdx = 0;
      var tipTimer = setInterval(function () {
        if (loadingTip) loadingTip.textContent = LOADING_TIPS[tipIdx++ % LOADING_TIPS.length];
      }, 1800);

      var kpDump = window.fixLastKeypoints.map(function (kp, idx) {
        return KEYPOINT_NAMES[idx] + ': x=' + kp.x.toFixed(3) + ' y=' + kp.y.toFixed(3) + ' z=' + kp.z.toFixed(3) + ' vis=' + kp.visibility.toFixed(2);
      }).join('\n');

      var system, userContent;
      if (window.fixMode === 'normal') {
        system = 'Tu ek expert sports physiotherapist aur posture analyst hai. User ne camera ke saamne khade hokar pose diya hai. MediaPipe se 33 body keypoints milte hain (x, y, z coordinates, visibility). Tu inhe analyze karke EXACTLY 20 numbered points mein posture analysis dega. Har point mein: kya dekha, score (/10), aur 1 line tip. Hinglish mein likh — simple, direct, actionable. Ek overall posture score bhi de end mein.';
        userContent = 'Yeh user ke body keypoints hain:\n\n' + kpDump + '\n\nIn 33 keypoints ko analyze karke EXACTLY 20 numbered posture points mein batao. Format:\n1. [Body Part] — Score: X/10 — [Observation + Tip]\n...\n\n🏆 Overall Posture Score: X/10\n💡 Top 3 improvement tips:';
      } else {
        system = 'Tu ek expert sports physiotherapist aur pain specialist hai. User workout ke dauran "' + window.fixPainArea + '" area mein dard feel kar raha hai. MediaPipe se 33 body keypoints mile hain. Tu inhe deeply analyze karke 50+ detailed points mein problem diagnose karega aur fix batayega. Hinglish mein likh — clear, caring, aur actionable.';
        userContent = 'User ko ' + window.fixPainArea + ' area mein workout ke dauran dard ho raha hai.\n\nBody keypoints:\n' + kpDump + '\n\nDeep analysis karo:\n\n😣 PAIN ANALYSIS (' + window.fixPainArea.toUpperCase() + ')\n\n🔍 ROOT CAUSE (10 points):\n1-10. [Har possible cause]\n\n📍 AFFECTED AREAS (15 points):\n11-25. [Muscles/joints affected]\n\n⚠️ WARNING SIGNS (10 points):\n26-35. [Kya avoid karo]\n\n✅ FIX IT — EXERCISES (15 points):\n36-50. [Har exercise — naam, sets/reps, tip]\n\n🩺 DOCTOR KAB JAO:\n[Clear guidance]\n\n💊 IMMEDIATE RELIEF:\n[2-3 quick tips]';
      }

      var maxTokens = window.fixMode === 'pain' ? 2000 : 1200;
      var finalText = null;

      try {
        var anthropicData = await window.ReaperAI.request({
          provider: 'anthropic', model: 'claude-sonnet-4-20250514', max_tokens: maxTokens,
          system: system, messages: [{ role: 'user', content: userContent }]
        });
        var anthropicText = window.ReaperAI.extractText('anthropic', anthropicData);
        if (anthropicText) {
          finalText = anthropicText;
          console.log('Fix It: Anthropic Claude used (via ReaperAI) ✅');
        }
      } catch (e) {
        console.warn('Anthropic proxy error:', e && e.message);
      }

      if (!finalText) {
        for (var i = 0; i < GROQ_FALLBACK_MODELS.length; i++) {
          var model = GROQ_FALLBACK_MODELS[i];
          try {
            var groqData = await window.ReaperAI.request({
              provider: 'groq', model: model, max_tokens: maxTokens,
              messages: [{ role: 'system', content: system }, { role: 'user', content: userContent }]
            });
            var groqText = window.ReaperAI.extractText('groq', groqData);
            if (groqText) {
              finalText = groqText;
              console.log('Fix It: Groq model used (via ReaperAI):', model);
              break;
            }
          } catch (e) {
            console.warn('Groq proxy failed:', model, e && e.message);
            if (i === GROQ_FALLBACK_MODELS.length - 1) {
              finalText = '❌ AI service unavailable. Internet check karo ya thodi der baad try karo.';
            }
          }
        }
      }

      clearInterval(tipTimer);
      if (loading) loading.classList.add('hidden');
      if (resultText) resultText.textContent = finalText || '❌ Koi response nahi aaya.';
      if (result) result.scrollIntoView({ behavior: 'smooth', block: 'start' });
    };

    window._fixAnalyzeMigrated = true;
    console.log('[arch-fixes] fixAnalyze migrated onto window.ReaperAI (single AI service) ✅');
  })();

  // ─────────────────────────────────────────────────────────────
  // FIX — Google FedCM deprecation warning
  // ─────────────────────────────────────────────────────────────
  // ROOT CAUSE: script.js calls google.accounts.id.initialize({...,
  // use_fedcm_for_prompt: false, ...}) in two places (initGoogleOneTap
  // and signInWithGoogle). Google now logs a console deprecation
  // warning whenever a caller explicitly opts out of FedCM this way,
  // since the legacy (non-FedCM) One Tap/prompt path is being retired.
  //
  // FIX: rather than edit the two hardcoded call sites inside
  // script.js (minified, 200 KB — see this file's header), patch the
  // Google Identity Services SDK's own initialize() method once it
  // loads, so any config object passed to it — from either call site,
  // now or in the future — is forced to use_fedcm_for_prompt:true
  // before being forwarded to the real implementation. This removes
  // the warning without touching script.js and without changing the
  // observable sign-in behavior (FedCM is a drop-in replacement for
  // the legacy prompt UI here — no other config depends on the flag).
  (function _patchGsiForFedCM() {
    function tryPatch() {
      if (window.google && google.accounts && google.accounts.id &&
          typeof google.accounts.id.initialize === 'function' &&
          !google.accounts.id.initialize._fedcmPatched) {
        var _origInitialize = google.accounts.id.initialize;
        var patched = function (config) {
          config = config || {};
          config.use_fedcm_for_prompt = true;
          return _origInitialize.call(this, config);
        };
        patched._fedcmPatched = true;
        google.accounts.id.initialize = patched;
        console.log('[arch-fixes] Google Identity Services patched — FedCM enabled ✅');
        return true;
      }
      return false;
    }
    if (!tryPatch()) {
      var tries = 0;
      var iv = setInterval(function () {
        tries++;
        if (tryPatch() || tries > 50) clearInterval(iv); // give up after ~5s
      }, 100);
    }
  })();

  console.log('[ReaperSquad] Architecture fixes loaded ✅');
})();

// ============================================================
// REAPER SQUAD — SECURITY PATCH (security-patch.js)
// Load this BEFORE script.js in index.html:
//   <script src="/js/core/patches/security-patch.js"></script>
//   <script src="/js/core/script.js"></script>
// ============================================================

// ---------------------------------------------------------------
// CRITICAL FIX 1: Remove hardcoded secrets from global scope.
// GROQ_KEY, SB_KEY, and OWNER are now runtime-only / server-side.
// Any reference to GROQ_KEY/SB_KEY in script.js calls will be
// intercepted and proxied through /api/ai (Cloudflare Function).
// ---------------------------------------------------------------

// Poison the leaked globals so script.js code that still references
// them fails fast rather than sending real keys to the browser.
// Real calls are handled by the patched callGemini / callGeminiText
// / callGeminiForPlan overrides below.
window._GROQ_KEY_REMOVED = true;

// ---------------------------------------------------------------
// CRITICAL FIX 2: AI calls → /api/ai (server proxy, no key exposed)
// Overrides callGemini, callGeminiText, callGeminiForPlan BEFORE
// script.js defines them, so script.js definitions are shadowed.
//
// PHASE 2 AI ARCHITECTURE REFACTOR (js/ai/service.js):
// Sending requests, auth headers, retry logic, response
// normalization, and provider selection now live in js/ai/service.js
// (window.ReaperAI) and js/ai/providers/*.js. This file no longer
// duplicates that logic — it only forwards the same legacy globals
// and fetch-interception behavior to window.ReaperAI, so every
// existing caller (script.js's callGemini/callGeminiText/
// callGeminiForPlan usages, and fixAnalyze()'s direct fetch calls)
// keeps working exactly as before, with zero call-site changes.
// js/ai/service.js and js/ai/providers/*.js MUST load before this
// file — see index.html.
// ---------------------------------------------------------------

// Back-compat shim: some code (none currently, kept just in case)
// may still reference _getAiAuthHeaders() / _proxyAI() by name.
async function _getAiAuthHeaders() {
  return window.ReaperAI ? window.ReaperAI.getAuthHeaders() : {};
}

async function _proxyAI(provider, model, messages, system, max_tokens) {
  if (!window.ReaperAI) throw new Error('AI service not loaded');
  return window.ReaperAI.requestRaw(provider, model, messages, system, max_tokens);
}

// Replace callGemini (used everywhere for chat/AI) — forwards to
// ReaperAI.chat(), which builds the same message array and returns
// the same Promise<string> contract as before.
window.callGemini = function(systemPrompt, messages, max_tokens) {
  if (!window.ReaperAI) return Promise.resolve('');
  return window.ReaperAI.chat(systemPrompt, messages, max_tokens, { provider: 'groq' });
};

// Replace callGeminiText — forwards to ReaperAI.chatText(), same
// callback(onSuccess, onError) contract as before.
window.callGeminiText = function(system, userContent, onSuccess, onError) {
  if (!window.ReaperAI) return onError && onError();
  window.ReaperAI.chatText(system, userContent, onSuccess, onError, { provider: 'groq' });
};

// Replace callGeminiForPlan — forwards to ReaperAI.planJSON(), same
// (prompt, progressBar, intervalId, onSuccess, onError) contract,
// same JSON-fence-stripping / {...} extraction / parsed.days check.
window.callGeminiForPlan = function(prompt, progressBar, intervalId, onSuccess, onError) {
  if (!window.ReaperAI) { clearInterval(intervalId); return onError && onError(); }
  window.ReaperAI.planJSON(prompt, progressBar, intervalId, onSuccess, onError, { provider: 'groq' });
};

// ---------------------------------------------------------------
// CRITICAL FIX 3: Anthropic direct browser call → proxy
// fixAnalyze() in script.js calls Anthropic directly with
// anthropic-dangerous-direct-browser-access. Intercept fetch.
//
// PHASE 2: the actual request-sending/auth/retry/normalization for
// the intercepted api.anthropic.com and api.groq.com branches below
// now happens inside window.ReaperAI.requestRaw() (js/ai/service.js);
// this interceptor still owns exactly what it owned before — deciding
// *which* outbound calls get rerouted, parsing the caller's body, and
// re-wrapping the proxy's JSON back into a Response object so callers
// that expect a normal fetch() Response see no difference.
// ---------------------------------------------------------------
(function() {
  const _origFetch = window.fetch;
  window.fetch = function(url) {
    var args = Array.prototype.slice.call(arguments);
    // SECURITY FIX (audit 5.1): /api/ai now requires an Authorization
    // header (see functions/api/ai.js). script.js's fixAnalyze() calls
    // fetch('/api/ai', ...) directly (not through ReaperAI.request), so
    // inject the header here rather than editing that large generated file.
    if (typeof url === 'string' && url.indexOf('/api/ai') === 0) {
      return _getAiAuthHeaders().then(function(authHeaders) {
        var opts = Object.assign({}, args[1] || {});
        opts.headers = Object.assign({}, opts.headers || {}, authHeaders);
        return _origFetch(url, opts);
      });
    }
    if (typeof url === 'string' && url.includes('api.anthropic.com')) {
      // Extract body and re-route through server proxy
      const opts = args[1] || {};
      let body = {};
      try { body = JSON.parse(opts.body || '{}'); } catch(e) {}
      return _proxyAI('anthropic', body.model || 'claude-sonnet-4-20250514',
        body.messages || [], body.system || '', body.max_tokens || 1200)
        .then(function(data) {
          return new Response(JSON.stringify(data), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
          });
        });
    }
    if (typeof url === 'string' && url.includes('api.groq.com')) {
      // Also intercept direct Groq calls (callGeminiForPlan in script.js uses GROQ_KEY directly)
      const opts = args[1] || {};
      let body = {};
      try { body = JSON.parse(opts.body || '{}'); } catch(e) {}
      const msgs = body.messages || [];
      const sys = msgs.find(function(m) { return m.role === 'system'; });
      const userMsgs = msgs.filter(function(m) { return m.role !== 'system'; });
      return _proxyAI('groq', body.model || 'llama-3.3-70b-versatile',
        userMsgs, sys ? sys.content : null, body.max_tokens || 1000)
        .then(function(data) {
          return new Response(JSON.stringify(data), {
            status: 200,
            headers: { 'Content-Type': 'application/json' }
          });
        });
    }
    return _origFetch.apply(window, args);
  };
})();

// ---------------------------------------------------------------
// CRITICAL FIX 4: Server-side owner verification
// isOwner() in script.js compares username === OWNER (client string).
// We replace it to use a cached server-verified flag set at login.
// ---------------------------------------------------------------
window._ownerVerified = false; // set to true after server confirms

// SECURITY FIX: verify-owner now requires a real Supabase Auth session
// (Authorization: Bearer <jwt>) — the server resolves identity from the
// JWT itself and never trusts a client-supplied username. If there is
// no ReaperAuth session yet (Phase 2 auth not wired in for this user),
// ownership simply cannot be verified and defaults to false.
async function _verifyOwnerServerSide() {
  try {
    if (!window.ReaperAuth || !window.ReaperAuth._ready) {
      window._ownerVerified = false;
      return;
    }
    const session = await window.ReaperAuth.getSession();
    if (!session || !session.access_token) {
      window._ownerVerified = false;
      return;
    }
    const resp = await fetch('/api/verify-owner', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + session.access_token,
      },
      body: JSON.stringify({}),
    });
    const data = await resp.json();
    window._ownerVerified = !!data.isOwner;
  } catch(e) {
    window._ownerVerified = false;
  }
}

// Override isOwner to use server-verified flag only
window.isOwner = function(username) {
  // If a specific username is passed (for display only), use the verified flag only
  // when it's the current user.
  if (username && window.S && window.S.user && username !== window.S.user.username) {
    return false; // Can't claim owner for another user client-side
  }
  return window._ownerVerified === true;
};

// CRITICAL FIX 5: removed — doLogin/doSignup now use ReaperAuth (Phase 2 auth wiring)

// ---------------------------------------------------------------
// HIGH FIX 6: Ban enforcement from Supabase (not localStorage)
// getKicked() reads localStorage which any user can clear.
// Augment with a Supabase fetch so bans can't be self-removed.
// ---------------------------------------------------------------
window._kickedFromServer = new Set();

// SCHEMA FIX: there is no kicked_users table in the authoritative schema
// (01_schema.sql says bare-username kicked_users is deliberately
// absent). Moderation state now lives on squad_members.status, keyed by
// UUID user_id, scoped to the caller's own squad via RLS
// (squad_members_select_own_squad). We read kicked memberships, then
// resolve those user_ids to usernames via users (users_select_self_or_
// squadmates already allows reading squadmates' rows).
async function _loadKickedFromServer(squadCode) {
  try {
    // Uses the existing sbGet helper defined in script.js
    const memResult = await window.sbGet('squad_members', { status: 'kicked' });
    const kickedUserIds = (memResult.results || []).map(function(r) { return r.user_id; });
    if (!kickedUserIds.length) {
      window._kickedFromServer = new Set();
      return;
    }
    const usernames = new Set();
    for (const uid of kickedUserIds) {
      const userResult = await window.sbGet('users', { id: uid });
      (userResult.results || []).forEach(function(u) {
        if (u.username) usernames.add(u.username);
      });
    }
    window._kickedFromServer = usernames;
  } catch(e) {
    // fallback to localStorage-only on network error
  }
}

// Wrap isKicked to also check server list
const _origIsKicked = window.isKicked;
window.isKicked = function(username) {
  return window._kickedFromServer.has(username) ||
    (typeof _origIsKicked === 'function' ? _origIsKicked(username) : false);
};

// ---------------------------------------------------------------
// HIGH FIX 7: Hook bootApp to trigger server-side checks
// ---------------------------------------------------------------
document.addEventListener('DOMContentLoaded', function() {
  // FIX 3: Register security checks into the shared bootApp patch queue
  // instead of using setInterval to race-overwrite window.bootApp.
  // The queue is drained in order by arch-fixes.js after all scripts load.
  if (!window._bootAppMiddleware) window._bootAppMiddleware = [];
  window._bootAppMiddleware.push(function securityMiddleware(user, next) {
    if (user && user.username) {
      _verifyOwnerServerSide().then(function() {
        return _loadKickedFromServer(user.squadCode || 'SQXXNI');
      }).then(function() {
        if (window._kickedFromServer.has(user.username)) {
          if (typeof window.toast === 'function') window.toast('\u274c You have been removed from this squad.');
          if (typeof window.doLogout === 'function') window.doLogout();
          return;
        }
        next();
      }).catch(function() { next(); });
    } else {
      next();
    }
  });
});

// ---------------------------------------------------------------
// HIGH FIX 8: XSS — patch innerHTML sinks that use user.picture URL
// renderGoogleUserInHeader uses innerHTML with S.user.picture (external URL).
// Sanitize by restricting to known Google CDN domain only.
// ---------------------------------------------------------------
(function() {
  const _timer2 = setInterval(function() {
    if (typeof window.renderGoogleUserInHeader === 'function') {
      clearInterval(_timer2);
      const _orig = window.renderGoogleUserInHeader;
      window.renderGoogleUserInHeader = function() {
        // Validate picture URL before it reaches innerHTML
        if (window.S && window.S.user && window.S.user.picture) {
          const pic = window.S.user.picture;
          // Only allow Google user content CDN
          if (!/^https:\/\/lh[0-9]+\.googleusercontent\.com\//.test(pic)) {
            window.S.user.picture = ''; // strip untrusted URL
          }
        }
        return _orig.apply(this, arguments);
      };
    }
  }, 50);
})();

console.log('[ReaperSquad] Security patch loaded ✅');

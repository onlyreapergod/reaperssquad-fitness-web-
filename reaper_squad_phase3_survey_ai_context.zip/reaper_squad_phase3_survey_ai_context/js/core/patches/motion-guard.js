// ============================================================
// REAPER SQUAD — Motion Guard (mobile performance)
// Load AFTER script.js.
//
// FIX 4: prefers-reduced-motion respected for particles/themes.
// FIX 4: Leaderboard interval cleaned up on logout/navigate.
// FIX 4: Theme particle intervals cleaned up on theme switch.
// ============================================================
(function() {
  'use strict';

  // ── Reduced motion: disable particle animations ──────────
  const mq = window.matchMedia('(prefers-reduced-motion: reduce)');

  function applyMotionPolicy(reduced) {
    // Pause all theme particle intervals when user prefers reduced motion
    if (reduced && window._themeIv) {
      clearInterval(window._themeIv);
      window._themeIv = null;
    }

    // Hide the themeLayer particles if they exist
    const layer = document.getElementById('themeLayer');
    if (layer) layer.style.display = reduced ? 'none' : '';
  }

  // Apply on load and on change
  applyMotionPolicy(mq.matches);
  mq.addEventListener('change', (e) => applyMotionPolicy(e.matches));

  // ── Patch applyTheme to respect reduced motion ──────────
  // Wait for script.js to define it, then wrap it.
  document.addEventListener('DOMContentLoaded', function() {
    const _waitTheme = setInterval(function() {
      if (typeof window.applyTheme === 'function') {
        clearInterval(_waitTheme);
        const _origApplyTheme = window.applyTheme;
        window.applyTheme = function(theme) {
          _origApplyTheme(theme);
          // Re-apply motion policy after theme starts its interval
          setTimeout(() => applyMotionPolicy(mq.matches), 50);
        };
      }
    }, 80);

    // ── Patch doLogout to clean up all intervals ──────────
    const _waitLogout = setInterval(function() {
      if (typeof window.doLogout === 'function') {
        clearInterval(_waitLogout);
        const _origLogout = window.doLogout;
        window.doLogout = function() {
          // Clean up leaderboard poll
          if (window.S && window.S.lbIv) {
            clearInterval(window.S.lbIv);
            window.S.lbIv = null;
          }
          // Clean up theme particles
          if (window._themeIv) {
            clearInterval(window._themeIv);
            window._themeIv = null;
          }
          // Clean up rest timer
          if (window.S && window.S.restIv) {
            clearInterval(window.S.restIv);
            window.S.restIv = null;
          }
          _origLogout.apply(this, arguments);
        };
      }
    }, 80);
  });

  console.log('[ReaperSquad] Motion guard loaded ✅');
})();

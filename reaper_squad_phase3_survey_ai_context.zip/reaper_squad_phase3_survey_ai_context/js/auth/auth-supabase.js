// ============================================================
// REAPER SQUAD — Auth Layer (browser build)
//
// Mapped to the authoritative schema (01_schema.sql / 02_security.sql):
// users (id UUID PRIMARY KEY == auth.users.id, username TEXT UNIQUE,
// name, squad_code, total_xp, streak, theme, is_owner, suspended,
// login_pts, last_login, sel_physique, phys_streak, profile_data,
// settings_data, rank, rank_xp).
//
// - users.id is the real identity column — auth.uid(), never username.
// - squad_code / is_owner on users are denormalized, trigger-maintained
//   caches of squad_members (see sync_user_squad_cache() in
//   02_security.sql); the client only ever reads them, never writes
//   them directly — protect_readonly_user_columns() silently discards
//   any client-sent value anyway.
// - There is no squad_chat or user_blobs table in the authoritative
//   schema — the chat and generic-blob helpers that used to live here
//   have been removed rather than pointed at invented tables.
// - Preserves all other function signatures for backward compatibility
//   (script.js / index.html call these exactly as before).
// ============================================================

(function () {
  const SB_URL = window._SB_URL || window.SB_URL || 'https://tfkaehpblumtgkkzasub.supabase.co';
  const SB_ANON_KEY = window._SB_KEY || window.SB_KEY ||
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRma2FlaHBibHVtdGdra3phc3ViIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkzNDAwNzgsImV4cCI6MjA5NDkxNjA3OH0.HSWwWE5GhF5iAE1mMn8M-OsCf2RWwugjSgeFQJOS71A';

  window.ReaperAuth = window.ReaperAuth || {};
  window.ReaperAuth._ready = false;
  let supabase = null;

  async function init() {
    try {
      const mod = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
      supabase = mod.createClient(SB_URL, SB_ANON_KEY);
      window.ReaperAuth._client = supabase;
      window.ReaperAuth._ready = true;
      document.dispatchEvent(new CustomEvent('reaperauth:ready'));

      supabase.auth.onAuthStateChange(function (event, session) {
        if (event === 'PASSWORD_RECOVERY') {
          document.dispatchEvent(new CustomEvent('reaperauth:password_recovery', { detail: { session: session } }));
        }
      });

      console.log('[ReaperAuth] Supabase Auth client ready ✅ (users schema)');
    } catch (e) {
      console.warn('[ReaperAuth] Failed to load supabase-js — Phase 2 auth unavailable:', e);
    }
  }
  init();

  function requireClient() {
    if (!supabase) throw new Error('ReaperAuth not ready yet — wait for the "reaperauth:ready" event.');
    return supabase;
  }

  // Map a users row -> the shape script.js / index.html expect.
  function mapRow(row) {
    return {
      user_id: row.id, // back-compat alias; users.id is the real column
      username: row.username,
      name: row.name || row.username,
      squad_code: row.squad_code || 'SQXXNI',
      total_xp: row.total_xp || 0,
      streak: row.streak || 0,
      theme: row.theme || 'dark',
      is_owner: !!row.is_owner,
      suspended: !!row.suspended,
      login_pts: row.login_pts,
      last_login: row.last_login,
      sel_physique: row.sel_physique,
      phys_streak: row.phys_streak,
      profile_data: row.profile_data,
      settings_data: row.settings_data,
      rank: row.rank,
      rank_xp: row.rank_xp,
      created_at: row.created_at
    };
  }

  // ── Auth ──────────────────────────────────────────────────────

  window.ReaperAuth.signUp = async function ({ email, password, name, username }) {
    const sb = requireClient();
    if (!/^[a-z0-9_]{3,30}$/.test(username)) {
      throw new Error('Username must be 3–30 chars, lowercase letters/numbers/underscores only.');
    }
    const { data: authData, error: authError } = await sb.auth.signUp({
      email,
      password,
      options: { data: { username } },
    });
    if (authError) throw authError;

    if (!authData.session) {
      return { ...authData, needsEmailConfirmation: true };
    }

    // Insert into users (PK = id = auth.uid()). squad_code/is_owner/
    // suspended are never client-set — protect_readonly_user_columns()
    // forces them to their real defaults on INSERT regardless, and
    // joined_at has its own `default now()` (timestamptz, not epoch ms).
    const { error: rowError } = await sb
      .from('users')
      .insert({
        id: authData.user.id,
        username: username,
        name: name || username,
        theme: 'dark'
      });
    if (rowError) {
      const isUsernameTaken =
        rowError.code === '23505' ||
        /duplicate key|already exists/i.test(rowError.message || '');
      try { await sb.auth.signOut(); } catch (_) { }
      const err = new Error(
        isUsernameTaken
          ? 'That username is already taken — please choose another one and try again.'
          : (rowError.message || 'Could not create your profile. Please try again.')
      );
      err.usernameTaken = isUsernameTaken;
      err.cause = rowError;
      throw err;
    }

    return authData;
  };

  window.ReaperAuth.signIn = async function ({ email, password }) {
    const sb = requireClient();
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  };

  window.ReaperAuth.signInWithGoogle = async function (idToken) {
    const sb = requireClient();
    const { data, error } = await sb.auth.signInWithIdToken({
      provider: 'google',
      token: idToken,
    });
    if (error) throw error;
    return data;
  };

  window.ReaperAuth.signOut = async function () {
    const sb = requireClient();
    const { error } = await sb.auth.signOut();
    if (error) throw error;
  };

  window.ReaperAuth.updatePassword = async function (newPassword) {
    const sb = requireClient();
    const { data, error } = await sb.auth.updateUser({ password: newPassword });
    if (error) throw error;
    return data;
  };

  window.ReaperAuth.getUser = async function () {
    const sb = requireClient();
    const { data: { user } } = await sb.auth.getUser();
    return user;
  };

  window.ReaperAuth.getSession = async function () {
    const sb = requireClient();
    const { data: { session } } = await sb.auth.getSession();
    return session;
  };

  window.ReaperAuth.onAuthChange = function (callback) {
    const sb = requireClient();
    return sb.auth.onAuthStateChange((_event, session) => callback(session));
  };

  // ── Profile  (users) ────────────────────────────────────────────

  window.ReaperAuth.getMyProfile = async function () {
    const sb = requireClient();
    const { data: { user } } = await sb.auth.getUser();
    if (!user) throw new Error('Not signed in');

    const { data, error } = await sb
      .from('users')
      .select('id, username, name, squad_code, total_xp, streak, theme, is_owner, suspended, login_pts, last_login, sel_physique, phys_streak, profile_data, settings_data, rank, rank_xp, created_at')
      .eq('id', user.id)
      .single();
    if (error) throw error;

    return mapRow(data);
  };

  window.ReaperAuth.ensureProfile = async function (defaults) {
    const sb = requireClient();
    try {
      return await window.ReaperAuth.getMyProfile();
    } catch (e) {
      // PGRST116 = "no rows" from .single() — fall through and create one.
      if (!e || e.code !== 'PGRST116') throw e;
    }

    const { data: { user } } = await sb.auth.getUser();
    if (!user) throw new Error('Not signed in');

    const meta = user.user_metadata || {};
    const displayName = (defaults && defaults.name) || meta.name || meta.full_name ||
      (user.email || 'Reaper').split('@')[0];
    let base = ((defaults && defaults.username) || meta.username ||
      (user.email || 'reaper').split('@')[0])
      .toLowerCase().replace(/[^a-z0-9_]/g, '_').slice(0, 30);
    if (base.length < 3) base = (base + '___').slice(0, 3);

    let lastError = null;
    for (let attempt = 0; attempt < 5; attempt++) {
      const candidate = attempt === 0 ? base : base.slice(0, 25) + '_' + Math.random().toString(36).slice(2, 6);

      const { error: insertError } = await sb
        .from('users')
        .insert({
          id: user.id,
          username: candidate,
          name: displayName,
          theme: 'dark'
        });

      if (!insertError) {
        return await window.ReaperAuth.getMyProfile();
      }

      lastError = insertError;
      const detail = (insertError.message || '') + ' ' + (insertError.details || '');
      // If a row for this id already exists (raced with another
      // concurrent sign-in attempt), just fetch it instead of failing.
      const isIdDup = insertError.code === '23505' && /\bid\b/i.test(detail);
      if (isIdDup) {
        return await window.ReaperAuth.getMyProfile();
      }
      const isUsernameDup = insertError.code === '23505' ||
        /duplicate key|already exists/i.test(insertError.message || '');
      if (!isUsernameDup) throw insertError;
      // username collided — loop and try a suffixed candidate
    }
    throw lastError || new Error('Could not create your profile — please try again.');
  };

  window.ReaperAuth.updateProfile = async function (fields) {
    const sb = requireClient();
    const { data: { user } } = await sb.auth.getUser();
    if (!user) throw new Error('Not signed in');

    const safe = {};
    if (fields.name !== undefined) safe.name = fields.name;
    if (fields.display_name !== undefined) safe.name = fields.display_name; // back-compat alias
    if (fields.theme !== undefined) safe.theme = fields.theme;
    if (fields.sel_physique !== undefined) safe.sel_physique = fields.sel_physique;
    if (fields.phys_streak !== undefined) safe.phys_streak = fields.phys_streak;
    if (fields.profile_data !== undefined) safe.profile_data = fields.profile_data;
    if (fields.settings_data !== undefined) safe.settings_data = fields.settings_data;
    // Never allow the client to set is_owner or suspended — the
    // users_update_own RLS policy rejects any change to them anyway.

    const { data, error } = await sb
      .from('users')
      .update(safe)
      .eq('id', user.id);
    if (error) throw error;
    return data;
  };

  // ── Scores  (daily_scores) ────────────────────────────────────

  window.ReaperAuth.upsertScore = async function ({ pts, date }) {
    const sb = requireClient();
    if (pts < 0 || pts > 10) throw new Error('pts must be 0–10');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('date must be YYYY-MM-DD');

    const { data: { user } } = await sb.auth.getUser();
    if (!user) throw new Error('Not signed in');
    const profile = await window.ReaperAuth.getMyProfile();
    const { data, error } = await sb
      .from('daily_scores')
      .upsert(
        { user_id: user.id, username: profile.username, name: profile.name, squad_code: profile.squad_code, pts, date, exercises: [] },
        { onConflict: 'user_id,date' }
      );
    if (error) throw error;
    return data;
  };

  window.ReaperAuth.getScores = async function ({ date } = {}) {
    const sb = requireClient();
    let q = sb.from('daily_scores').select('username, name, pts, date, squad_code');
    if (date) q = q.eq('date', date);
    const { data, error } = await q;
    if (error) throw error;
    return data;
  };

  // NOTE: there is no squad_chat or user_blobs table in the authoritative
  // schema (01_schema.sql says both are deliberately absent), so the
  // sendChatMessage/deleteChatMessage/getChatMessages and
  // upsertBlob/getBlob/deleteBlob helpers that used to live here have
  // been removed rather than pointed at invented tables. Callers that
  // still reference window.ReaperAuth.sendChatMessage etc. degrade
  // gracefully since those callers already feature-detect the function
  // before calling it.

  // ── Kick / Unkick  (owner-only, goes through /api/kick-user) ────

  async function callKickApi(payload) {
    const session = await window.ReaperAuth.getSession();
    if (!session) throw new Error('Not signed in');
    const resp = await fetch('/api/kick-user', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + session.access_token,
      },
      body: JSON.stringify(payload),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  window.ReaperAuth.kickUser = function (username, reason) {
    return callKickApi({ action: 'kick', username, reason });
  };

  window.ReaperAuth.unkickUser = function (username) {
    return callKickApi({ action: 'unkick', username });
  };
})();

// ============================================================
// REAPER SQUAD — Rank Engine  (rank-engine.js)
//
// DEPENDS ON (must load before this file):
//   • script.js   — getTotalXP(), GAMI_BADGES, calcStreak(),
//                   S (global app state), lsGet()
//
// EXPOSES (via window.RankEngine):
//   calculateXP(opts?)   → number
//   getRank(xp?)         → { name, emoji, threshold, index }
//   getNextRank(xp?)     → { name, emoji, threshold, index } | null
//   getProgress(xp?)     → number  0-100
//   getRemainingXP(xp?)  → number
//
// Each helper accepts an optional pre-computed XP value so callers
// can batch-compute without calling getTotalXP() multiple times.
// When omitted, the function reads the live XP from localStorage
// via the existing getTotalXP() (defined in script.js).
//
// FORMULA:
//   XP = (Points × 100) + Mission Bonus + Badge Bonus + Streak Bonus
//
// WHERE:
//   Points        = getTotalXP() — the cumulative raw points already
//                   tracked by script.js (habits + exercise + steps,
//                   each day up to 6 pts) × internal XP multipliers
//                   applied by addXP().  We treat getTotalXP() as the
//                   "Points" input — it is the single authoritative
//                   source of truth for base XP (no duplication).
//
//   Mission Bonus = 500 × number of "full day" completions in the
//                   rolling 30-day window.  A full day = calcPts() ≥ 6
//                   on any past date, read from localStorage keys
//                   ex_<user>_<date> and hb_<user>_<date>.
//
//   Badge Bonus   = sum of numeric XP values for all unlocked
//                   GAMI_BADGES (those with locked:false in the global
//                   array defined in script.js). String XP labels
//                   like "+100 XP" are parsed to integers.
//
//   Streak Bonus  = streak_days × 50  (capped at 365 × 50 = 18 250)
//                   Uses calcStreak() from script.js; it already caches
//                   the result in localStorage so there is no extra
//                   network round-trip.
//
// RANK THRESHOLDS (8 ranks):
//   0       → Initiate
//   2 500   → Raven
//   7 500   → Phantom
//   16 000  → Executioner
//   30 000  → Harbinger
//   50 000  → Reaper
//   80 000  → Reaper Sovereign
//   120 000 → Reaper Ascendant
//
// EDGE CASES:
//   • XP < 0        → clamped to 0 (safety guard)
//   • No user       → calculateXP() returns 0; all rank calls fall
//                     back to Initiate / no-next-rank
//   • getTotalXP()  → gracefully handles undefined (returns 0)
//   • GAMI_BADGES   → if the global array is not yet defined (script.js
//                     not yet loaded), badgeBonus defaults to 0
//   • calcStreak()  → if unavailable, streakBonus defaults to 0
//   • calcPts()     → full-day scan falls back to 0 if localStorage
//                     keys are absent
//   • NaN anywhere  → each bonus is guarded with || 0
// ============================================================

(function (global) {
  'use strict';

  // ── Rank table ──────────────────────────────────────────────
  // Order matters: ascending threshold.
  var RANKS = [
    { name: 'Initiate',          emoji: '🌑', threshold: 0      },
    { name: 'Raven',             emoji: '🪶', threshold: 2500   },
    { name: 'Phantom',           emoji: '👻', threshold: 7500   },
    { name: 'Executioner',       emoji: '⚔️',  threshold: 16000  },
    { name: 'Harbinger',         emoji: '💀', threshold: 30000  },
    { name: 'Reaper',            emoji: '🔱', threshold: 50000  },
    { name: 'Reaper Sovereign',  emoji: '👑', threshold: 80000  },
    { name: 'Reaper Ascendant',  emoji: '⚡', threshold: 120000 }
  ];

  // ── Internal helpers ────────────────────────────────────────

  /**
   * Safely read an integer from getTotalXP().
   * Returns 0 if getTotalXP is unavailable or returns NaN.
   */
  function _baseXP() {
    if (typeof global.getTotalXP === 'function') {
      return parseInt(global.getTotalXP(), 10) || 0;
    }
    return 0;
  }

  /**
   * Compute Mission Bonus: 500 XP for each day in the last 30 days
   * where the user achieved a full-day score (6/6 pts).
   *
   * Reads ex_<user>_<date> and hb_<user>_<date> from localStorage —
   * the same keys already written by saveTodayData() in script.js.
   * No new writes. No new network calls.
   */
  function _missionBonus() {
    try {
      var S = global.S;
      if (!S || !S.user || !S.user.username) return 0;
      var u = S.user.username;
      var bonus = 0;
      var now = new Date();

      for (var i = 0; i < 30; i++) {
        var d = new Date(now);
        d.setDate(d.getDate() - i);
        var dateStr = d.toISOString().slice(0, 10);

        var exKey = 'ex_' + u + '_' + dateStr;
        var hbKey = 'hb_' + u + '_' + dateStr;

        var exercises = [];
        var habits = {};

        try {
          var exRaw = localStorage.getItem(exKey);
          exercises = exRaw ? JSON.parse(exRaw) : [];
        } catch (e) { exercises = []; }

        try {
          var hbRaw = localStorage.getItem(hbKey);
          habits = hbRaw ? JSON.parse(hbRaw) : {};
        } catch (e) { habits = {}; }

        // Replicate calcPts() logic exactly — do NOT call calcPts()
        // directly because it reads S.exercises / S.habits (today only).
        var steps = 0;
        try {
          var stepsRaw = localStorage.getItem('steps_' + u + '_' + dateStr);
          steps = parseInt(stepsRaw, 10) || 0;
        } catch (e) { steps = 0; }

        var habitPts = Object.values(habits).filter(Boolean).length;
        var exPt = exercises.length > 0 ? 1 : 0;
        var stepPt = steps >= 5000 ? 1 : 0;
        var dayScore = habitPts + exPt + stepPt;

        // Today: use live calcPts() if available (most accurate)
        if (i === 0 && typeof global.calcPts === 'function') {
          dayScore = global.calcPts();
        }

        if (dayScore >= 6) {
          bonus += 500;
        }
      }

      return bonus;
    } catch (e) {
      return 0;
    }
  }

  /**
   * Compute Badge Bonus: sum of XP values for all unlocked GAMI_BADGES.
   * GAMI_BADGES entries have xp as strings like "+100 XP" or "+500 XP".
   * We parse the integer out of that string.
   */
  function _badgeBonus() {
    try {
      var badges = global.GAMI_BADGES;
      if (!Array.isArray(badges)) return 0;

      return badges.reduce(function (total, badge) {
        if (badge.locked) return total;
        // Parse "+100 XP" → 100, "+500 XP" → 500, etc.
        var xpStr = String(badge.xp || '');
        var match = xpStr.match(/\d+/);
        var xpVal = match ? parseInt(match[0], 10) : 0;
        return total + (xpVal || 0);
      }, 0);
    } catch (e) {
      return 0;
    }
  }

  /**
   * Compute Streak Bonus: streak_days × 50.
   * Uses the existing calcStreak() which caches in localStorage.
   */
  function _streakBonus() {
    try {
      var S = global.S;
      if (!S || !S.user) return 0;

      var streak = 0;
      if (typeof global.calcStreak === 'function') {
        streak = global.calcStreak(S.user.username) || 0;
      } else if (typeof global.getStreak === 'function') {
        streak = global.getStreak(S.user.username) || 0;
      }

      // Cap at 365 days to prevent any runaway values
      streak = Math.min(Math.max(parseInt(streak, 10) || 0, 0), 365);
      return streak * 50;
    } catch (e) {
      return 0;
    }
  }

  // ── Public API ──────────────────────────────────────────────

  var RankEngine = {};

  /**
   * calculateXP(opts?)
   *
   * Returns the full XP total according to the formula:
   *   XP = (Points × 100) + Mission Bonus + Badge Bonus + Streak Bonus
   *
   * "Points" = the existing getTotalXP() value (raw accumulated XP
   * from habits / exercises / steps, already computed by script.js).
   *
   * opts (optional):
   *   { points, missionBonus, badgeBonus, streakBonus }
   *   Each is optional — if omitted the engine computes it live.
   *   Pass pre-computed values to avoid redundant calls.
   *
   * @returns {number}
   */
  RankEngine.calculateXP = function (opts) {
    opts = opts || {};

    var points      = (typeof opts.points      === 'number') ? opts.points      : _baseXP();
    var mission     = (typeof opts.missionBonus === 'number') ? opts.missionBonus : _missionBonus();
    var badge       = (typeof opts.badgeBonus  === 'number') ? opts.badgeBonus  : _badgeBonus();
    var streak      = (typeof opts.streakBonus === 'number') ? opts.streakBonus  : _streakBonus();

    // Clamp each component to non-negative integers
    points  = Math.max(0, parseInt(points, 10)  || 0);
    mission = Math.max(0, parseInt(mission, 10) || 0);
    badge   = Math.max(0, parseInt(badge, 10)   || 0);
    streak  = Math.max(0, parseInt(streak, 10)  || 0);

    return (points * 100) + mission + badge + streak;
  };

  /**
   * getRank(xp?)
   *
   * Returns the rank object the user currently holds for the given XP.
   * Falls back to live calculateXP() when xp is not provided.
   *
   * @param {number} [xp]
   * @returns {{ name: string, emoji: string, threshold: number, index: number }}
   */
  RankEngine.getRank = function (xp) {
    var totalXP = (typeof xp === 'number') ? Math.max(0, xp) : RankEngine.calculateXP();
    var current = RANKS[0];
    var idx = 0;

    for (var i = 0; i < RANKS.length; i++) {
      if (totalXP >= RANKS[i].threshold) {
        current = RANKS[i];
        idx = i;
      }
    }

    return {
      name:      current.name,
      emoji:     current.emoji,
      threshold: current.threshold,
      index:     idx
    };
  };

  /**
   * getNextRank(xp?)
   *
   * Returns the next rank above the user's current rank, or null when
   * the user is already at the highest rank (Reaper Ascendant).
   *
   * @param {number} [xp]
   * @returns {{ name: string, emoji: string, threshold: number, index: number } | null}
   */
  RankEngine.getNextRank = function (xp) {
    var totalXP  = (typeof xp === 'number') ? Math.max(0, xp) : RankEngine.calculateXP();
    var current  = RankEngine.getRank(totalXP);
    var nextIdx  = current.index + 1;

    if (nextIdx >= RANKS.length) {
      return null; // Already at max rank
    }

    return {
      name:      RANKS[nextIdx].name,
      emoji:     RANKS[nextIdx].emoji,
      threshold: RANKS[nextIdx].threshold,
      index:     nextIdx
    };
  };

  /**
   * getProgress(xp?)
   *
   * Returns a 0–100 percentage representing how far the user is between
   * their current rank threshold and the next one.
   * Returns 100 when at max rank (Reaper Ascendant).
   *
   * @param {number} [xp]
   * @returns {number}  integer 0–100
   */
  RankEngine.getProgress = function (xp) {
    var totalXP  = (typeof xp === 'number') ? Math.max(0, xp) : RankEngine.calculateXP();
    var current  = RankEngine.getRank(totalXP);
    var next     = RankEngine.getNextRank(totalXP);

    if (!next) return 100; // Max rank

    var rangeTotal = next.threshold - current.threshold;
    var earned     = totalXP - current.threshold;

    if (rangeTotal <= 0) return 100; // Degenerate case guard

    var pct = Math.floor((earned / rangeTotal) * 100);
    return Math.min(Math.max(pct, 0), 100);
  };

  /**
   * getRemainingXP(xp?)
   *
   * Returns how many XP points still needed to reach the next rank.
   * Returns 0 when at max rank.
   *
   * @param {number} [xp]
   * @returns {number}
   */
  RankEngine.getRemainingXP = function (xp) {
    var totalXP = (typeof xp === 'number') ? Math.max(0, xp) : RankEngine.calculateXP();
    var next    = RankEngine.getNextRank(totalXP);

    if (!next) return 0; // Already at Reaper Ascendant

    return Math.max(0, next.threshold - totalXP);
  };

  /**
   * getRankTable()
   *
   * Returns a read-only copy of the full rank table.
   * Useful for rendering rank lists in the UI without importing the array.
   *
   * @returns {Array}
   */
  RankEngine.getRankTable = function () {
    return RANKS.map(function (r) {
      return { name: r.name, emoji: r.emoji, threshold: r.threshold };
    });
  };

  /**
   * persistRank()
   *
   * Computes the current full XP and writes it to localStorage under
   * the key "rankXP_<username>" for instant local UI feedback.
   * cloud_sync.js intercepts this key (type "userrow") and triggers a
   * debounced users write for the current user — rank/rank_xp
   * themselves are server-computed (compute_user_stats() in
   * 02_security.sql) and are not sent from here.
   *
   * Safe to call on every updateScore() tick; the debounce in
   * cloud_sync.js (1 000 ms) absorbs rapid successive calls.
   *
   * @returns {number}  the calculated XP that was persisted
   */
  RankEngine.persistRank = function () {
    try {
      var S = global.S;
      if (!S || !S.user || !S.user.username) return 0;
      var xp = RankEngine.calculateXP();
      // lsSet is overridden by cloud_sync.js — writes localStorage AND
      // queues a Supabase upsert.  Fall back to raw localStorage if
      // cloud_sync hasn't loaded yet (e.g. offline first boot).
      if (typeof global.lsSet === 'function') {
        global.lsSet('rankXP_' + S.user.username, xp);
      } else {
        try {
          localStorage.setItem('rankXP_' + S.user.username, JSON.stringify(xp));
        } catch (e) { /* storage full / private mode */ }
      }
      return xp;
    } catch (e) {
      return 0;
    }
  };

  /**
   * updateHeaderRankBadge()
   *
   * Updates the #hdrRank element in the header to show the current
   * rank name instead of the leaderboard position number.
   *
   * The existing updateHeaderRank() in script.js only sets "#?" when
   * the element still shows "#—".  This function replaces that with
   * the full rank name + emoji, and is designed to be called from
   * updateScore() without touching any UI element script.js owns.
   *
   * Idempotent — safe to call on every score update tick.
   */
  RankEngine.updateHeaderRankBadge = function () {
    try {
      var el = document.getElementById('hdrRank');
      if (!el) return;
      var xp   = RankEngine.calculateXP();
      var rank = RankEngine.getRank(xp);
      el.textContent = rank.emoji + ' ' + rank.name;
      el.title = xp.toLocaleString() + ' XP';
    } catch (e) { /* DOM not ready */ }
  };

  // ── Expose on window ────────────────────────────────────────
  global.RankEngine = RankEngine;

}(window));

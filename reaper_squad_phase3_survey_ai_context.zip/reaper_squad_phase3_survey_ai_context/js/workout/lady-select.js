// Lady Anime Physique — Select, Render, Choose functions
// Depends on: LADY_ANIME_PHYSIQUES (lady-physiques.js), script.js globals

window._selectedLadyPhysique = null;

// RESTORED: was called from lady-select.js, script.js, train_mode.js and
// home_skill_plan.js but never defined anywhere — every call threw
// "ReferenceError: loadSavedLadyPhysique is not defined" (the one in
// openLadyAnimeSelectPage() below is unguarded, so it's the one that
// actually crashed). Mirrors the male loadSavedPhysique()/getSavedPhysiqueKey()
// pattern in script.js, reading the same "selLadyPhys_<username>" key that
// chooseLadyAnimeChar() below already writes to via localStorage.setItem.
function loadSavedLadyPhysique(){
  try{
    var key = "selLadyPhys_" + (window.S && window.S.user ? window.S.user.username : "guest");
    var raw = localStorage.getItem(key);
    if(!raw) return;
    var saved = JSON.parse(raw);
    if(!saved || !saved.id) return;
    var found = (typeof LADY_ANIME_PHYSIQUES !== "undefined")
      ? LADY_ANIME_PHYSIQUES.find(function(e){ return e.id === saved.id; })
      : null;
    if(found) window._selectedLadyPhysique = found;
  }catch(e){}
}

function openLadyAnimeSelectPage(){
  if(!window._selectedLadyPhysique)loadSavedLadyPhysique();
  document.querySelectorAll(".page").forEach(function(e){e.classList.add("hidden")});
  showPage(document.getElementById("pgLadyAnimeSelect"));
  renderLadyAnimeCharGrid("all");
}

function closeLadyAnimeSelectPage(){
  var e=document.getElementById("pgLadyAnimeSelect");
  e&&e.classList.add("hidden");
  var t=document.getElementById("pgTrain");
  t&&t.classList.remove("hidden");
  renderTrainPage();
}

function filterLadyAnimeChars(e,t){
  document.querySelectorAll(".lady-filter-btn").forEach(function(e){e.classList.remove("active")});
  e.classList.add("active");
  renderLadyAnimeCharGrid(t);
}

function renderLadyAnimeCharGrid(t){
  var a=window._selectedLadyPhysique?window._selectedLadyPhysique.id:null;
  var grid=document.getElementById("ladyAnimeCharGrid");
  if(!grid)return;
  var filtered=LADY_ANIME_PHYSIQUES.filter(function(e){
    if(t==="all")return true;
    if(t==="strength")return e.stats.strength>=88;
    if(t==="speed")return e.stats.speed>=90;
    if(t==="aesthetic")return e.stats.aesthetics>=95;
    if(t==="endurance")return e.stats.endurance>=88;
    return true;
  });
  grid.innerHTML=filtered.map(function(e){
    var sel=e.id===a;
    return '<div class="anime-char-card'+(sel?" selected-card":"")+'" id="lacard_'+e.id+'">'
      +'<div class="acc-top">'
      +'<div class="acc-emoji-wrap" style="background:'+e.glow+';border-color:'+e.border+'">'+e.emoji+'</div>'
      +'<div class="acc-info">'
      +'<div class="acc-name" style="color:'+e.color+'">'+e.name+'</div>'
      +'<div class="acc-anime">'+e.anime+'</div>'
      +'<div class="acc-desc">'+e.desc+'</div>'
      +'</div></div>'
      +'<div class="acc-stats">'
      +ladyStatBar("💪","Strength",e.stats.strength,e.color)
      +ladyStatBar("🏃","Endurance",e.stats.endurance,e.color)
      +ladyStatBar("⚡","Speed",e.stats.speed,e.color)
      +ladyStatBar("✨","Aesthetic",e.stats.aesthetics,e.color)
      +'</div>'
      +'<div class="acc-bottom">'
      +'<div class="acc-time">⏱ '+e.minTime+'</div>'
      +'<button class="acc-select-btn'+(sel?" chosen":"")+'" onclick="chooseLadyAnimeChar(\''+e.id+'\')">'+(sel?"✓ Selected":"Choose →")+'</button>'
      +'</div></div>';
  }).join("");
}

function ladyStatBar(e,t,a,i){
  return '<div class="acc-stat-row"><div class="acc-stat-ico">'+e+'</div><div class="acc-stat-bar"><div class="acc-stat-fill" style="width:'+a+'%;background:'+i+'"></div></div><div class="acc-stat-val">'+a+'</div></div>';
}

function chooseLadyAnimeChar(t){
  var e=LADY_ANIME_PHYSIQUES.find(function(e){return e.id===t});
  if(!e)return;
  window._selectedLadyPhysique=e;
  document.querySelectorAll("#ladyAnimeCharGrid .anime-char-card").forEach(function(e){e.classList.remove("selected-card")});
  document.querySelectorAll("#ladyAnimeCharGrid .acc-select-btn").forEach(function(e){e.classList.remove("chosen");e.textContent="Choose →"});
  var card=document.getElementById("lacard_"+t);
  if(card){card.classList.add("selected-card");var btn=card.querySelector(".acc-select-btn");if(btn){btn.classList.add("chosen");btn.textContent="✓ Selected";}}
  if(typeof toast==="function")toast(e.emoji+" "+e.name+" selected! 🌸");
  // Save to localStorage like anime physique
  try{localStorage.setItem("selLadyPhys_"+(window.S&&window.S.user?window.S.user.username:"guest"),JSON.stringify({id:e.id}));}catch(x){}
  // Update preview in train page
  var prev=document.getElementById("selectedLadyPhysiquePreview");
  if(prev){
    prev.style.display="flex";
    var em=document.getElementById("selLadyPhysEmoji");var nm=document.getElementById("selLadyPhysName");var an=document.getElementById("selLadyPhysAnime");
    if(em)em.textContent=e.emoji;if(nm){nm.textContent=e.name;nm.style.color=e.color;}if(an)an.textContent=e.anime;
  }
  setTimeout(function(){
    closeLadyAnimeSelectPage();
    setTimeout(function(){selectLadyPhysique(t);},300);
  },600);
}

function selectLadyPhysique(t){
  var e=LADY_ANIME_PHYSIQUES.find(function(e){return e.id===t});
  if(!e)return;
  window._selectedLadyPhysique=e;
  window._gymMode=null;
  var modal=document.getElementById("physiqueModal");
  var body=document.getElementById("physiqueModalBody");
  if(!modal||!body)return;
  body.scrollTop=0;
  var label=modal.querySelector(".phys-modal-label");
  if(label){label.textContent=e.emoji+" "+e.name;label.style.color=e.color;}
  body.innerHTML='<div class="phys-modal-hero" style="--phm-bg:'+e.glow+'">'
    +'<div class="phm-glow-bg"></div>'
    +'<div class="phm-emoji">'+e.emoji+'</div>'
    +'<div class="phm-name" style="background:linear-gradient(135deg,'+e.color+',#ff69b4);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text">'+e.name+'</div>'
    +'<div class="phm-anime">'+e.anime+'</div>'
    +'<div class="phm-time-pill">⏱ Min Time: '+e.minTime+'</div>'
    +'</div>'
    +'<div class="phm-body">'
    +'<div class="phm-desc">'+e.desc+'</div>'
    +'<div class="phm-sec-title">🎯 Key Traits</div>'
    +'<div class="phm-traits">'+e.traits.map(function(t){return'<div class="phm-trait"><div class="phm-trait-dot" style="background:'+e.color+';box-shadow:0 0 6px '+e.color+'"></div><span>'+t+'</span></div>';}).join("")+'</div>'
    +'<div class="phm-sec-title">📊 Stats</div>'
    +'<div class="phm-stats">'+statBar("💪 Strength",e.stats.strength,e.color)+statBar("🏃 Endurance",e.stats.endurance,e.color)+statBar("⚡ Speed",e.stats.speed,e.color)+statBar("✨ Aesthetics",e.stats.aesthetics,e.color)+'</div>'
    +'<div style="height:1px;background:linear-gradient(90deg,transparent,var(--border),transparent);margin-bottom:16px"></div>'
    +'<div class="gym-pick-title">💪 Tu kaise train karegi?</div>'
    +'<div class="gym-pick-grid">'
    +'<div class="gym-choice-box" id="choiceGym" onclick="selectGymMode(\'gym\')"><div class="gcb-ico">🏋️</div><div class="gcb-title">Gym Access</div><div class="gcb-sub">Weights, barbells<br>machines sab available</div></div>'
    +'<div class="gym-choice-box" id="choiceNoGym" onclick="selectGymMode(\'nogym\')"><div class="gcb-ico">🏠</div><div class="gcb-title">No Gym</div><div class="gcb-sub">Ghar pe bodyweight<br>zero equipment</div></div>'
    +'</div>'
    +'<div id="askAiBtn" style="display:none">'
    +'<div class="days-pick-wrap"><div class="days-pick-title">📅 Kitne din train karna hai?</div>'
    +'<div class="days-pick-grid">'+[3,4,5,6,7].map(function(e){return'<div class="days-chip" id="dayChip'+e+'" onclick="selectDays('+e+')">'+e+' din</div>';}).join("")+'</div></div>'
    +'<div id="generatePlanBtn" style="display:none;margin-top:12px"><button class="ai-cta-btn" style="background:linear-gradient(135deg,'+e.color+',#ff69b4)" onclick="generateLadyWorkoutPlan()">🌸 Plan Banao →</button></div>'
    +'</div></div>';
  modal.classList.remove("hidden");
  requestAnimationFrame(function(){
    body.querySelectorAll(".phm-stat-bar-fill,.phys-bar-fill").forEach(function(e){var t=e.style.width;e.style.width="0";requestAnimationFrame(function(){e.style.width=t;});});
  });
}

function generateLadyWorkoutPlan(){
  var e=window._selectedLadyPhysique;
  var n=window._gymMode;
  var s=window._trainDays||4;
  if(!e||!n)return;
  var prompt='Mujhe '+e.name+' ('+e.anime+') jaisi female physique chahiye. '+(n==="gym"?"gym available hai — barbells, dumbbells, machines sab use kar sakti hoon":"ghar pe train karna hai — sirf bodyweight exercises, koi equipment nahi")+'. Mujhe '+s+' din/week ka workout plan chahiye. IMPORTANT: Sirf JSON return karo, koi extra text nahi. Format bilkul yeh hona chahiye:\n{"planName": "Plan ka naam","days": [{"day": "Day 1 — Push","exercises": [{"name": "Push Up","sets": 4,"reps": "20","emoji": "🤸"}]}],"tip": "Ek motivational tip Hinglish mein"}\nExactly '+s+' day objects banao. Gym mode: '+n+'. Har day mein 4-6 exercises rakho. Real, effective exercises use karo jo '+e.name+' physique ke liye best hain. Female-specific exercises include karo jaise hip thrust, glute bridge, etc.';
  var body=document.getElementById("physiqueModalBody");
  if(!body)return;
  body.innerHTML='<div class="plan-loading"><div class="plan-loader-skull">🌸</div><div class="plan-loader-text">REAPER AI plan bana raha hai...</div><div class="plan-loader-bar"><div class="plan-loader-fill" id="planLoaderFill"></div></div><div class="plan-loader-sub" id="planLoaderSub">'+e.name+' ke secrets download ho rahe hain 💪</div></div>';
  var fill=document.getElementById("planLoaderFill");
  var tips=["Exercises calculate ho rahi hain...","Sets aur reps set ho rahe hain...","Final plan ready ho raha hai 💪"];
  var ti=0;
  var iv=setInterval(function(){ti=Math.min(ti+1,tips.length-1);var s=document.getElementById("planLoaderSub");if(s)s.textContent=tips[ti];},900);
  if(fill){fill.style.width="0%";setTimeout(function(){fill.style.width="90%"},100);}
  callGeminiForPlan(prompt,fill,iv,function(plan){renderWorkoutPlanUI(window._currentPlan=plan,window._currentPhys=e);},function(){renderPlanError();});
}
/* ============ END LADY ANIME PHYSIQUE ============ */
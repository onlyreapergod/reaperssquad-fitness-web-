// ============================================================
// CLOUD SYNC LAYER — Replaces localStorage for all game data
// Drop this BEFORE script.js in your HTML
//
// FIXES applied (v6 — conforms to 01_schema.sql / 02_security.sql):
//   • reaper_users -> users, keyed by id (== auth.users.id), not username
//   • daily_scores writes now always include user_id (required, not
//     populated by any trigger) and target the real (user_id, date)
//     unique constraint
//   • exercises is jsonb (not INTEGER) — always saved as an array
//   • exercises_count saved separately to its own column
//   • user_blobs does not exist in the authoritative schema — the
//     god_warned/god_disabled/god_autoUnban keys that used to sync
//     through it are now localStorage-only, same as urExercises/
//     workoutPlans_*
//   • %20 encoding — removed double-encodeURIComponent; raw values passed
//     to PostgREST eq. filter (PostgREST URL-decodes query params itself)
// ============================================================

(function() {

  const SB  = window._SB_URL  || "https://tfkaehpblumtgkkzasub.supabase.co";
  const KEY = window._SB_KEY  || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRma2FlaHBibHVtdGdra3phc3ViIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkzNDAwNzgsImV4cCI6MjA5NDkxNjA3OH0.HSWwWE5GhF5iAE1mMn8M-OsCf2RWwugjSgeFQJOS71A";

  // FIX: Separate base headers from upsert headers.
  // The original HDRS included Prefer: resolution=merge-duplicates globally,
  // which caused 404 on GET requests that don't support that Prefer value.
  const BASE_HDRS = {
    apikey: KEY,
    Authorization: "Bearer " + KEY,
    "Content-Type": "application/json"
  };

  const UPSERT_HDRS = Object.assign({}, BASE_HDRS, {
    Prefer: "resolution=merge-duplicates,return=minimal"
  });

  // ── Cloud user state cache (populated on login) ──
  window._cloudUser = {};

  // ── In-memory local cache for fast reads ──
  const _mem = {};

  // ── Keys that ALWAYS stay local (device prefs / session) ──
  // SCHEMA FIX: there is no user_blobs table in the authoritative schema
  // (01_schema.sql says it is deliberately absent), so god_warned/
  // god_disabled/god_autoUnban live here now too, alongside
  // urExercises/workoutPlans_* — all local-only until a documented
  // mapping onto an existing table exists.
  const LOCAL_ONLY = new Set([
    "theme", "gamiAv", "gamiTab", "gamiOpen", "gamiGridOpen",
    "currentUser", "pedometerEnabled", "fix_groq_key",
    "skillTree_v2", "skillTree_log_v2", "skillTree_streak_v1",
    "urExercises",
    "god_warned", "god_disabled", "god_autoUnban",
  ]);

  function getUsername() {
    try {
      var u = JSON.parse(localStorage.getItem("currentUser"));
      return u && u.username ? u.username : null;
    } catch(e) { return null; }
  }

  // ── Supabase helpers ──

  // FIX (Supabase 503 — Service Unavailable): neither sbGet() nor
  // sbUpsert() retried before this fix. Supabase's REST endpoint can
  // return a transient 503 (cold start after inactivity, brief outage,
  // momentary rate-limit) that succeeds a moment later — but a single
  // 503 here silently dropped the read (sbGet returned null, e.g. the
  // leaderboard row just came back empty) or the write (sbUpsert's
  // catch swallowed it — the score/profile change was lost until the
  // next debounced call happened to fire, if ever). Retry a small,
  // fixed number of times with a short backoff ONLY on 503 and on
  // network failures (fetch throwing) — never on 4xx, which are
  // permanent (bad request / conflict / not found) and would just
  // fail identically on retry.
  function _wait(ms) { return new Promise(function (res) { setTimeout(res, ms); }); }

  async function fetchWithRetry(url, opts, retries) {
    retries = retries == null ? 2 : retries;
    for (var attempt = 0; ; attempt++) {
      try {
        var r = await fetch(url, opts);
        if (r.status === 503 && attempt < retries) {
          await _wait(400 * Math.pow(2, attempt)); // 400ms, then 800ms
          continue;
        }
        return r;
      } catch (e) {
        if (attempt < retries) {
          await _wait(400 * Math.pow(2, attempt));
          continue;
        }
        throw e;
      }
    }
  }

  // FIX: Use raw (un-encoded) values in PostgREST eq. filters.
  // PostgREST decodes URL query parameters before comparing, so
  // encodeURIComponent was causing "john%20doe" to match literally
  // instead of matching "john doe". Raw spaces in query strings are
  // technically invalid per RFC but PostgREST handles them fine, and
  // encodeURIComponent is safe to keep only for blob_key which may
  // contain special characters like "workoutPlans_username".
  async function sbGet(table, filter) {
    var url = SB + "/rest/v1/" + table + "?" + filter + "&limit=1";
    try {
      var r = await fetchWithRetry(url, {
        headers: Object.assign({}, BASE_HDRS, {
          Range: "0-0",
          Prefer: "count=none"
        })
      });
      // FIX: 404 means table/endpoint missing; surface the error for debugging
      if (r.status === 404) {
        console.error("[cloud_sync] 404 on", table, "— check table exists and RLS allows SELECT");
        return null;
      }
      if (r.status === 503) {
        console.warn("[cloud_sync] 503 on", table, "— Supabase unavailable after retries, using local cache");
        return null;
      }
      var d = await r.json();
      return Array.isArray(d) ? d[0] || null : null;
    } catch(e) { return null; }
  }

  async function getWriteContext() {
    try {
      if (window.ReaperAuth && window.ReaperAuth._ready) {
        var session = await window.ReaperAuth.getSession();
        if (session && session.access_token && session.user && session.user.id) {
          return {
            userId: session.user.id,
            headers: Object.assign({}, BASE_HDRS, {
              Authorization: "Bearer " + session.access_token,
              Prefer: "resolution=merge-duplicates,return=minimal"
            })
          };
        }
      }
    } catch(e) {}
    // VERIFIED FIX (schema): users.id and daily_scores.user_id are both
    // NOT NULL with no trigger that populates them — sbUpsert() below
    // fills them in explicitly from this authenticated session, which
    // only resolves once ReaperAuth has a real signed-in session. The
    // old fallback used to send these writes with the anon key instead
    // whenever a session wasn't ready yet; without a real user id there
    // was nothing correct to put in that NOT NULL column, and RLS (`to
    // authenticated`) would reject an anon-key write here regardless.
    // Returning null lets sbUpsert() below skip the write entirely
    // until a real session exists, rather than sending a request the
    // database was always going to reject.
    return null;
  }

  async function sbUpsert(table, obj, conflict) {
    try {
      var ctx = await getWriteContext();
      if (!ctx) return; // no authenticated session yet — skip rather than send a doomed write
      var payload = Object.assign({}, obj);
      // SCHEMA FIX: users.id / daily_scores.user_id are required and
      // must be the caller's own id (RLS with check enforces this
      // anyway) — fill them in here so every call site gets this for
      // free instead of repeating it at each call site.
      if (table === "users" && !payload.id) payload.id = ctx.userId;
      if (table === "daily_scores" && !payload.user_id) payload.user_id = ctx.userId;
      var r = await fetchWithRetry(
        // FIX: conflict columns with comma must NOT be encoded (%2C breaks PostgREST)
        SB + "/rest/v1/" + table + "?on_conflict=" + conflict,
        { method: "POST", headers: ctx.headers, body: JSON.stringify(payload) }
      );
      if (r.status === 404) {
        console.error("[cloud_sync] 404 upsert on", table, "— table missing or RLS blocks INSERT");
      } else if (r.status === 503) {
        // Retries in fetchWithRetry already exhausted — write is lost for
        // this debounce cycle. localStorage still has the value (lsSet()
        // always writes there first), so the next lsSet() call on this key
        // schedules another debouncedWrite() and tries again; nothing to
        // recover here beyond making the failure visible.
        console.warn("[cloud_sync] 503 upsert on", table, "— Supabase unavailable after retries, will retry on next change");
      } else if (!r.ok) {
        // ROOT-CAUSE-VISIBILITY FIX: this branch previously logged only
        // r.status ("400 upsert on users — write rejected") and never read
        // the response body. PostgREST always returns a JSON error body on
        // non-2xx responses (code/message/details/hint) even when the
        // request used Prefer: return=minimal (that header only affects the
        // *success* representation) — that body is the only thing that
        // actually says *why* (missing column, NOT NULL violation, bad
        // on_conflict target, FK violation, etc.), and it was being thrown
        // away every time. Read and log it so the real cause is visible in
        // devtools instead of having to guess from the schema.
        var errBody = "";
        try { errBody = await r.clone().text(); } catch (e2) {}
        console.error("[cloud_sync]", r.status, "upsert on", table, "— write rejected. Payload sent:", payload, "Response body:", errBody);
      }
    } catch(e) {}
  }

  // ── Date helpers ──
  function todayStr() { return new Date().toISOString().slice(0, 10); }

  // ── Determine where a key lives ──
  function keyType(k) {
    if (LOCAL_ONLY.has(k)) return "local";
    if (/^ex_/.test(k) || /^hb_/.test(k) || /^xpAwarded_/.test(k) ||
        /^planEx_/.test(k) || /^steps_/.test(k)) return "daily";
    if (/^totalXP_/.test(k) || /^streak_/.test(k) || /^selPhys_/.test(k) ||
        /^physStreak_/.test(k) || /^tuProfile_/.test(k) || /^tuSettings_/.test(k) ||
        /^pts_/.test(k) || /^rankXP_/.test(k)) return "userrow";
    if (/^workoutPlans_/.test(k)) return "local";  // FIX: no user_blobs table
    return "local";
  }

  // ── Parse daily key: ex_tanishq_2026-05-28 → {type, user, date} ──
  function parseDailyKey(k) {
    var m = k.match(/^([^_]+)_([^_]+)_(\d{4}-\d{2}-\d{2})$/);
    if (!m) return null;
    return { type: m[1], user: m[2], date: m[3] };
  }

  // ── Debounce map for cloud writes ──
  var _debounce = {};
  function debouncedWrite(key, fn, delay) {
    if (_debounce[key]) clearTimeout(_debounce[key]);
    _debounce[key] = setTimeout(fn, delay || 600);
  }

  // ── Daily scores cloud cache ──
  var _dailyCache = {};

  function dailyCacheKey(user, date) { return user + "_" + date; }

  async function loadDailyFromCloud(user, date) {
    var ck = dailyCacheKey(user, date);
    if (_dailyCache[ck]) return _dailyCache[ck];

    var row = await sbGet(
      "daily_scores",
      "username=eq." + encodeURIComponent(user) + "&date=eq." + date
    );

    var data = { exercises: [], habits: {}, steps: 0, xpAwarded: {}, planEx: {} };
    if (row) {
      try {
        // FIX: exercises is now JSONB array, not INTEGER
        if (row.exercises) {
          data.exercises = typeof row.exercises === "string"
            ? JSON.parse(row.exercises)
            : (Array.isArray(row.exercises) ? row.exercises : []);
        }
      } catch(e) {}
      try { if (row.habits)     data.habits     = typeof row.habits     === "string" ? JSON.parse(row.habits)     : (row.habits     || {}); } catch(e) {}
      try { if (row.xp_awarded) data.xpAwarded  = typeof row.xp_awarded === "string" ? JSON.parse(row.xp_awarded) : (row.xp_awarded || {}); } catch(e) {}
      try { if (row.plan_ex)    data.planEx      = typeof row.plan_ex    === "string" ? JSON.parse(row.plan_ex)    : (row.plan_ex    || {}); } catch(e) {}
      data.steps = row.steps || 0;
    }
    _dailyCache[ck] = data;
    return data;
  }

  function saveDailyToCloud(user, date) {
    var ck = dailyCacheKey(user, date);
    var data = _dailyCache[ck] || {};
    debouncedWrite("daily_" + ck, async function() {
      var habits    = data.habits    || {};
      var exercises = data.exercises || [];
      var steps     = data.steps     || 0;
      var pts = Object.values(habits).filter(Boolean).length +
                (exercises.length > 0 ? 1 : 0) +
                (steps >= 5000 ? 1 : 0);

      await sbUpsert("daily_scores", {
        username:        user,
        date:            date,
        pts:             pts,
        name:            data.name,
        squad_code:      data.squad_code || "SQXXNI",
        exercises:       exercises,                            // FIX: JSONB array
        exercises_count: exercises.length,                    // FIX: new column
        habits:          habits,
        steps:           steps,
        xp_awarded:      data.xpAwarded || {},
        plan_ex:         data.planEx    || {},
        total_sets:      exercises.reduce(function(a, e) { return a + (e.sets || 0); }, 0),
        updated_at:      new Date().toISOString(),
        // SCHEMA FIX: target the real (user_id, date) unique constraint
        // (01_schema.sql) instead of a legacy (username, date) key.
        // user_id itself isn't set here — sbUpsert() (above) fills it in
        // from the authenticated session automatically, since
        // daily_scores.user_id is NOT NULL and no trigger populates it.
      }, "user_id,date");
    }, 800);
  }

  // ── User row cache ──
  var _userRowCache = {};

  async function loadUserRow(username) {
    if (_userRowCache[username]) return _userRowCache[username];
    var row = await sbGet("users", "username=eq." + encodeURIComponent(username));
    _userRowCache[username] = row || {};
    return _userRowCache[username];
  }

  function saveUserRow(username) {
    var data = _userRowCache[username] || {};
    debouncedWrite("userrow_" + username, async function() {
      // ROOT CAUSE FIX (persistent 400 on POST /rest/v1/users?on_conflict=id):
      // `data` here is `_userRowCache[username]`, which loadUserRow() seeds
      // directly from an unfiltered `GET /rest/v1/users?username=eq....`
      // (no `select=` param -> PostgREST returns every column). The old
      // code did `Object.assign({}, data)` and sent that WHOLE row back on
      // every debounced write — id, is_owner, squad_code, total_xp, streak,
      // rank, rank_xp, created_at, joined_at, updated_at, all of it,
      // regardless of whether this function had any business writing them.
      // Today those extra columns happen not to 400 (the numeric/boolean
      // "cache" columns are silently reset by protect_readonly_user_
      // columns(), and the timestamp columns happen to be valid values) —
      // but that's incidental, not guaranteed, and it's exactly the kind of
      // unreviewed, shape-shifting payload that turned "users.name missing"
      // into a 400 on every write the first time. Any future NOT NULL
      // column without a default, a stricter CHECK, or a renamed/removed
      // rank_tiers/squads row hit by a *stale* cached value would reproduce
      // the same class of bug immediately. Fix it once, structurally: only
      // ever send the columns this function actually owns.
      var payload = {
        username: username,
        // SCHEMA FIX (400 on every users upsert): users.name is NOT NULL
        // with no default (01_schema.sql). PostgREST performs this upsert
        // as INSERT ... ON CONFLICT (id) DO UPDATE — Postgres builds and
        // NOT-NULL-validates the candidate insert row BEFORE it resolves
        // the conflict, so an omitted/undefined name 400s on *every*
        // write, not just the first insert. Mirrors the same
        // `name || username` fallback doSignup()/ensureProfile() already
        // use in auth-supabase.js.
        name: (window.S && window.S.user && window.S.user.name) || username
      };
      if (data.theme !== undefined)         payload.theme         = data.theme;
      if (data.sel_physique !== undefined)  payload.sel_physique  = data.sel_physique;
      if (data.phys_streak !== undefined)   payload.phys_streak   = data.phys_streak;
      if (data.profile_data !== undefined)  payload.profile_data  = data.profile_data;
      if (data.settings_data !== undefined) payload.settings_data = data.settings_data;
      if (data.login_pts !== undefined)     payload.login_pts     = data.login_pts;
      if (data.last_login !== undefined)    payload.last_login    = data.last_login;
      // suspended / is_owner / squad_code / total_xp / streak / rank /
      // rank_xp / id / created_at / joined_at / updated_at are deliberately
      // never included — they are server-owned or auto-filled (id, by
      // sbUpsert below) and this function has no business round-tripping
      // stale copies of them.
      await sbUpsert("users", payload, "id");
    }, 1000);
  }

  // NOTE: there is no user_blobs table in the authoritative schema, so
  // the loadBlob/saveBlob helpers that used to sync god_warned/
  // god_disabled/god_autoUnban through it have been removed. Those keys
  // are now in LOCAL_ONLY above and never leave localStorage.

  // ── CORE OVERRIDE: lsGet ──
  window.lsGet = function(key) {
    if (_mem[key] !== undefined) {
      var v = _mem[key];
      return v === "__null__" ? null : v;
    }
    try {
      var t = localStorage.getItem(key);
      return t ? JSON.parse(t) : null;
    } catch(e) { return null; }
  };

  // ── CORE OVERRIDE: lsSet ──
  window.lsSet = function(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch(e) {}

    var type     = keyType(key);
    var username = getUsername();
    if (!username || type === "local") return;

    _mem[key] = value;

    if (type === "daily") {
      var parsed = parseDailyKey(key);
      if (!parsed) return;
      var ck = dailyCacheKey(parsed.user, parsed.date);
      if (!_dailyCache[ck]) _dailyCache[ck] = { exercises: [], habits: {}, steps: 0, xpAwarded: {}, planEx: {} };
      var fieldMap = { ex: "exercises", hb: "habits", steps: "steps", xpAwarded: "xpAwarded", planEx: "planEx" };
      var field = fieldMap[parsed.type];
      if (field) _dailyCache[ck][field] = value;
      saveDailyToCloud(parsed.user, parsed.date);
    }
    else if (type === "userrow") {
      // BUG FIX: this used to derive the cache key by stripping the known
      // prefix off `key` and then doing `.replace(/_.*/, "")`, which chops
      // off everything from the FIRST remaining underscore onward. Usernames
      // are allowed to contain underscores (ReaperAuth.signUp validates
      // against /^[a-z0-9_]{3,30}$/), so for e.g. key = "tuProfile_test_user"
      // this produced u = "test" instead of "test_user" — a silently wrong,
      // truncated cache key that doesn't match the row loadUserRow() already
      // populated under the real username. saveUserRow() would then be
      // called with that wrong value and send it as the `username` column
      // in the /rest/v1/users?on_conflict=id upsert for the real
      // (correctly-identified-by-id) user's row. `username` here is always
      // the current signed-in user (from getUsername(), already validated
      // non-null above) — every call site that sets one of these prefixed
      // keys does so for the current user, so there is no parsing to do.
      var u = username;
      if (!_userRowCache[u]) _userRowCache[u] = {};
      if      (/^totalXP_/.test(key))    { /* SECURITY FIX: total_xp is now server-computed
                                              by compute_user_stats() (02_security.sql) from
                                              daily_scores — stop sending a client value. */ }
      else if (/^streak_/.test(key))     { /* SECURITY FIX: same as total_xp — server-computed. */ }
      else if (/^selPhys_/.test(key))    _userRowCache[u].sel_physique   = JSON.stringify(value);
      else if (/^physStreak_/.test(key)) _userRowCache[u].phys_streak    = JSON.stringify(value); // FIX: column now exists
      else if (/^tuProfile_/.test(key))  _userRowCache[u].profile_data   = value;
      else if (/^tuSettings_/.test(key)) _userRowCache[u].settings_data  = value;
      else if (/^rankXP_/.test(key)) {
        // SECURITY FIX: rank_xp / rank / total_xp / streak are all
        // server-computed by compute_user_stats() (02_security.sql),
        // fired by the daily_scores_recompute_stats trigger every time
        // a daily_scores row is written — never from a client-sent
        // value on users. Stop sending a client value; RankEngine.
        // persistRank() still writes rankXP_<username> to localStorage
        // for the current user's own instant UI feedback (header badge,
        // "isMe" leaderboard row); the number itself just no longer
        // travels over the wire to users.
      }
      else if (/^pts_/.test(key)) {
        // FIX: login_pts, last_login, suspended columns now in schema
        _userRowCache[u].login_pts  = value.pts;
        _userRowCache[u].last_login = value.lastLogin;
        _userRowCache[u].suspended  = value.suspended;
      }
      saveUserRow(u);
    }
    // NOTE: "blob" and "kicked" key types no longer exist — god_warned/
    // god_disabled/god_autoUnban are LOCAL_ONLY (no user_blobs table),
    // and squad moderation now goes through /api/kick-user ->
    // squad_members (no kicked_users table either).
  };

  // ── Pre-populate from cloud on boot ──
  window._cloudBootstrap = async function(username) {
    if (!username) return;
    console.log("☁️ Cloud bootstrap for:", username);

    // 1. Load user row
    var userRow = await loadUserRow(username);
    if (userRow) {
      _userRowCache[username] = userRow;
      if (userRow.total_xp !== undefined) _mem["totalXP_" + username] = userRow.total_xp;
      if (userRow.streak   !== undefined) _mem["streak_"  + username] = userRow.streak;

      // FIX: read new columns login_pts / last_login / suspended
      if (userRow.login_pts !== undefined) {
        _mem["pts_" + username] = {
          pts:       (userRow.login_pts !== null && userRow.login_pts !== undefined) ? userRow.login_pts : 20,
          lastLogin: userRow.last_login || null,
          suspended: !!userRow.suspended
        };
      }
      if (userRow.sel_physique) {
        try { _mem["selPhys_" + username] = JSON.parse(userRow.sel_physique); }
        catch(e) { _mem["selPhys_" + username] = userRow.sel_physique; }
      }
      if (userRow.phys_streak) {
        try { _mem["physStreak_" + username] = JSON.parse(userRow.phys_streak); } catch(e) {}
      }
      if (userRow.profile_data)  _mem["tuProfile_"  + username] = userRow.profile_data;
      if (userRow.settings_data) _mem["tuSettings_" + username] = userRow.settings_data;
      if (userRow.theme)         _mem["theme"] = userRow.theme;
      // FIX P2: restore rank_xp so RankEngine.persistRank() has correct base after reload/login
      if (userRow.rank_xp !== undefined && userRow.rank_xp !== null) {
        _mem["rankXP_" + username] = userRow.rank_xp;
        try { localStorage.setItem("rankXP_" + username, JSON.stringify(userRow.rank_xp)); } catch(e) {}
      }
    }

    // 2. Load today's daily data
    var today = todayStr();
    var daily = await loadDailyFromCloud(username, today);
    if (daily) {
      _mem["ex_"        + username + "_" + today] = daily.exercises;
      _mem["hb_"        + username + "_" + today] = daily.habits;
      _mem["steps_"     + username + "_" + today] = daily.steps;
      _mem["xpAwarded_" + username + "_" + today] = daily.xpAwarded;
      _mem["planEx_"    + username + "_" + today] = daily.planEx;
      try {
        localStorage.setItem("ex_" + username + "_" + today, JSON.stringify(daily.exercises));
        localStorage.setItem("hb_" + username + "_" + today, JSON.stringify(daily.habits));
      } catch(e) {}
    }

    // 3. god_warned / god_disabled / god_autoUnban are LOCAL_ONLY now
    // (no user_blobs table exists) — window.lsGet() already reads them
    // straight from localStorage, so there is nothing to bootstrap here.

    console.log("☁️ Cloud bootstrap complete!");
  };

  // ── FIX 3: Register cloud bootstrap into shared bootApp middleware queue ──
  // Avoids racey setTimeout/setInterval overwrites of window.bootApp.
  document.addEventListener("DOMContentLoaded", function() {
    if (!window._bootAppMiddleware) window._bootAppMiddleware = [];
    window._bootAppMiddleware.push(function cloudMiddleware(user, next) {
      if (user && user.username) {
        window._cloudBootstrap(user.username)
          .then(function() { next(); })
          .catch(function() { next(); });
      } else {
        next();
      }
    });;
  });

  // v4 log replaced by v5 below;

  // ── FIX: Single-writer abstraction ──────────────────────────
  // script.js was calling sbUpsert("daily_scores", ...) directly
  // (in saveTodayData), bypassing cloud_sync's debounce and cache.
  // This caused last-write-wins races and exercises being saved as
  // integer counts (script.js) vs JSONB arrays (cloud_sync).
  //
  // Solution: expose window.CloudSync.saveDaily() which script.js
  // MUST call instead of direct sbUpsert. The patch below also
  // overrides window.sbUpsert for daily_scores writes so existing
  // calls in script.js are automatically routed through here.
  // ────────────────────────────────────────────────────────────

  const _origSbUpsert = window.sbUpsert;

  window.CloudSync = {
    /**
     * saveDaily(payload) — the ONLY place daily_scores gets written.
     * Merges payload into the in-memory cache then debounces the cloud write.
     *
     * @param {object} payload - { exercises, habits, steps, pts, name, squad_code, ... }
     */
    saveDaily(payload) {
      const username = getUsername();
      if (!username) return;
      const date = todayStr();
      const ck = dailyCacheKey(username, date);

      // Merge into cache — prefer JSONB array for exercises over integer count
      if (!_dailyCache[ck]) {
        _dailyCache[ck] = { exercises: [], habits: {}, steps: 0, xpAwarded: {}, planEx: {} };
      }

      // If caller passed exercises as integer (old script.js path), ignore it;
      // we always use the array from the cache.
      if (Array.isArray(payload.exercises)) {
        _dailyCache[ck].exercises = payload.exercises;
      }
      if (payload.habits && typeof payload.habits === 'object') {
        _dailyCache[ck].habits = payload.habits;
      }
      if (typeof payload.steps === 'number') {
        _dailyCache[ck].steps = payload.steps;
      }
      if (payload.squad_code) {
        _dailyCache[ck].squad_code = payload.squad_code;
      }
      if (payload.name) {
        _dailyCache[ck].name = payload.name;
      }

      // Sync mem keys so lsGet reads stay consistent
      _mem["ex_" + username + "_" + date] = _dailyCache[ck].exercises;
      _mem["hb_" + username + "_" + date] = _dailyCache[ck].habits;
      _mem["steps_" + username + "_" + date] = _dailyCache[ck].steps;

      saveDailyToCloud(username, date);
    }
  };

  // Intercept direct sbUpsert("daily_scores", ...) calls from script.js
  // and redirect them through the single-writer abstraction.
  window.sbUpsert = function(table, data, conflict) {
    if (table === 'daily_scores') {
      // Route through CloudSync.saveDaily to avoid double-write race
      window.CloudSync.saveDaily(data);
      return Promise.resolve([]);
    }
    return (_origSbUpsert || function() { return Promise.resolve([]); })(table, data, conflict);
  };

  console.log("☁️ Cloud Sync Layer loaded! (v5 — single-writer patch)");

  // FIX P1: Signal that cloud_sync lsGet/lsSet are authoritative.
  // arch-fixes.js reads this flag to know it must re-guard them after
  // script.js's global function declarations overwrite window.lsGet/lsSet.
  window._cloudSyncReady = true;
  window._cloudSyncLsGet = window.lsGet;
  window._cloudSyncLsSet = window.lsSet;

  // Remove the old v4 log that appears in the original file
})();

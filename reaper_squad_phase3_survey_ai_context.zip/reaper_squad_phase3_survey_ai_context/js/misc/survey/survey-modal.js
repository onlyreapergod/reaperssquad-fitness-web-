// ══════════════════════════════════════════════════════════════════
// REAPER SQUAD — Inline Survey Modal Engine (F-08)
// Ported from survey.html — logic reused verbatim, only the
// DOM context changed from a full page to #surveyModal overlay.
// ══════════════════════════════════════════════════════════════════

(function () {
  'use strict';

  // ── Questions (copied verbatim from survey.html) ───────────────
  var QUESTIONS = [
    {
      id: 'age', type: 'number', required: true,
      q: 'How Old Are You?', sub: '// your age determines your training capacity',
      placeholder: 'Enter your age', min: 10, max: 80, unit: 'YRS'
    },
    {
      id: 'gender', type: 'cards', required: true,
      q: 'Your Gender', sub: '// for customized physique programming',
      options: [
        { val: 'male',   icon: '♂️',  label: 'Male' },
        { val: 'female', icon: '♀️',  label: 'Female' },
        { val: 'other',  icon: '⚧️', label: 'Other' }
      ]
    },
    {
      id: 'body', type: 'hw', required: true,
      q: 'Height & Weight', sub: '// your physical stats'
    },
    {
      id: 'goal', type: 'cards', required: true,
      q: 'Primary Fitness Goal', sub: '// choose your battle',
      options: [
        { val: 'fat_loss',   icon: '🔥', label: 'Fat Loss',    sub: 'burn it down' },
        { val: 'muscle',     icon: '💪', label: 'Muscle Gain', sub: 'build the armor' },
        { val: 'aesthetics', icon: '⚡', label: 'Aesthetics',  sub: 'sculpt the god form' },
        { val: 'strength',   icon: '🏋️', label: 'Strength',    sub: 'become unbreakable' }
      ]
    },
    {
      id: 'level', type: 'cards', required: true,
      q: 'Current Fitness Level', sub: '// be honest, the reaper knows',
      options: [
        { val: 'beginner',     icon: '🌱', label: 'Beginner',     sub: '0-1 yr experience' },
        { val: 'intermediate', icon: '⚔️', label: 'Intermediate', sub: '1-3 yrs' },
        { val: 'advanced',     icon: '💀', label: 'Advanced',     sub: '3+ yrs, no excuses' }
      ]
    },
    {
      id: 'experience', type: 'slider', required: true,
      q: 'Workout Experience', sub: '// years of consistent training',
      min: 0, max: 10, step: 1, defaultVal: 1,
      labels: ['0 YRS', '5 YRS', '10 YRS'], unit: 'YRS'
    },
    {
      id: 'equipment', type: 'multi', required: true,
      q: 'Available Equipment', sub: '// select all that apply',
      options: [
        { val: 'bodyweight',       icon: '🫀', label: 'Bodyweight Only' },
        { val: 'dumbbells',        icon: '🏋️', label: 'Dumbbells' },
        { val: 'barbells',         icon: '⚖️', label: 'Barbells' },
        { val: 'cables',           icon: '🔗', label: 'Cables / Machines' },
        { val: 'resistance_bands', icon: '🎗️', label: 'Resistance Bands' },
        { val: 'full_gym',         icon: '🏟️', label: 'Full Gym Access' }
      ]
    },
    {
      id: 'location', type: 'toggle', required: true,
      q: 'Workout Location', sub: '// where do you train?',
      options: [
        { val: 'home', icon: '🏠', label: 'HOME' },
        { val: 'gym',  icon: '🏋️', label: 'GYM' }
      ]
    },
    {
      id: 'days', type: 'specific_days', required: true,
      q: 'Workout Days', sub: '// kaun se din workout karega? (select karo)'
    },
    {
      id: 'time', type: 'cards', required: true,
      q: 'Daily Workout Time', sub: '// available training duration',
      options: [
        { val: '20-30', icon: '⚡', label: '20-30 min', sub: 'quick strikes' },
        { val: '45-60', icon: '🔥', label: '45-60 min', sub: 'standard session' },
        { val: '60-90', icon: '💪', label: '60-90 min', sub: 'serious grind' },
        { val: '90+',   icon: '💀', label: '90+ min',   sub: 'no life, all gains' }
      ]
    },
    {
      id: 'sleep', type: 'cards', required: false,
      q: 'Sleep Schedule', sub: '// recovery is half the battle',
      options: [
        { val: 'less5', icon: '😵', label: '<5 hours',   sub: 'basically dead' },
        { val: '5to6',  icon: '😴', label: '5-6 hours',  sub: 'barely surviving' },
        { val: '7to8',  icon: '😊', label: '7-8 hours',  sub: 'optimal recovery' },
        { val: 'more8', icon: '🛌', label: '8+ hours',   sub: 'sleep god' }
      ]
    },
    {
      id: 'activity', type: 'cards', required: true,
      q: 'Daily Activity Level', sub: '// outside of workouts',
      options: [
        { val: 'sedentary', icon: '💺', label: 'Sedentary',     sub: 'desk job, low movement' },
        { val: 'lightly',   icon: '🚶', label: 'Lightly Active', sub: 'some walking' },
        { val: 'moderate',  icon: '🏃', label: 'Moderate',       sub: 'active lifestyle' },
        { val: 'very',      icon: '⚡', label: 'Very Active',    sub: 'physical job / sport' }
      ]
    },
    {
      id: 'vibe', type: 'cards', required: true,
      q: 'Target Physique Vibe', sub: '// your anime-inspired goal form',
      options: [
        { val: 'shonen_hero', icon: '🦸', label: 'Shōnen Hero',     sub: 'lean, explosive, agile' },
        { val: 'demon_lord',  icon: '👿', label: 'Demon Lord',       sub: 'jacked, dark, imposing' },
        { val: 'assassin',    icon: '🗡️', label: 'Shadow Assassin',  sub: 'toned, fast, lethal' },
        { val: 'tank',        icon: '🛡️', label: 'Armored Tank',     sub: 'thick, powerful, unbreakable' },
        { val: 'god',         icon: '✨', label: 'God Form',         sub: 'peak aesthetics, balanced' },
        { val: 'berserker',   icon: '🐺', label: 'Berserker',        sub: 'raw strength, beast mode' }
      ]
    },
    {
      id: 'injuries', type: 'textarea', required: false,
      q: 'Injuries or Limitations', sub: '// any physical restrictions? (optional)',
      placeholder: 'e.g. bad knees, lower back pain, shoulder injury...'
    },
    {
      id: 'diet', type: 'cards', required: false,
      q: 'Diet Preference', sub: '// your fuel type',
      options: [
        { val: 'anything', icon: '🍖', label: 'No Restriction',       sub: 'I eat everything' },
        { val: 'veg',      icon: '🥗', label: 'Vegetarian',           sub: 'plant-based' },
        { val: 'vegan',    icon: '🌱', label: 'Vegan',                sub: 'fully plant' },
        { val: 'keto',     icon: '🥑', label: 'Keto',                 sub: 'low carb warrior' },
        { val: 'fasting',  icon: '⏳', label: 'Intermittent Fasting', sub: 'timed eating' }
      ]
    },
    {
      id: 'motivation', type: 'slider', required: true,
      q: 'Motivation Level', sub: '// how hungry are you? be real.',
      min: 1, max: 10, step: 1, defaultVal: 7,
      labels: ['ZERO WILL', 'AVERAGE', 'GOD MODE'], unit: '/10'
    },
    {
      id: 'pushup', type: 'capability', required: false,
      q: 'Current Capability', sub: '// max reps you can do right now',
      fields: [
        { key: 'pushups', label: 'PUSH-UPS', placeholder: '0', icon: '💪' },
        { key: 'squats',  label: 'SQUATS',   placeholder: '0', icon: '🦵' }
      ]
    },
    {
      id: 'style', type: 'multi', required: false,
      q: 'Preferred Workout Style', sub: '// select your battle style',
      options: [
        { val: 'hiit',              icon: '⚡', label: 'HIIT' },
        { val: 'strength_training', icon: '🏋️', label: 'Strength Training' },
        { val: 'calisthenics',      icon: '🤸', label: 'Calisthenics' },
        { val: 'cardio',            icon: '🏃', label: 'Cardio' },
        { val: 'yoga',              icon: '🧘', label: 'Yoga / Flexibility' },
        { val: 'sports',            icon: '⚽', label: 'Sports / Athletic' }
      ]
    }
  ];

  // ── State ──────────────────────────────────────────────────────
  var currentStep   = 0;
  var smAnswers     = {};
  var smCharData    = null;

  // ── Helper: scoped getElementById inside the modal ─────────────
  function $sm(id) {
    var modal = document.getElementById('surveyModal');
    return modal ? modal.querySelector('#sm-' + id) : null;
  }

  // ══════════════════════════════════════════════════
  // PUBLIC INIT (called once when modal first opens)
  // ══════════════════════════════════════════════════
  window._surveyInlineInitialized = false;
  window._surveyInlineInit = function () {
    window._surveyInlineInitialized = true;
    currentStep = 0;
    smAnswers   = {};
    smCharData  = null;

    smStartSurvey();
  };

  // ══════════════════════════════════════════════════
  // START SURVEY
  // ══════════════════════════════════════════════════
  function smStartSurvey() {
    var headerSub = $sm('header-sub');
    if (headerSub) headerSub.textContent = '// CALIBRATING YOUR SOUL //';

    var progContainer = $sm('progress-container');
    if (progContainer) progContainer.style.display = 'block';

    var stepCard = $sm('step-card');
    if (stepCard) stepCard.style.display = 'block';

    var navRow = $sm('nav-row');
    if (navRow) navRow.style.display = 'flex';

    // Build dots
    var dotsEl = $sm('prog-dots');
    if (dotsEl) {
      dotsEl.innerHTML = '';
      QUESTIONS.forEach(function (_, i) {
        var d = document.createElement('div');
        d.className = 'sm-pdot' + (i === 0 ? ' sm-active' : '');
        d.id = 'sm-dot-' + i;
        dotsEl.appendChild(d);
      });
    }

    smRenderStep(0);
  }

  // ══════════════════════════════════════════════════
  // RENDER STEP
  // ══════════════════════════════════════════════════
  function smRenderStep(idx) {
    var q     = QUESTIONS[idx];
    var total = QUESTIONS.length;

    // Progress bar
    var pct = Math.round((idx / total) * 100);
    var progFill = $sm('prog-fill');
    if (progFill) progFill.style.width = Math.max(pct, 4) + '%';
    var progCount = $sm('prog-count');
    if (progCount) progCount.textContent = (idx + 1) + ' / ' + total;

    // Dots
    var modal = document.getElementById('surveyModal');
    if (modal) {
      modal.querySelectorAll('.sm-pdot').forEach(function (d, i) {
        d.className = 'sm-pdot' + (i < idx ? ' sm-done' : i === idx ? ' sm-active' : '');
      });
    }

    // Card content
    var stepNum = $sm('step-num');
    if (stepNum) stepNum.textContent = 'QUESTION ' + String(idx + 1).padStart(2, '0') + ' OF ' + total;
    var stepQ = $sm('step-q');
    if (stepQ) stepQ.textContent = q.q;
    var stepSub = $sm('step-sub');
    if (stepSub) stepSub.textContent = q.sub;
    var errMsg = $sm('err-msg');
    if (errMsg) errMsg.classList.remove('sm-show');

    // Back button
    var btnBack = $sm('btn-back');
    if (btnBack) btnBack.style.display = idx === 0 ? 'none' : 'block';

    // Skip link
    var skipEl = $sm('skip-link');
    if (skipEl) skipEl.style.display = !q.required ? 'block' : 'none';

    // Next button label
    var isLast = idx === total - 1;
    var btnNext = $sm('btn-next');
    if (btnNext) btnNext.textContent = isLast ? '⚡ FORGE MY REAPER' : 'NEXT →';

    // Re-animate card
    var card = $sm('step-card');
    if (card) {
      card.style.animation = 'none';
      card.offsetHeight; // reflow
      card.style.animation = 'smSlideIn 0.4s cubic-bezier(.4,0,.2,1)';
    }

    // Render input content
    var content = $sm('step-content');
    if (!content) return;
    content.innerHTML = '';
    var saved = smAnswers[q.id];

    switch (q.type) {
      case 'number':
        content.innerHTML =
          '<div class="sm-input-unit">' +
            '<input class="sm-rs-input" type="number" inputmode="numeric"' +
            ' id="sm-inp-' + q.id + '" placeholder="' + q.placeholder + '"' +
            ' min="' + q.min + '" max="' + q.max + '"' +
            ' value="' + (saved || '') + '"' +
            ' style="border:none;background:transparent;padding:14px 16px;color:var(--purple-text,#e8e6ff);font-family:Rajdhani,sans-serif;font-size:16px;font-weight:600;outline:none;flex:1"/>' +
            '<span class="sm-unit-badge">' + q.unit + '</span>' +
          '</div>';
        setTimeout(function () {
          var el = document.getElementById('sm-inp-' + q.id);
          if (el) el.focus();
        }, 100);
        break;

      case 'hw':
        content.innerHTML =
          '<div class="sm-input-row">' +
            '<div class="sm-input-group">' +
              '<span class="sm-input-label">HEIGHT</span>' +
              '<div class="sm-input-unit">' +
                '<input type="number" inputmode="numeric" id="sm-inp-height"' +
                ' placeholder="170" value="' + ((saved && saved.height) || '') + '"' +
                ' style="border:none;background:transparent;padding:14px 16px;color:var(--purple-text,#e8e6ff);font-family:Rajdhani,sans-serif;font-size:16px;font-weight:600;outline:none;flex:1"/>' +
                '<span class="sm-unit-badge">CM</span>' +
              '</div>' +
            '</div>' +
            '<div class="sm-input-group">' +
              '<span class="sm-input-label">WEIGHT</span>' +
              '<div class="sm-input-unit">' +
                '<input type="number" inputmode="numeric" id="sm-inp-weight"' +
                ' placeholder="70" value="' + ((saved && saved.weight) || '') + '"' +
                ' style="border:none;background:transparent;padding:14px 16px;color:var(--purple-text,#e8e6ff);font-family:Rajdhani,sans-serif;font-size:16px;font-weight:600;outline:none;flex:1"/>' +
                '<span class="sm-unit-badge">KG</span>' +
              '</div>' +
            '</div>' +
          '</div>';
        break;

      case 'cards':
        var colCls = q.options.length === 2 ? 'sm-col2' : '';
        content.innerHTML =
          '<div class="sm-options-grid ' + colCls + '" id="sm-grid-' + q.id + '">' +
          q.options.map(function (o) {
            return '<div class="sm-opt-card' + (saved === o.val ? ' sm-selected' : '') + '"' +
              ' data-val="' + o.val + '" onclick="smSelectCard(\'' + q.id + '\',\'' + o.val + '\')">' +
              '<div class="sm-opt-check">✓</div>' +
              '<span class="sm-opt-icon">' + o.icon + '</span>' +
              '<div class="sm-opt-label">' + o.label + '</div>' +
              (o.sub ? '<div class="sm-opt-sub">' + o.sub + '</div>' : '') +
            '</div>';
          }).join('') +
          '</div>';
        break;

      case 'multi':
        content.innerHTML =
          '<div class="sm-tag-grid" id="sm-multi-' + q.id + '">' +
          q.options.map(function (o) {
            return '<div class="sm-tag' + ((saved || []).includes(o.val) ? ' sm-selected' : '') + '"' +
              ' data-val="' + o.val + '" onclick="smToggleMulti(\'' + q.id + '\',\'' + o.val + '\')">' +
              o.icon + ' ' + o.label + '</div>';
          }).join('') +
          '</div>';
        break;

      case 'toggle':
        var tv = saved || q.options[0].val;
        content.innerHTML =
          '<div class="sm-toggle-row" id="sm-tog-' + q.id + '">' +
          q.options.map(function (o) {
            return '<div class="sm-toggle-opt' + (tv === o.val ? ' sm-selected' : '') + '"' +
              ' data-val="' + o.val + '" onclick="smSelectToggle(\'' + q.id + '\',\'' + o.val + '\')">' +
              '<span class="sm-t-icon">' + o.icon + '</span>' +
              '<span class="sm-t-label">' + o.label + '</span></div>';
          }).join('') +
          '</div>';
        if (!saved) smAnswers[q.id] = tv;
        break;

      case 'specific_days':
        var savedDays = Array.isArray(saved) ? saved : [];
        var dayNames  = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        var dayKeys   = [1, 2, 3, 4, 5, 6, 0];
        content.innerHTML =
          '<div class="sm-days-picker" id="sm-days-pick">' +
          dayNames.map(function (dn, i) {
            return '<div class="sm-day-btn' + (savedDays.includes(dayKeys[i]) ? ' sm-selected' : '') + '"' +
              ' data-d="' + dayKeys[i] + '" onclick="smToggleSpecificDay(' + dayKeys[i] + ')">' + dn + '</div>';
          }).join('') +
          '</div>' +
          '<div style="text-align:center;margin-top:10px;font-size:13px;color:#7a78a0" id="sm-days-selected-count">' +
          (savedDays.length > 0 ? savedDays.length + ' din selected' : 'Koi din select nahi') +
          '</div>';
        if (!Array.isArray(saved)) smAnswers[q.id] = [];
        break;

      case 'slider':
        var sv = saved !== undefined ? saved : q.defaultVal;
        content.innerHTML =
          '<div class="sm-slider-container">' +
            '<input type="range" class="sm-rs-slider" id="sm-sl-' + q.id + '"' +
            ' min="' + q.min + '" max="' + q.max + '" step="' + q.step + '" value="' + sv + '"' +
            ' oninput="smUpdateSlider(\'' + q.id + '\',\'' + q.unit + '\')"/>' +
            '<div class="sm-slider-labels">' +
            q.labels.map(function (l) { return '<span>' + l + '</span>'; }).join('') +
            '</div>' +
            '<div class="sm-slider-value" id="sm-slval-' + q.id + '">' + sv + q.unit + '</div>' +
          '</div>';
        if (saved === undefined) smAnswers[q.id] = sv;
        break;

      case 'textarea':
        content.innerHTML =
          '<textarea class="sm-rs-textarea" id="sm-ta-' + q.id + '"' +
          ' placeholder="' + q.placeholder + '">' + (saved || '') + '</textarea>';
        break;

      case 'capability':
        content.innerHTML =
          '<div class="sm-input-row">' +
          q.fields.map(function (f) {
            return '<div class="sm-input-group">' +
              '<span class="sm-input-label">' + f.icon + ' ' + f.label + '</span>' +
              '<div class="sm-input-unit">' +
                '<input type="number" inputmode="numeric" id="sm-cap-' + f.key + '"' +
                ' placeholder="' + f.placeholder + '"' +
                ' value="' + ((saved && saved[f.key]) || '') + '"' +
                ' style="border:none;background:transparent;padding:14px 16px;color:var(--purple-text,#e8e6ff);font-family:Rajdhani,sans-serif;font-size:18px;font-weight:700;outline:none;flex:1"/>' +
                '<span class="sm-unit-badge">REPS</span>' +
              '</div>' +
            '</div>';
          }).join('') +
          '</div>';
        break;
    }

    // Scroll modal content to top
    var scroller = document.querySelector('#surveyModal .sm-scroll');
    if (scroller) scroller.scrollTop = 0;
  }

  // ══════════════════════════════════════════════════
  // INTERACTION HANDLERS (global, called from onclick)
  // ══════════════════════════════════════════════════
  window.smSelectCard = function (qId, val) {
    smAnswers[qId] = val;
    var modal = document.getElementById('surveyModal');
    if (modal) {
      modal.querySelectorAll('#sm-grid-' + qId + ' .sm-opt-card').forEach(function (c) {
        c.classList.toggle('sm-selected', c.dataset.val === val);
      });
    }
    var err = $sm('err-msg');
    if (err) err.classList.remove('sm-show');
  };

  window.smToggleMulti = function (qId, val) {
    if (!smAnswers[qId]) smAnswers[qId] = [];
    var arr = smAnswers[qId];
    var idx = arr.indexOf(val);
    if (idx > -1) arr.splice(idx, 1); else arr.push(val);
    var modal = document.getElementById('surveyModal');
    if (modal) {
      modal.querySelectorAll('#sm-multi-' + qId + ' .sm-tag').forEach(function (t) {
        t.classList.toggle('sm-selected', arr.includes(t.dataset.val));
      });
    }
  };

  window.smSelectToggle = function (qId, val) {
    smAnswers[qId] = val;
    var modal = document.getElementById('surveyModal');
    if (modal) {
      modal.querySelectorAll('#sm-tog-' + qId + ' .sm-toggle-opt').forEach(function (t) {
        t.classList.toggle('sm-selected', t.dataset.val === val);
      });
    }
  };

  window.smToggleSpecificDay = function (d) {
    if (!Array.isArray(smAnswers['days'])) smAnswers['days'] = [];
    var idx = smAnswers['days'].indexOf(d);
    if (idx >= 0) smAnswers['days'].splice(idx, 1); else smAnswers['days'].push(d);
    var modal = document.getElementById('surveyModal');
    if (modal) {
      modal.querySelectorAll('.sm-day-btn').forEach(function (b) {
        b.classList.toggle('sm-selected', smAnswers['days'].includes(parseInt(b.dataset.d)));
      });
    }
    var countEl = document.getElementById('sm-days-selected-count');
    if (countEl) countEl.textContent = smAnswers['days'].length > 0 ? smAnswers['days'].length + ' din selected' : 'Koi din select nahi';
  };

  window.smUpdateSlider = function (qId, unit) {
    var sl = document.getElementById('sm-sl-' + qId);
    if (!sl) return;
    smAnswers[qId] = parseInt(sl.value);
    var valEl = document.getElementById('sm-slval-' + qId);
    if (valEl) valEl.textContent = sl.value + unit;
    var pct = (sl.value - sl.min) / (sl.max - sl.min) * 100;
    sl.style.background = 'linear-gradient(90deg, #7c6fff ' + pct + '%, #1c1c33 ' + pct + '%)';
  };

  // ══════════════════════════════════════════════════
  // NAVIGATION
  // ══════════════════════════════════════════════════
  function smCollectCurrentAnswer() {
    var q = QUESTIONS[currentStep];
    switch (q.type) {
      case 'number':
        smAnswers[q.id] = (document.getElementById('sm-inp-' + q.id) || {}).value || '';
        break;
      case 'hw':
        smAnswers[q.id] = {
          height: (document.getElementById('sm-inp-height') || {}).value || '',
          weight: (document.getElementById('sm-inp-weight') || {}).value || ''
        };
        break;
      case 'textarea':
        smAnswers[q.id] = (document.getElementById('sm-ta-' + q.id) || {}).value || '';
        break;
      case 'capability':
        smAnswers[q.id] = {};
        q.fields.forEach(function (f) {
          smAnswers[q.id][f.key] = (document.getElementById('sm-cap-' + f.key) || {}).value || '';
        });
        break;
    }
  }

  function smValidateCurrent() {
    var q = QUESTIONS[currentStep];
    if (!q.required) return true;
    smCollectCurrentAnswer();
    var a = smAnswers[q.id];
    if (q.type === 'number')        return a && !isNaN(a) && a > 0;
    if (q.type === 'hw')            return a && a.height && a.weight;
    if (q.type === 'cards')         return !!a;
    if (q.type === 'multi')         return a && a.length > 0;
    if (q.type === 'toggle')        return !!a;
    if (q.type === 'specific_days') return Array.isArray(a) && a.length > 0;
    if (q.type === 'slider')        return a !== undefined;
    return true;
  }

  window.smGoNext = function () {
    smCollectCurrentAnswer();
    if (!smValidateCurrent()) {
      var err = $sm('err-msg');
      if (err) err.classList.add('sm-show');
      return;
    }
    if (currentStep < QUESTIONS.length - 1) {
      currentStep++;
      smRenderStep(currentStep);
    } else {
      smCollectCurrentAnswer();
      smGenerateCharacter();
    }
  };

  window.smGoBack = function () {
    if (currentStep > 0) {
      smCollectCurrentAnswer();
      currentStep--;
      smRenderStep(currentStep);
    }
  };

  window.smSkipStep = function () {
    if (currentStep < QUESTIONS.length - 1) {
      currentStep++;
      smRenderStep(currentStep);
    } else {
      smGenerateCharacter();
    }
  };

  // ══════════════════════════════════════════════════
  // AI CHARACTER GENERATION (reused from survey.html)
  // ══════════════════════════════════════════════════
  function smGenerateCharacter() {
    $sm('step-card')         && ($sm('step-card').style.display = 'none');
    $sm('nav-row')           && ($sm('nav-row').style.display = 'none');
    $sm('skip-link')         && ($sm('skip-link').style.display = 'none');
    $sm('progress-container')&& ($sm('progress-container').style.display = 'none');
    $sm('ai-loading')        && ($sm('ai-loading').style.display = 'block');
    $sm('header-sub')        && ($sm('header-sub').textContent = '// FORGING YOUR SOUL //');

    var a   = smAnswers;
    var bmi = a.body && a.body.height && a.body.weight
      ? (a.body.weight / Math.pow(a.body.height / 100, 2)).toFixed(1)
      : '?';

    var prompt =
      'You are a dark anime-themed fitness character generator for "Reaper Squad" app.\n\n' +
      'Generate a unique fitness character/identity for this user based on their profile:\n' +
      '- Age: ' + (a.age || 'unknown') + '\n' +
      '- Gender: ' + (a.gender || 'unknown') + '\n' +
      '- Height: ' + ((a.body && a.body.height) || '?') + 'cm, Weight: ' + ((a.body && a.body.weight) || '?') + 'kg, BMI: ' + bmi + '\n' +
      '- Goal: ' + (a.goal || 'general fitness') + '\n' +
      '- Level: ' + (a.level || 'beginner') + '\n' +
      '- Experience: ' + (a.experience || 0) + ' years\n' +
      '- Equipment: ' + ((a.equipment || []).join(', ') || 'bodyweight') + '\n' +
      '- Location: ' + (a.location || 'home') + '\n' +
      '- Days/week: ' + (Array.isArray(a.days) ? a.days.length : (a.days || 4)) + '\n' +
      '- Session time: ' + (a.time || '45-60') + ' min\n' +
      '- Sleep: ' + (a.sleep || '7to8') + '\n' +
      '- Activity: ' + (a.activity || 'moderate') + '\n' +
      '- Target vibe: ' + (a.vibe || 'shonen_hero') + '\n' +
      '- Injuries: ' + (a.injuries || 'none') + '\n' +
      '- Diet: ' + (a.diet || 'no restriction') + '\n' +
      '- Motivation: ' + (a.motivation || 7) + '/10\n' +
      '- Push-ups: ' + ((a.pushup && a.pushup.pushups) || '?') + ', Squats: ' + ((a.pushup && a.pushup.squats) || '?') + '\n' +
      '- Style: ' + ((a.style || []).join(', ') || 'mixed') + '\n\n' +
      'Respond ONLY with valid JSON (no markdown, no backticks):\n' +
      '{"name":"...","archetype":"...","emoji":"...","emojiRow":"...","story":"...","stats":[{"val":"...","label":"..."}],"traits":["..."],"power":"..."}';

    fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 1000,
        messages: [{ role: 'user', content: prompt }]
      })
    })
    .then(function (resp) { return resp.json(); })
    .then(function (data) {
      var raw   = (data.content && data.content[0] && data.content[0].text) || '';
      var clean = raw.replace(/```json?|```/g, '').trim();
      smCharData = JSON.parse(clean);
      smShowCharacter(smCharData);
    })
    .catch(function () {
      smCharData = smGetFallbackCharacter();
      smShowCharacter(smCharData);
    });
  }

  function smGetFallbackCharacter() {
    var vibes = {
      shonen_hero: { name: 'The Rising Phoenix', arch: 'SHŌNEN WARRIOR', emoji: '🔥' },
      demon_lord:  { name: 'Void Emperor',        arch: 'DEMON SOVEREIGN', emoji: '👿' },
      assassin:    { name: 'The Shadow Blade',    arch: 'SILENT REAPER',   emoji: '🗡️' },
      tank:        { name: 'Iron Fortress',        arch: 'ARMORED TITAN',   emoji: '🛡️' },
      god:         { name: 'Celestial Form',       arch: 'GOD PHYSIQUE',    emoji: '✨' },
      berserker:   { name: 'Primal Beast',         arch: 'RAGE INCARNATE',  emoji: '🐺' }
    };
    var v = vibes[smAnswers.vibe] || vibes.shonen_hero;
    return {
      name: v.name, archetype: v.arch, emoji: v.emoji,
      emojiRow: '💀⚔️🔥✨',
      story: 'You have answered the call of the Reaper Squad. Your path begins in darkness, but you will forge yourself into something the world has never seen. The journey ahead will break you — and you will rebuild, stronger than before.',
      stats: [
        { val: String(Array.isArray(smAnswers.days) ? smAnswers.days.length : (smAnswers.days || 4)) + 'D', label: 'DAYS/WEEK' },
        { val: String(smAnswers.motivation || '7'), label: 'WILL POWER' },
        { val: (smAnswers.level || 'beginner').toUpperCase().slice(0, 3), label: 'TIER' }
      ],
      traits: ['Determined', 'Rising', 'Hungry', 'Unstoppable'],
      power: 'Soul Forge'
    };
  }

  function smShowCharacter(c) {
    $sm('ai-loading')  && ($sm('ai-loading').style.display = 'none');
    $sm('char-reveal') && ($sm('char-reveal').style.display = 'block');
    $sm('header-sub')  && ($sm('header-sub').textContent = '// IDENTITY FORGED //');

    var avatar = $sm('char-avatar');
    if (avatar) avatar.textContent = c.emoji || '💀';
    var emojiRow = $sm('char-emoji-row');
    if (emojiRow) emojiRow.textContent = c.emojiRow || '';
    var charName = $sm('char-name');
    if (charName) charName.textContent = c.name || 'The Reaper';
    var archetype = $sm('char-archetype');
    if (archetype) archetype.textContent = c.archetype || 'SOUL WARRIOR';
    var story = $sm('char-story');
    if (story) story.textContent = c.story || '';

    var statsEl = $sm('char-stats');
    if (statsEl) {
      statsEl.innerHTML = (c.stats || []).map(function (s) {
        return '<div class="sm-stat-box"><span class="sm-stat-val">' + s.val + '</span><span class="sm-stat-lbl">' + s.label + '</span></div>';
      }).join('');
    }

    var traitsEl = $sm('char-traits');
    if (traitsEl) {
      traitsEl.innerHTML = (c.traits || []).map(function (t) {
        return '<span class="sm-trait-tag">' + t + '</span>';
      }).join('');
    }

    // Scroll to top
    var scroller = document.querySelector('#surveyModal .sm-scroll');
    if (scroller) scroller.scrollTop = 0;
  }

  // ══════════════════════════════════════════════════
  // SAVE & ENTER
  // ══════════════════════════════════════════════════
  window.smSaveAndEnter = function () {
    if (window.ReaperSurveyGate) {
      window.ReaperSurveyGate.onComplete(smAnswers, smCharData);
    }
  };

  // ══════════════════════════════════════════════════
  // KEYBOARD — Enter to advance
  // ══════════════════════════════════════════════════
  document.addEventListener('keydown', function (e) {
    var modal = document.getElementById('surveyModal');
    if (!modal || !modal.classList.contains('sm-visible')) return;
    var stepCard = $sm('step-card');
    if (e.key === 'Enter' && stepCard && stepCard.style.display !== 'none') {
      window.smGoNext();
    }
  });

})();

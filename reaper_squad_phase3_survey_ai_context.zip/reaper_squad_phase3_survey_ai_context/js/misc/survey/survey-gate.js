// ══════════════════════════════════════════════════════════════════
// REAPER SQUAD — Survey Gate v2
// F-08: Inline fullscreen overlay (no iframe, no page navigation)
// SCHEMA FIX: there is no user_blobs table in the authoritative schema
// (01_schema.sql says it is deliberately absent), so this no longer
// calls ReaperAuth.upsertBlob/getBlob (removed — they targeted that
// table). Completion state is localStorage-only until a documented
// mapping onto users.profile_data / users.settings_data exists.
// ══════════════════════════════════════════════════════════════════

(function () {
  'use strict';

  // ── Constants ──────────────────────────────────────────────────
  var LS_DONE_KEY   = 'rs_survey_done_v1';
  var LS_ANSWERS    = 'rs_survey_answers';
  var LS_USER_KEY   = 'rs_user';

  // ── Gate entry-point: called after session is confirmed ────────
  // Pass the authenticated Supabase session object (or null).
  window.ReaperSurveyGate = {

    /**
     * Check whether the survey has already been completed.
     * Primary source: Supabase blob. Fallback: localStorage.
     */
    checkAndShowIfNeeded: async function () {
      // No user_blobs table exists to check server-side — localStorage
      // is the only source of truth for completion right now.
      if (localStorage.getItem(LS_DONE_KEY)) {
        return; // Already done — skip
      }

      window.ReaperSurveyGate.show();
    },

    /** Programmatically show the survey modal */
    show: function () {
      var modal = document.getElementById('surveyModal');
      if (!modal) return;
      // Init the inline survey engine if not yet done
      if (!window._surveyInlineInitialized) {
        window._surveyInlineInit();
      }
      modal.classList.add('sm-visible');
      document.body.style.overflow = 'hidden'; // prevent bg scroll
    },

    /** Hide the survey modal (call only after successful completion) */
    hide: function () {
      var modal = document.getElementById('surveyModal');
      if (!modal) return;
      modal.classList.remove('sm-visible');
      modal.classList.add('sm-exit');
      document.body.style.overflow = '';
      setTimeout(function () {
        modal.classList.remove('sm-exit');
      }, 500);
    },

    /**
     * Called when user presses "Begin Your Journey" button.
     * Persists completion then closes the modal.
     */
    onComplete: async function (answers, characterData) {
      // Save answers to localStorage (profile sync)
      try {
        var saveData = {
          surveyAnswers: answers,
          character: characterData,
          characterName: (characterData && characterData.name) ? characterData.name : 'The Reaper',
          completedAt: Date.now()
        };
        localStorage.setItem(LS_USER_KEY, JSON.stringify(saveData));
        localStorage.setItem(LS_ANSWERS, JSON.stringify(answers));
        localStorage.setItem('rs_last_survey', String(Date.now()));
      } catch (storageErr) {
        console.warn('[SurveyGate] localStorage save error:', storageErr);
      }

      // ── Persist completion (localStorage-only — no user_blobs table) ──
      try {
        localStorage.setItem(LS_DONE_KEY, '1');
      } catch (e2) { /* ignore */ }

      // ── Sync survey answers to user profile ──────────────────
      try {
        var currentUser = JSON.parse(localStorage.getItem('currentUser') || 'null');
        var username = currentUser && currentUser.username;
        if (answers && username) {
          var profileKey = 'tuProfile_' + username;
          var existing = JSON.parse(localStorage.getItem(profileKey) || '{}');
          if (answers.body) {
            if (answers.body.height) existing.height = parseInt(answers.body.height);
            if (answers.body.weight) existing.weight = parseInt(answers.body.weight);
          }
          if (answers.age)    existing.age    = parseInt(answers.age);
          if (answers.gender) existing.gender = answers.gender;
          var goalMap = { fat_loss: 'cutting', muscle: 'bulking', aesthetics: 'cutting', strength: 'bulking' };
          if (answers.goal)   existing.goal   = goalMap[answers.goal] || 'maintain';
          var days = Array.isArray(answers.days) ? answers.days.length : (parseInt(answers.days) || 3);
          existing.activity = days <= 2 ? 'light' : days <= 4 ? 'moderate' : 'very';
          if (answers.level === 'beginner' && days <= 3) existing.activity = 'light';
          localStorage.setItem(profileKey, JSON.stringify(existing));
        }
      } catch (profileErr) {
        console.warn('[SurveyGate] Profile sync error:', profileErr);
      }

      // Close overlay
      window.ReaperSurveyGate.hide();
    }
  };

})();

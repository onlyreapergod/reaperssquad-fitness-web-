// ============================================================
// REAPER SQUAD — AI provider: Anthropic (js/ai/providers/anthropic.js)
// Phase 2 AI architecture extraction.
//
// Provider-specific knowledge only:
//   - default model
//   - client-side mirror of the server's model whitelist (informational
//     only — the real enforcement is server-side in functions/api/ai.js,
//     which is NOT modified by this refactor)
//   - how to pull the assistant text back out of a raw Anthropic
//     Messages API response body
//
// This module must load before js/ai/service.js in index.html.
// ============================================================
(function (window) {
  'use strict';

  var ReaperAI = (window.ReaperAI = window.ReaperAI || {});
  ReaperAI.providers = ReaperAI.providers || {};

  // Mirrors CLAUDE_MODELS in functions/api/ai.js.
  var MODELS = ['claude-sonnet-4-20250514'];

  ReaperAI.providers.anthropic = {
    id: 'anthropic',
    defaultModel: 'claude-sonnet-4-20250514',
    models: MODELS,

    // Anthropic's Messages API shape:
    // { content: [ { type: "text", text: "..." } ] }
    extractText: function (raw) {
      try {
        return (raw && raw.content && raw.content[0] && raw.content[0].text) || '';
      } catch (e) {
        return '';
      }
    },
  };
})(window);

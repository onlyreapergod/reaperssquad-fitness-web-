// ============================================================
// REAPER SQUAD — AI provider: Groq (js/ai/providers/groq.js)
// Phase 2 AI architecture extraction.
//
// Provider-specific knowledge only:
//   - default model
//   - client-side mirror of the server's model whitelist (informational
//     only — the real enforcement is server-side in functions/api/ai.js,
//     which is NOT modified by this refactor)
//   - how to pull the assistant text back out of a raw Groq
//     (OpenAI-compatible chat completion) response body
//
// This module must load before js/ai/service.js in index.html.
// ============================================================
(function (window) {
  'use strict';

  var ReaperAI = (window.ReaperAI = window.ReaperAI || {});
  ReaperAI.providers = ReaperAI.providers || {};

  // Mirrors GROQ_MODELS in functions/api/ai.js.
  var MODELS = ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'gemma2-9b-it'];

  ReaperAI.providers.groq = {
    id: 'groq',
    defaultModel: 'llama-3.3-70b-versatile',
    models: MODELS,

    // Groq's endpoint is OpenAI-compatible:
    // { choices: [ { message: { content: "..." } } ] }
    extractText: function (raw) {
      try {
        return (raw && raw.choices && raw.choices[0] && raw.choices[0].message &&
          raw.choices[0].message.content) || '';
      } catch (e) {
        return '';
      }
    },
  };
})(window);

# ai/

Phase 2 extraction of the client-side AI architecture. Phase 3 added
automatic survey-context integration (see its own section below). Layout:

- `service.js` — the ONLY public AI entry point (`window.ReaperAI`). Owns
  sending requests to `/api/ai`, auth headers, retry logic, response
  normalization, provider selection, and (Phase 3) automatically folding
  the user's survey answers into every request via `survey-context.js`.
- `providers/groq.js`, `providers/anthropic.js` — provider-specific bits
  only: default model, a client-side mirror of the server's model
  whitelist (informational — real enforcement stays server-side), and how
  to pull assistant text out of that provider's raw response shape.
- `survey-context.js` — Phase 3. The one reusable place that reads the
  onboarding survey's answers back out of storage and formats them for a
  prompt. See "Phase 3 — Survey context" below.

`js/core/patches/security-patch.js` still defines the legacy globals
(`window.callGemini`, `window.callGeminiText`, `window.callGeminiForPlan`)
and the `window.fetch` interceptor for stray `/api/ai`, `api.anthropic.com`,
and `api.groq.com` calls — those now forward internally to `window.ReaperAI`
instead of duplicating request/auth/retry/normalization logic.

`js/core/patches/arch-fixes.js` (loads last, after `script.js`) replaces
`window.fixAnalyze` — the camera posture/pain analyzer, previously the one
AI feature calling `fetch('/api/ai', ...)` directly instead of going
through a shared entry point — with a version that keeps its exact
behavior (same prompts, same Anthropic-first → 3-Groq-fallback order,
same DOM ids) but calls `window.ReaperAI.request()` /
`.extractText()` like every other feature. Falls back to the original
implementation untouched if `window.ReaperAI` isn't loaded.

With this change, every AI feature in the app (Improve Guide, orb Improve
Guide, quit-persuasion popup, workout/diet plan generation, and Fix It)
routes through `window.ReaperAI`. The one remaining direct-call site,
`survey-modal.js`'s `smGenerateCharacter()` (calls
`api.anthropic.com` directly, only rescued by the `window.fetch`
interceptor above), is intentionally left as-is: it falls under this
project's protected "Survey Logic" and was out of scope for this pass.
See the regression report delivered alongside this change for details
and the pre-existing model-whitelist bug that already affects it.

No call site outside this folder — other than the one `arch-fixes.js`
wrap described above — changed.

`functions/api/ai.js` is unchanged and remains in `functions/api/` because
Cloudflare Pages Functions route by file path.

Load order (see index.html): `providers/*.js` → `survey-context.js` →
`service.js` → `core/patches/security-patch.js` → `core/script.js`.

## Phase 3 — Survey context

Before this change, every AI feature that wanted to know something about
the user re-read it from storage itself: `generateDiet()` in `script.js`
reads `tuProfile_<username>` directly, the anime-physique workout-plan
prompt in `script.js` separately reads `rs_survey_answers` (just for the
`days` field, to name specific weekdays in the plan), and Fix It / Improve
Guide / the quit-convince popup didn't use survey data at all. That's
scattered, one-off survey parsing exactly like the audit's problem
statement describes — it doesn't get any new survey field automatically
and has to be hand-written per feature.

`survey-context.js` is the one reusable builder for that. It reads the
same keys `js/misc/survey/survey-gate.js` already writes on completion
(`rs_survey_answers`, `rs_user`, `tuProfile_<username>`) — it does not
touch Survey storage, logic, or completion flow — and exposes:

- `ReaperAI.getSurveyContext()` — normalized `{ answers, characterName }`,
  or `null` if the survey hasn't been completed yet.
- `ReaperAI.getSurveyContextText()` — a ready-to-inject prompt block, or
  `''` if there's nothing to add.

`service.js`'s `request()` calls `getSurveyContextText()` on **every**
call and folds it into whatever system prompt that call already sends —
see `applySurveyContext()` in `service.js`. Because every path in this
folder (the high-level helpers below, the legacy globals in
`security-patch.js`, and any direct `window.ReaperAI.request()` call like
`arch-fixes.js`'s `fixAnalyze`) funnels through that one function, every
AI feature gets survey context automatically with no per-feature changes,
now or when new survey questions are added later — new fields in
`rs_survey_answers` show up in `getSurveyContextText()`'s output on their
own (see the humanization fallback in `survey-context.js`) without either
file needing an edit. Pass `{ skipSurveyContext: true }` to opt a specific
call out.

Two details worth knowing if you touch this:

- **Placement is deliberate.** Context is *prepended* to the existing
  system content, not appended, so a feature's own trailing instructions
  — `planJSON()`'s "return ONLY valid JSON" contract, `fixAnalyze`'s
  "EXACTLY 20 numbered points" — stay the last, most salient thing the
  model reads. (`arch-fixes.js` separately notes it deliberately did NOT
  wrap `callGeminiForPlan` with its own RankEngine context for this same
  JSON-safety reason — this file takes the same risk seriously, just
  mitigates it with ordering instead of exclusion, since the survey's
  equipment/injuries/goal data materially matters for workout-plan
  quality.)
- **Provider transport differs, so injection has to branch on it.**
  `functions/api/ai.js` (unchanged) gives Anthropic a separate top-level
  `system` field but silently drops that field for Groq — Groq only
  reads `messages`, OpenAI-style, where the system prompt has to be a
  `role: 'system'` entry. Anthropic's Messages API, conversely, rejects a
  `'system'` role inside `messages`. `applySurveyContext()` therefore
  puts the context in the top-level `system` field for `provider ===
  'anthropic'`, and into a `messages` system-role entry otherwise —
  either path unconditionally would silently drop the context (Groq, the
  default provider for most features) or break the request outright
  (Anthropic).

`survey-modal.js`'s `smGenerateCharacter()` is unaffected — it's the
survey's own AI call (generating the character *from* the answers before
they're saved), calls `api.anthropic.com` directly, and is out of scope
per the note above.

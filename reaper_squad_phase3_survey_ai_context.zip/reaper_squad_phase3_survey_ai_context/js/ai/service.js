// ============================================================
// REAPER SQUAD — AI SERVICE (js/ai/service.js)
// Phase 2 AI architecture extraction. Phase 3 added automatic
// survey-context injection (see below).
//
// This is the ONLY public client-side AI entry point. Every AI
// feature (directly, or via the legacy globals in
// js/core/patches/security-patch.js) goes through window.ReaperAI.
//
// Responsibilities owned here (moved out of security-patch.js):
//   - sending requests to the /api/ai server proxy
//   - authentication headers (Supabase session bearer token)
//   - retry logic
//   - response normalization (delegated to js/ai/providers/*.js)
//   - provider selection
//   - Phase 3: automatically folding the user's onboarding-survey
//     answers (js/ai/survey-context.js) into every request, so
//     individual features don't each rebuild that context by hand —
//     see applySurveyContext() / getSurveyContextText() below
//
// NOT changed by this refactor:
//   - functions/api/ai.js (server proxy — unchanged)
//   - authentication (same ReaperAuth.getSession() pattern)
//   - the shape of data sent to /api/ai: { provider, model, messages,
//     system, max_tokens } — identical to the pre-refactor payload
//
// Load order (see index.html): this file loads AFTER
// js/ai/providers/*.js and js/ai/survey-context.js, and BEFORE
// js/core/patches/security-patch.js, so security-patch.js's legacy
// callGemini/callGeminiText/callGeminiForPlan globals (and its fetch
// interceptor) can forward straight into window.ReaperAI.
// ============================================================
(function (window) {
  'use strict';

  var ReaperAI = (window.ReaperAI = window.ReaperAI || {});
  ReaperAI.providers = ReaperAI.providers || {};

  var ENDPOINT = '/api/ai';
  var MAX_RETRIES = 2; // total attempts = 1 + MAX_RETRIES
  var RETRY_BASE_DELAY_MS = 400;

  function sleep(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  // Retry only on transient failures (rate limit / server error) or
  // network-level exceptions. Non-retryable errors (4xx other than
  // 429, bad JSON, etc.) fail immediately — same as before this
  // refactor, just without duplicating the fetch call at each
  // call site.
  function isRetryableStatus(status) {
    return status === 429 || (status >= 500 && status <= 599);
  }

  // ---------------------------------------------------------------
  // Authentication headers
  // (moved from security-patch.js's _getAiAuthHeaders())
  // ---------------------------------------------------------------
  async function getAuthHeaders() {
    try {
      if (window.ReaperAuth && window.ReaperAuth._ready) {
        var session = await window.ReaperAuth.getSession();
        if (session && session.access_token) {
          return { Authorization: 'Bearer ' + session.access_token };
        }
      }
    } catch (e) { /* no session yet — proxy will 401, callers already handle that */ }
    return {};
  }

  // ---------------------------------------------------------------
  // Provider selection
  // ---------------------------------------------------------------
  function getProvider(name) {
    return ReaperAI.providers[name] || null;
  }

  function defaultModelFor(providerName) {
    var p = getProvider(providerName);
    return p ? p.defaultModel : undefined;
  }

  // ---------------------------------------------------------------
  // Survey context injection (Phase 3 — Survey → AI Automatic
  // Context Integration, js/ai/survey-context.js). Folds the user's
  // onboarding-survey answers into whatever system prompt a call
  // already sends, so every caller through request() — chat/chatText/
  // planJSON below, the legacy callGemini/callGeminiText/
  // callGeminiForPlan globals in security-patch.js, and any direct
  // window.ReaperAI.request() call (e.g. arch-fixes.js's fixAnalyze)
  // — automatically gets it, with zero changes needed at those call
  // sites, now or when new survey questions are added later.
  //
  // Context is PREPENDED (not appended) to the existing system
  // content, so a feature's own trailing instructions — e.g.
  // planJSON()'s "return ONLY valid JSON, no extra text" contract, or
  // fixAnalyze's "EXACTLY 20 numbered points" — stay the last, most
  // salient thing the model reads.
  //
  // functions/api/ai.js (unchanged) forwards the two providers
  // differently: Anthropic gets a separate top-level `system` field;
  // Groq only forwards `messages` and silently drops top-level
  // `system` entirely (it expects the system prompt as a role:
  // 'system' entry inside `messages` instead, OpenAI-style). So the
  // context has to go wherever that provider actually reads it from,
  // or it would never reach the model. Anthropic's Messages API also
  // does not accept a 'system'-role entry inside `messages`, so the
  // two paths must stay separate — a wrong guess here would either
  // silently drop the context (Groq) or break the request outright
  // (Anthropic).
  //
  // Pass { skipSurveyContext: true } to opt a specific call out.
  // ---------------------------------------------------------------
  function applySurveyContext(provider, system, messages) {
    var contextText = (ReaperAI && typeof ReaperAI.getSurveyContextText === 'function')
      ? ReaperAI.getSurveyContextText()
      : '';
    if (!contextText) return { system: system, messages: messages }; // survey not completed — no-op

    if (provider === 'anthropic') {
      return { system: contextText + '\n\n' + (system || ''), messages: messages };
    }

    // Groq (default) and anything else riding the OpenAI-style
    // messages format: fold into an existing system-role message, or
    // add one at the front if the caller didn't send one.
    var msgs = messages.slice(); // don't mutate the caller's array
    var sysIdx = -1;
    for (var i = 0; i < msgs.length; i++) {
      if (msgs[i] && msgs[i].role === 'system') { sysIdx = i; break; }
    }
    if (sysIdx !== -1) {
      msgs[sysIdx] = Object.assign({}, msgs[sysIdx], { content: contextText + '\n\n' + msgs[sysIdx].content });
    } else {
      msgs.unshift({ role: 'system', content: contextText });
    }
    return { system: system, messages: msgs };
  }

  // ---------------------------------------------------------------
  // Core request: auth + send + retry. Resolves with the raw parsed
  // JSON body from /api/ai — the same shape every caller already
  // received from the old _proxyAI() (the provider's raw response
  // object), so nothing downstream has to change.
  // ---------------------------------------------------------------
  async function request(opts) {
    opts = opts || {};
    var provider = opts.provider;
    var model = opts.model || defaultModelFor(provider);
    var messages = opts.messages || [];
    var system = opts.system || null;
    var max_tokens = opts.max_tokens || 1000;

    if (!opts.skipSurveyContext) {
      var withContext = applySurveyContext(provider, system, messages);
      system = withContext.system;
      messages = withContext.messages;
    }

    var attempt = 0;
    var lastErr = null;

    while (attempt <= MAX_RETRIES) {
      try {
        var authHeaders = await getAuthHeaders();
        var resp = await fetch(ENDPOINT, {
          method: 'POST',
          headers: Object.assign({ 'Content-Type': 'application/json' }, authHeaders),
          body: JSON.stringify({ provider: provider, model: model, messages: messages, system: system, max_tokens: max_tokens }),
        });

        if (!resp.ok) {
          if (isRetryableStatus(resp.status) && attempt < MAX_RETRIES) {
            attempt++;
            await sleep(RETRY_BASE_DELAY_MS * attempt);
            continue;
          }
          throw new Error('AI proxy error ' + resp.status);
        }

        return await resp.json();
      } catch (e) {
        lastErr = e;
        if (attempt < MAX_RETRIES) {
          attempt++;
          await sleep(RETRY_BASE_DELAY_MS * attempt);
          continue;
        }
        throw lastErr;
      }
    }
    throw lastErr || new Error('AI proxy error');
  }

  // Same as request(), but with the pre-refactor _proxyAI(provider,
  // model, messages, system, max_tokens) positional signature, for
  // callers that want a 1:1 drop-in (the fetch() interceptor in
  // security-patch.js).
  function requestRaw(provider, model, messages, system, max_tokens) {
    return request({ provider: provider, model: model, messages: messages, system: system, max_tokens: max_tokens });
  }

  // ---------------------------------------------------------------
  // Response normalization
  // ---------------------------------------------------------------
  function extractText(providerName, rawResponse) {
    var p = getProvider(providerName);
    if (p && typeof p.extractText === 'function') {
      return p.extractText(rawResponse) || '';
    }
    return '';
  }

  // ---------------------------------------------------------------
  // High-level helpers — identical contracts to the legacy globals
  // they back (window.callGemini / callGeminiText / callGeminiForPlan
  // in security-patch.js), so those can forward here 1:1.
  // ---------------------------------------------------------------

  // Promise<string> — mirrors callGemini(systemPrompt, messages, max_tokens)
  async function chat(systemPrompt, messages, max_tokens, opts) {
    opts = opts || {};
    var provider = opts.provider || 'groq';
    var msgs = [];
    if (systemPrompt) msgs.push({ role: 'system', content: systemPrompt });
    if (Array.isArray(messages)) {
      messages.forEach(function (m) {
        msgs.push({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content });
      });
    } else if (messages) {
      msgs.push({ role: 'user', content: messages });
    }
    try {
      var data = await request({ provider: provider, model: opts.model, messages: msgs, max_tokens: max_tokens || 1000 });
      return extractText(provider, data);
    } catch (e) {
      return '';
    }
  }

  // callback style — mirrors callGeminiText(system, userContent, onSuccess, onError)
  function chatText(system, userContent, onSuccess, onError, opts) {
    opts = opts || {};
    var provider = opts.provider || 'groq';
    request({
      provider: provider,
      model: opts.model,
      messages: [{ role: 'user', content: userContent }],
      system: system,
      max_tokens: opts.max_tokens || 900,
    }).then(function (data) {
      var text = extractText(provider, data);
      text ? onSuccess(text) : onError();
    }).catch(onError);
  }

  // callback style — mirrors
  // callGeminiForPlan(prompt, progressBar, intervalId, onSuccess, onError)
  // Same JSON-fence-stripping / {...} extraction / parsed.days check
  // as the pre-refactor implementation.
  function planJSON(prompt, progressBar, intervalId, onSuccess, onError, opts) {
    opts = opts || {};
    var provider = opts.provider || 'groq';
    var systemPrompt = opts.system ||
      'Tu ek expert fitness coach hai. User jo JSON format maange EXACTLY wohi return kar — koi extra text, explanation ya markdown nahi. Sirf valid JSON output karo.';
    request({
      provider: provider,
      model: opts.model,
      messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: prompt }],
      max_tokens: opts.max_tokens || 1500,
    }).then(function (data) {
      clearInterval(intervalId);
      if (progressBar) progressBar.style.width = '100%';
      var text = extractText(provider, data);
      text = text.replace(/```json|```/g, '').trim();
      var s = text.indexOf('{'), e = text.lastIndexOf('}');
      if (s !== -1 && e !== -1) text = text.slice(s, e + 1);
      var parsed = null;
      try { parsed = JSON.parse(text); } catch (err) { /* parsed stays null → onError below */ }
      parsed && parsed.days ? onSuccess(parsed) : onError();
    }).catch(function () {
      clearInterval(intervalId);
      onError();
    });
  }

  // ---------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------
  ReaperAI.getAuthHeaders = getAuthHeaders;
  ReaperAI.request = request;
  ReaperAI.requestRaw = requestRaw;
  ReaperAI.extractText = extractText;
  ReaperAI.getProvider = getProvider;
  ReaperAI.chat = chat;
  ReaperAI.chatText = chatText;
  ReaperAI.planJSON = planJSON;

  console.log('[ReaperSquad] AI service loaded ✅');
})(window);

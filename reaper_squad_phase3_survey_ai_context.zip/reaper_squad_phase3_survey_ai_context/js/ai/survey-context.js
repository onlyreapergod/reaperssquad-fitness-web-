// ============================================================
// REAPER SQUAD — AI Survey Context Builder (js/ai/survey-context.js)
// Phase 3 AI migration: Survey → AI Automatic Context Integration.
//
// PROBLEM THIS SOLVES: every AI feature used to build its own little
// slice of "what does the AI already know about this user" by hand
// (generateDiet() reads tuProfile_<username> itself; the anime-physique
// workout-plan prompt reads rs_survey_answers itself just for `days`;
// Fix It, Improve Guide and the quit-convince popup don't read survey
// data at all). That's the "every feature manually builds its own
// survey context" duplication this file exists to stop.
//
// This file is the ONE reusable place that reads the survey's answers
// back out of storage. It does NOT touch Survey logic, storage, or the
// completion flow — it only reads the same keys survey-gate.js already
// writes on completion (js/misc/survey/survey-gate.js):
//   - rs_survey_answers    raw QUESTIONS answers object (survey-modal.js)
//   - rs_user              completion wrapper: {surveyAnswers, character,
//                           characterName, completedAt}
//   - tuProfile_<username> legacy "Tu" page profile (height/weight/age/
//                           gender) — survey-gate.js's onComplete() keeps
//                           this in sync with the survey, and the user can
//                           also hand-edit it afterwards on the Tu page —
//                           used here only to freshen those few fields.
//
// Public API — attached to window.ReaperAI so every AI feature reaches
// it through the one shared service, without importing this file
// directly or re-implementing any of this parsing:
//   ReaperAI.getSurveyContext()      -> { answers, characterName } | null
//   ReaperAI.getSurveyContextText()  -> prompt-ready string | ''
//
// js/ai/service.js's request() calls getSurveyContextText() on every
// single AI call automatically (see the "SURVEY CONTEXT INJECTION"
// block there) — that's the "Survey → One shared AI Context → ReaperAI
// → Every AI Feature" wiring. Callers never rebuild this themselves.
//
// FUTURE-PROOF BY DESIGN: formatting below only special-cases a couple
// of known field shapes (the two nested objects `body`/`pushup`, and
// `days` which stores numeric weekday indices). Anything else in the
// answers object — including brand-new survey questions added later —
// still gets included via a generic humanized label, so new survey
// fields reach the AI automatically without editing this file or any
// AI feature. See LABELS / humanizeKey() below.
//
// This file is read-only with respect to localStorage — it never
// writes survey state. Must load before js/ai/service.js (see
// index.html) so ReaperAI.getSurveyContextText exists by the time any
// AI call is made.
// ============================================================
(function (window) {
  'use strict';

  var ReaperAI = (window.ReaperAI = window.ReaperAI || {});

  // Matches survey-modal.js's specific_days convention exactly
  // (dayKeys there are JS Date.getDay() indices: 0=Sun..6=Sat).
  var DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  // Friendly labels for the survey's current QUESTIONS ids
  // (survey-modal.js) plus the two nested-object field names once
  // flattened (height/weight from `body`, pushups/squats from
  // `pushup`). Anything NOT in this map still gets included — see
  // humanizeKey() — so new survey questions automatically show up
  // without editing this file.
  var LABELS = {
    age: 'Age',
    gender: 'Gender',
    height: 'Height (cm)',
    weight: 'Weight (kg)',
    goal: 'Fitness Goal',
    level: 'Fitness Level',
    experience: 'Years of Training Experience',
    equipment: 'Available Equipment',
    location: 'Workout Location',
    days: 'Workout Days',
    time: 'Daily Workout Time',
    sleep: 'Sleep Schedule',
    activity: 'Daily Activity Level',
    vibe: 'Target Physique Vibe',
    injuries: 'Injuries / Limitations',
    diet: 'Diet Preference',
    motivation: 'Motivation Level (out of 10)',
    pushups: 'Max Push-ups',
    squats: 'Max Squats',
    style: 'Preferred Workout Style'
  };

  function humanizeKey(key) {
    return String(key)
      .replace(/_/g, ' ')
      .replace(/([a-z])([A-Z])/g, '$1 $2')
      .replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  }

  function labelFor(key) {
    return LABELS[key] || humanizeKey(key);
  }

  function safeParse(json) {
    try { return JSON.parse(json); } catch (e) { return null; }
  }

  function currentUsername() {
    var cu = safeParse(localStorage.getItem('currentUser'));
    return (cu && cu.username) || null;
  }

  function isEmpty(v) {
    return v === null || v === undefined || v === '';
  }

  // Turn one answer value into a short display string.
  //   - `days` (specific_days type) -> weekday names, not raw indices
  //   - arrays (multi/specific_days types) -> comma-joined
  //   - nested objects -> shouldn't reach here (flatten() unwraps them
  //     first), but formatted defensively anyway so nothing is dropped
  //     if a future survey question introduces a new nested shape
  //   - everything else -> String(value) (kept even for 0/false, which
  //     are meaningful survey answers, e.g. 0 years experience)
  function formatValue(key, val) {
    if (isEmpty(val)) return null;

    if (key === 'days' && Array.isArray(val)) {
      var names = val.map(function (d) { return DAY_NAMES[d] !== undefined ? DAY_NAMES[d] : d; });
      return names.length ? names.join(', ') : null;
    }

    if (Array.isArray(val)) {
      var arr = val.filter(function (v) { return !isEmpty(v); });
      return arr.length ? arr.join(', ') : null;
    }

    if (typeof val === 'object') {
      var parts = [];
      Object.keys(val).forEach(function (k) {
        var fv = formatValue(k, val[k]);
        if (fv) parts.push(labelFor(k) + ': ' + fv);
      });
      return parts.length ? parts.join(', ') : null;
    }

    return String(val);
  }

  // Flatten the two known nested-object answers (`body`: {height,
  // weight}, `pushup`: {pushups,squats}) up one level so each field
  // gets its own labeled line instead of one squashed line. Any other
  // top-level key — known or not — passes through unchanged.
  function flatten(answers) {
    var out = {};
    Object.keys(answers || {}).forEach(function (key) {
      var val = answers[key];
      if (val && typeof val === 'object' && !Array.isArray(val)) {
        Object.keys(val).forEach(function (nestedKey) {
          if (!isEmpty(val[nestedKey])) out[nestedKey] = val[nestedKey];
        });
      } else {
        out[key] = val;
      }
    });
    return out;
  }

  // ---------------------------------------------------------------
  // getSurveyContext() — normalized { answers, characterName }, or
  // null if the user hasn't completed the survey yet.
  // ---------------------------------------------------------------
  function getSurveyContext() {
    var answers = safeParse(localStorage.getItem('rs_survey_answers'));

    // rs_user wraps the same answers plus the AI-generated character
    // (written by survey-gate.js's onComplete()) — fallback source.
    var rsUser = safeParse(localStorage.getItem('rs_user'));
    if (!answers && rsUser && rsUser.surveyAnswers) answers = rsUser.surveyAnswers;
    if (!answers) return null; // survey not completed — nothing to give the AI

    var flat = flatten(answers);

    // The legacy "Tu" page profile is kept in sync with the survey by
    // survey-gate.js's onComplete(), and the user can also hand-edit it
    // afterwards (saveProfile() in script.js) — treat it as the
    // freshest source for the handful of fields it covers. Everything
    // else (equipment, injuries, diet, goal, etc.) only lives in the
    // full survey answers, which stay the source of truth for those.
    var username = currentUsername();
    if (username) {
      var tuProfile = safeParse(localStorage.getItem('tuProfile_' + username));
      if (tuProfile) {
        ['height', 'weight', 'age', 'gender'].forEach(function (k) {
          if (!isEmpty(tuProfile[k])) flat[k] = tuProfile[k];
        });
      }
    }

    var characterName = (rsUser && (rsUser.characterName || (rsUser.character && rsUser.character.name))) || null;

    return { answers: flat, characterName: characterName };
  }

  // ---------------------------------------------------------------
  // getSurveyContextText() — ready-to-inject prompt block, or '' if
  // there's nothing to add (survey not completed yet).
  // ---------------------------------------------------------------
  function getSurveyContextText() {
    var ctx = getSurveyContext();
    if (!ctx) return '';

    var lines = [];
    if (ctx.characterName) lines.push('Reaper Squad character name: ' + ctx.characterName);
    Object.keys(ctx.answers).forEach(function (key) {
      var fv = formatValue(key, ctx.answers[key]);
      if (fv) lines.push(labelFor(key) + ': ' + fv);
    });
    if (!lines.length) return '';

    return 'REAPER SQUAD USER PROFILE (already answered during onboarding — '
      + 'do not ask the user to repeat this, use it to personalize your response):\n'
      + lines.map(function (l) { return '- ' + l; }).join('\n');
  }

  ReaperAI.getSurveyContext = getSurveyContext;
  ReaperAI.getSurveyContextText = getSurveyContextText;

  console.log('[ReaperSquad] AI survey context builder loaded ✅');
})(window);

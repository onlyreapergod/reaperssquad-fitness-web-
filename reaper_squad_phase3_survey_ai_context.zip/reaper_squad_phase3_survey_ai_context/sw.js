'use strict';

/* ============================================================
   REAPER SQUAD — Service Worker  v2.0.0
   ------------------------------------------------------------
   Cache strategy (per asset type):
     • HTML (navigation)     -> Network First
                                (cache is ONLY a fallback for
                                offline — a successful network
                                fetch always overwrites it, so a
                                stale index.html can never become
                                "permanent")
     • JS / CSS              -> Stale-While-Revalidate
                                (serve instantly from cache, then
                                silently re-fetch in the background
                                and replace the cache entry — next
                                load gets the new file automatically,
                                no manual cache-busting required)
     • Images / icons / fonts -> Cache First
     • API / auth / cloud-sync
       requests               -> Network First, NEVER cached

   BUILD_ID is the cache-buster. Bump it on every deploy (or wire a
   build step to inject a commit hash / timestamp) and activate()
   will automatically delete every cache from the previous build —
   old JS/CSS/HTML cannot survive a deployment.
     Example build command:
       sed -i "s/__BUILD_ID__/$(date +%s)/" sw.js
   ============================================================ */

const BUILD_ID = '20260717-1';

const HTML_CACHE   = `reaper-html-${BUILD_ID}`;
const STATIC_CACHE = `reaper-static-${BUILD_ID}`;
const MEDIA_CACHE  = `reaper-media-${BUILD_ID}`;
const CURRENT_CACHES = [HTML_CACHE, STATIC_CACHE, MEDIA_CACHE];

// Precached at install time so the very first offline visit still works.
// NOTE: keep these in sync with the actual ?v= query strings index.html
// requests — a mismatch just means a cold-start precache miss (harmless,
// SWR/cache-first will populate it on first real request), NOT a stale
// asset, since every strategy below re-validates against the network.
const HTML_SHELL = ['/index.html', '/offline.html'];

const STATIC_SHELL = [
  '/css/main.css?v=20260611',
  '/css/core/base.css',
  '/css/theme/themes.css',
  '/css/theme/theme-vars.css',
  '/css/core/premium-ui.css',
  '/js/data-layer/cloud_sync.js?v=20260611',
  '/js/core/patches/security-patch.js?v=20260702',
  '/js/core/script.js?v=20260715',
  '/js/auth/auth-supabase.js?v=20260715',
  '/js/workout/data/lady-physiques.js?v=20260611',
  '/js/workout/lady-select.js?v=20260611',
  '/js/config/settings-panel.js?v=20260611',
  '/js/workout/train_mode.js?v=20260611',
  '/js/workout/home_skill_plan.js?v=20260611',
  '/js/gamification/rank-engine.js?v=20260628',
  '/js/core/patches/stub-compat.js?v=20260611',
  '/js/core/premium-animations.js?v=20260611',
  '/js/core/patches/motion-guard.js?v=20260611',
  '/js/core/patches/arch-fixes.js?v=20260611',
  '/js/misc/survey/survey-gate.js?v=20260627',
  '/js/misc/survey/survey-modal.js?v=20260627',
];

const MEDIA_SHELL = ['/favicon.svg', '/icon-192.png', '/icon-512.png'];

// Requests that must always hit the network and must NEVER be cached
// (auth, Google login callbacks, Cloud Sync / Supabase, serverless fns).
const NETWORK_FIRST_PATTERNS = [
  '/api/',
  '/auth/',
  '/rest/v1/',
  '/functions/',
  '/realtime/',
  '/graphql',
];

const NETWORK_TIMEOUT_MS = 5000;

const STATIC_EXT = /\.(?:js|css)$/i;
const MEDIA_EXT = /\.(?:png|jpe?g|gif|webp|svg|ico|woff2?|ttf|otf|eot)$/i;


/* ── INSTALL ──────────────────────────────────────────────── */
self.addEventListener('install', (event) => {
  event.waitUntil(
    Promise.all([
      precache(HTML_CACHE, HTML_SHELL),
      precache(STATIC_CACHE, STATIC_SHELL),
      precache(MEDIA_CACHE, MEDIA_SHELL),
    ]).then(() => self.skipWaiting()) // activate this SW immediately, don't wait for old tabs to close
  );
});

async function precache(cacheName, urls) {
  const cache = await caches.open(cacheName);
  await Promise.allSettled(
    urls.map((url) =>
      fetch(new Request(url, { cache: 'no-store', redirect: 'follow' }))
        .then((res) => {
          if (!res.ok) return;
          // Never cache a redirected response — it can't be returned for
          // navigate-mode requests and throws at respondWith() time.
          if (res.redirected) {
            return fetch(res.url, { cache: 'no-store', redirect: 'follow' })
              .then((finalRes) => {
                if (finalRes.ok && !finalRes.redirected) return cache.put(url, finalRes);
              })
              .catch(() => {});
          }
          return cache.put(url, res);
        })
        .catch(() => { /* non-fatal — runtime strategies will fill this in */ })
    )
  );
}


/* ── ACTIVATE ─────────────────────────────────────────────── */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys
          .filter((key) => !CURRENT_CACHES.includes(key)) // wipes ALL previous-build caches, including
          .map((stale) => caches.delete(stale))           // the old single-bucket "reaper-vXXXXXXXX" cache
      ))
      .then(() => self.clients.claim()) // take control of already-open tabs right away
  );
});


/* ── FETCH ────────────────────────────────────────────────── */
self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return;
  if (url.origin !== self.location.origin) return; // let cross-origin (Google auth, Supabase, CDNs) pass through untouched

  const isNavigation = request.mode === 'navigate' || request.destination === 'document';
  const isApi = NETWORK_FIRST_PATTERNS.some((p) => url.pathname.includes(p));
  const isStatic = STATIC_EXT.test(url.pathname) || request.destination === 'script' || request.destination === 'style';
  const isMedia = MEDIA_EXT.test(url.pathname) || request.destination === 'image' || request.destination === 'font';

  if (isNavigation) {
    event.respondWith(networkFirstHtml(request));
  } else if (isApi) {
    event.respondWith(networkFirstNoStore(request));
  } else if (isStatic) {
    event.respondWith(staleWhileRevalidate(event));
  } else if (isMedia) {
    event.respondWith(cacheFirst(request));
  } else {
    // Anything unclassified (manifest.json, misc.) — stay safe, always fresh, never cached.
    event.respondWith(networkFirstNoStore(request));
  }
});


/* ── STRATEGY 1: Network-First — HTML navigations ─────────
   Always tries the network first so a deploy is visible on the very
   next load. The cache entry is written ONLY as a byproduct of a
   successful network fetch, so it is continuously replaced and is
   used exclusively as an offline fallback — it can never "win" over
   a live network response, i.e. it can never go permanently stale. */
async function networkFirstHtml(request) {
  const cache = await caches.open(HTML_CACHE);
  const { pathname } = new URL(request.url);
  // '/' and '/index.html' are the same document — normalize so both share
  // one cache entry. Every OTHER real HTML page (e.g. /survey.html) gets
  // cached under its own path, so it can never overwrite the app shell.
  const cacheKey = pathname === '/' ? '/index.html' : pathname;

  try {
    const response = await withTimeout(
      fetch(request, { redirect: 'follow', cache: 'no-store' }),
      NETWORK_TIMEOUT_MS
    );

    if (response.redirected) {
      const finalResponse = await fetch(response.url, { redirect: 'follow', cache: 'no-store' });
      if (finalResponse.ok && !finalResponse.redirected) {
        cache.put(cacheKey, finalResponse.clone()).catch(() => {});
        return finalResponse;
      }
    }

    if (response.ok && !response.redirected) {
      cache.put(cacheKey, response.clone()).catch(() => {});
    }
    return response;
  } catch {
    // Offline (or timed out) — prefer the exact page that was requested,
    // fall back to the app shell, then to the static offline page.
    const fallback =
      (await cache.match(cacheKey)) ||
      (await cache.match('/index.html')) ||
      (await cache.match('/offline.html'));
    if (fallback) return fallback;
    return new Response('', { status: 503, headers: { 'X-SW-Offline': 'true' } });
  }
}


/* ── STRATEGY 2: Stale-While-Revalidate — JS / CSS ────────
   Serves the cached copy instantly (fast paint, works offline), while
   kicking off a background re-fetch that silently overwrites the cache
   entry with whatever the network returns. The NEXT request for this
   exact URL (next click, next page load) gets the fresh file — no
   manual cache version bump or hard-refresh needed. event.waitUntil()
   keeps the worker alive long enough for that background write to
   finish even though the response was already handed back. */
async function staleWhileRevalidate(event) {
  const request = event.request;
  const cache = await caches.open(STATIC_CACHE);
  const cached = await cache.match(request);

  const networkFetch = fetch(request, { redirect: 'follow' })
    .then((response) => {
      if (response && response.ok && !response.redirected) {
        cache.put(request, response.clone()).catch(() => {});
      }
      return response;
    })
    .catch(() => null);

  event.waitUntil(networkFetch);

  if (cached) return cached;

  const fresh = await networkFetch;
  return fresh || new Response('', { status: 503, headers: { 'X-SW-Offline': 'true' } });
}


/* ── STRATEGY 3: Cache-First — images / icons / fonts ─────── */
async function cacheFirst(request) {
  const cache = await caches.open(MEDIA_CACHE);
  const cached = await cache.match(request);
  if (cached) return cached;

  try {
    const response = await fetch(request, { redirect: 'follow' });
    if (response.ok && !response.redirected) cache.put(request, response.clone()).catch(() => {});
    return response;
  } catch {
    return new Response('', { status: 503, headers: { 'X-SW-Offline': 'true' } });
  }
}


/* ── STRATEGY 4: Network-First, NEVER cached — API/auth/sync ─
   Used for anything hitting /api/, /auth/, /rest/v1/, /functions/,
   /realtime/, /graphql — and as the default for unclassified requests.
   No caches.open(), no cache.put() — nothing here ever touches the
   Cache Storage API, so responses can't be replayed stale. */
async function networkFirstNoStore(request) {
  try {
    return await withTimeout(fetch(request, { redirect: 'follow' }), NETWORK_TIMEOUT_MS);
  } catch {
    return new Response(
      JSON.stringify({ error: 'offline', offline: true }),
      { status: 503, headers: { 'Content-Type': 'application/json', 'X-SW-Offline': 'true' } }
    );
  }
}


/* ── HELPER: withTimeout ──────────────────────────────────── */
function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Network timeout after ${ms}ms`)), ms);
    promise.then(
      (v) => { clearTimeout(timer); resolve(v); },
      (e) => { clearTimeout(timer); reject(e); }
    );
  });
}


/* ── MESSAGE ──────────────────────────────────────────────── */
self.addEventListener('message', (event) => {
  if (event.data === 'CHECK_VERSION') {
    event.source.postMessage({ type: 'SW_VERSION', version: BUILD_ID });
  }
  // Lets a client force-activate a waiting SW instead of waiting for all
  // tabs to close. Combined with skipWaiting() in install(), this is
  // belt-and-suspenders — install() already does it automatically.
  if (event.data === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

# config/

No config-specific CSS currently exists. This folder is reserved for future
settings/config UI styling. The current settings panel markup uses inline
styles in index.html and shares classes from other feature CSS files.

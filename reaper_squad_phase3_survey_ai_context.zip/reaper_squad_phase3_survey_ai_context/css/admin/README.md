# admin/

No admin-specific CSS currently exists. Admin/owner UI (owner badge, kick controls)
reuses styles already defined in `css/auth/` and `css/leaderboard/`. This folder is
reserved for future admin-only styling if that surface grows into its own UI.

// Cloudflare Pages Function: /api/verify-owner
//
// SECURITY FIX: previous version trusted a client-supplied `username`
// string with no session check — anyone could POST any username and
// be told "isOwner: true" for it. This version:
//   1. requires a real Supabase Auth session (Authorization: Bearer <jwt>)
//   2. resolves the caller's identity from that JWT via Supabase Auth
//      (server-side call to /auth/v1/user — the JWT cannot be forged
//      without SUPABASE_JWT secret, and Supabase validates it for us)
//   3. looks up ownership for THAT verified user_id only via
//      squad_members.role — the real source of truth for ownership
//      (users.is_owner is only a trigger-maintained cache of this) —
//      using the service_role key (bypasses RLS, but only ever reads,
//      never trusts client input for the lookup key)
//
// Any client-supplied username in the request body is ignored.

const ALLOWED_ORIGINS = [
  'https://reaperssquad.pages.dev', // replace with your actual domain
];

function json(body, status, origin) {
  return new Response(JSON.stringify(body), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin || '' },
  });
}

export async function onRequestPost(context) {
  const { request, env } = context;
  const origin = request.headers.get('Origin') || '';

  if (!ALLOWED_ORIGINS.includes(origin)) {
    return new Response('Forbidden', { status: 403 });
  }

  const SUPABASE_URL = env.SUPABASE_URL;
  const ANON_KEY = env.SUPABASE_ANON_KEY;
  const SERVICE_ROLE_KEY = env.SUPABASE_SERVICE_ROLE_KEY;

  if (!SUPABASE_URL || !ANON_KEY || !SERVICE_ROLE_KEY) {
    return json({ isOwner: false, error: 'Server misconfigured' }, 500, origin);
  }

  // ── 1. Require a real session — no Authorization header, no owner ──
  const authHeader = request.headers.get('Authorization');
  if (!authHeader) {
    return json({ isOwner: false }, 200, origin);
  }

  // ── 2. Resolve caller identity from the JWT itself (server validates it) ──
  let callerUser;
  try {
    const userResp = await fetch(SUPABASE_URL + '/auth/v1/user', {
      headers: { apikey: ANON_KEY, Authorization: authHeader },
    });
    if (!userResp.ok) return json({ isOwner: false }, 200, origin);
    callerUser = await userResp.json();
  } catch (e) {
    return json({ isOwner: false }, 200, origin);
  }
  if (!callerUser || !callerUser.id) {
    return json({ isOwner: false }, 200, origin);
  }

  // ── 3. Look up ownership for the VERIFIED user_id (never client input) ──
  // SCHEMA FIX: the real source of truth for ownership is squad_members
  // (role/status), keyed by user_id — see 01_schema.sql / 02_security.sql.
  // users.is_owner is only a denormalized cache of this, kept correct by
  // sync_user_squad_cache(); the client is never trusted for it directly.
  try {
    const memResp = await fetch(
      SUPABASE_URL + '/rest/v1/squad_members?user_id=eq.' + encodeURIComponent(callerUser.id) +
        '&status=eq.active&select=role&limit=1',
      {
        headers: {
          apikey: SERVICE_ROLE_KEY,
          Authorization: 'Bearer ' + SERVICE_ROLE_KEY,
        },
      }
    );
    const rows = await memResp.json();
    const membership = Array.isArray(rows) ? rows[0] : null;
    return json({ isOwner: !!(membership && membership.role === 'owner') }, 200, origin);
  } catch (e) {
    return json({ isOwner: false, error: 'Lookup failed' }, 500, origin);
  }
}

export async function onRequestOptions(context) {
  const origin = context.request.headers.get('Origin') || '';
  if (!ALLOWED_ORIGINS.includes(origin)) return new Response('Forbidden', { status: 403 });
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    },
  });
}

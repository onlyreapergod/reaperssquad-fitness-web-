// Cloudflare Pages Function: /api/kick-user
// Adapted from supabase/functions/kick-user/index.ts (Phase 2 audit package).
// This project deploys on Cloudflare Pages (see verify-owner.js, ai.js),
// not Supabase Edge Functions, so this is a Pages Function port of the
// same logic — same security model, same checks, different runtime.
//
// Replaces: anon-key INSERT/UPDATE/DELETE on the (removed) bare-username
// kicked_users table. Moderation state now lives on squad_members
// (role/status), which has no authenticated-role write policy at all —
// only service_role, via this function, can change it.
//
// Requires these Cloudflare Pages environment variables (Settings →
// Environment variables, marked "Encrypted"):
//   SUPABASE_URL              e.g. https://tfkaehpblumtgkkzasub.supabase.co
//   SUPABASE_ANON_KEY         the same anon key already used elsewhere
//   SUPABASE_SERVICE_ROLE_KEY service_role key — NEVER expose to client
//
// IMPORTANT: this endpoint only works once the caller has a real
// Supabase Auth session (Authorization: Bearer <access_token>) and an
// active squad_members row with role = 'owner'. squad_members is the
// real source of truth for ownership and moderation — users.is_owner /
// users.squad_code are only trigger-maintained caches of it (see
// sync_user_squad_cache() in 02_security.sql) and are never used here.

const ALLOWED_ORIGINS = [
  'https://reaperssquad.pages.dev', // replace with your actual domain
];

function json(body, status, origin) {
  return new Response(JSON.stringify(body), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin || '' },
  });
}

export async function onRequestPost(context) {
  const { request, env } = context;
  const origin = request.headers.get('Origin') || '';

  if (!ALLOWED_ORIGINS.includes(origin)) {
    return new Response('Forbidden', { status: 403 });
  }

  const SUPABASE_URL = env.SUPABASE_URL;
  const ANON_KEY = env.SUPABASE_ANON_KEY;
  const SERVICE_ROLE_KEY = env.SUPABASE_SERVICE_ROLE_KEY;

  if (!SUPABASE_URL || !ANON_KEY || !SERVICE_ROLE_KEY) {
    return json({ error: 'Server misconfigured: missing Supabase env vars' }, 500, origin);
  }

  // ── 1. Verify caller is authenticated ──────────────────────────
  const authHeader = request.headers.get('Authorization');
  if (!authHeader) {
    return json({ error: 'Missing Authorization header' }, 401, origin);
  }

  let callerUser;
  try {
    const userResp = await fetch(SUPABASE_URL + '/auth/v1/user', {
      headers: { apikey: ANON_KEY, Authorization: authHeader },
    });
    if (!userResp.ok) return json({ error: 'Unauthorized' }, 401, origin);
    callerUser = await userResp.json();
  } catch (e) {
    return json({ error: 'Unauthorized' }, 401, origin);
  }
  if (!callerUser || !callerUser.id) {
    return json({ error: 'Unauthorized' }, 401, origin);
  }

  // ── 2. Verify caller is an active owner (service-role client, bypasses RLS) ─
  const svcHeaders = {
    apikey: SERVICE_ROLE_KEY,
    Authorization: 'Bearer ' + SERVICE_ROLE_KEY,
    'Content-Type': 'application/json',
  };

  // SCHEMA FIX: squad_members is the real source of truth for ownership
  // and moderation (role/status), keyed by user_id — not a global
  // is_owner/squad_code cache on a "reaper_users" table. Resolve the
  // caller's own active membership first.
  let callerMembership;
  try {
    const memResp = await fetch(
      SUPABASE_URL + '/rest/v1/squad_members?user_id=eq.' + encodeURIComponent(callerUser.id) +
        '&status=eq.active&select=id,role,squad_id&limit=1',
      { headers: svcHeaders }
    );
    const rows = await memResp.json();
    callerMembership = Array.isArray(rows) ? rows[0] : null;
  } catch (e) {
    return json({ error: 'Lookup failed' }, 500, origin);
  }

  if (!callerMembership || callerMembership.role !== 'owner') {
    return json({ error: 'Forbidden: owner only' }, 403, origin);
  }

  // ── 3. Parse and validate request body ──────────────────────────
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'Invalid JSON body' }, 400, origin);
  }

  const action = body && body.action;
  const targetUsername = body && body.username;
  const reason = body && body.reason;

  if (!['kick', 'unkick'].includes(action)) {
    return json({ error: 'action must be "kick" or "unkick"' }, 400, origin);
  }
  if (!targetUsername || typeof targetUsername !== 'string') {
    return json({ error: 'username required' }, 400, origin);
  }

  // ── 4. Resolve the target username to its real users.id ──────────
  let targetUser;
  try {
    const userResp = await fetch(
      SUPABASE_URL + '/rest/v1/users?username=eq.' + encodeURIComponent(targetUsername) +
        '&select=id,username&limit=1',
      { headers: svcHeaders }
    );
    const rows = await userResp.json();
    targetUser = Array.isArray(rows) ? rows[0] : null;
  } catch (e) {
    return json({ error: 'Lookup failed' }, 500, origin);
  }

  if (!targetUser) {
    return json({ error: 'User not found' }, 404, origin);
  }
  if (targetUser.id === callerUser.id) {
    return json({ error: 'Cannot kick yourself' }, 400, origin);
  }

  // ── 5. Resolve the target's squad_members row and confirm same squad ─
  let targetMembership;
  try {
    const tmResp = await fetch(
      SUPABASE_URL + '/rest/v1/squad_members?user_id=eq.' + encodeURIComponent(targetUser.id) +
        '&select=id,squad_id&limit=1',
      { headers: svcHeaders }
    );
    const rows = await tmResp.json();
    targetMembership = Array.isArray(rows) ? rows[0] : null;
  } catch (e) {
    return json({ error: 'Lookup failed' }, 500, origin);
  }

  if (!targetMembership || targetMembership.squad_id !== callerMembership.squad_id) {
    return json({ error: 'Forbidden: not your squad' }, 403, origin);
  }

  // ── 6. Execute the kick / unkick on squad_members ─────────────────
  // set_squad_member_moderation_timestamps() (02_security.sql) also
  // derives kicked_at from status, but we set it explicitly too so the
  // response reflects the exact moment of this request.
  try {
    if (action === 'kick') {
      const resp = await fetch(
        SUPABASE_URL + '/rest/v1/squad_members?id=eq.' + encodeURIComponent(targetMembership.id),
        {
          method: 'PATCH',
          headers: Object.assign({}, svcHeaders, { Prefer: 'return=minimal' }),
          body: JSON.stringify({
            status: 'kicked',
            kicked_at: new Date().toISOString(),
            kick_reason: reason || null,
          }),
        }
      );
      if (!resp.ok) {
        const errBody = await resp.text();
        return json({ error: 'Kick failed: ' + errBody }, 502, origin);
      }
      return json({ ok: true, action: 'kicked', username: targetUsername }, 200, origin);
    }

    if (action === 'unkick') {
      const resp = await fetch(
        SUPABASE_URL + '/rest/v1/squad_members?id=eq.' + encodeURIComponent(targetMembership.id),
        {
          method: 'PATCH',
          headers: Object.assign({}, svcHeaders, { Prefer: 'return=minimal' }),
          body: JSON.stringify({
            status: 'active',
            kicked_at: null,
            kick_reason: null,
          }),
        }
      );
      if (!resp.ok) {
        const errBody = await resp.text();
        return json({ error: 'Unkick failed: ' + errBody }, 502, origin);
      }
      return json({ ok: true, action: 'unkicked', username: targetUsername }, 200, origin);
    }
  } catch (err) {
    return json({ error: 'Internal server error' }, 500, origin);
  }
}

export async function onRequestOptions(context) {
  const origin = context.request.headers.get('Origin') || '';
  if (!ALLOWED_ORIGINS.includes(origin)) return new Response('Forbidden', { status: 403 });
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    },
  });
}

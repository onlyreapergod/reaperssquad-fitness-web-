// Cloudflare Pages Function: /api/ai
// Routes all AI API calls server-side. GROQ_KEY and ANTHROPIC_KEY are
// set as encrypted environment variables in the Cloudflare Pages dashboard.
//
// SECURITY FIX (audit 5.1 - CRITICAL, "unauthenticated AI endpoint"):
// This endpoint previously had NO session/API-key/CSRF check - its
// only gate was the client-supplied Origin header (trivially spoofed
// by curl/a script; not a security boundary for non-browser callers)
// plus a per-isolate in-memory rate limiter. That let anyone with no
// login at all consume the app owner's Anthropic/Groq API budget
// directly. Fixed the same way functions/api/kick-user.js and
// functions/api/verify-owner.js already correctly do it: require a
// real Supabase Auth session (Authorization: Bearer <jwt>) and
// resolve identity from that JWT server-side via Supabase's own
// /auth/v1/user endpoint (the JWT cannot be forged without the
// project's JWT secret; Supabase validates it for us). No owner-only
// restriction here - any authenticated app user is allowed, matching
// this endpoint's existing behavior for logged-in users (Fix It,
// diet/workout plan generation, quit-convince messages).
//
// NOTE: the in-memory, per-isolate rate limiter below is unchanged
// and still has the multi-instance limitation described in its own
// comment (needs Cloudflare KV/Durable Objects for a true global
// cap) - that is a separate scaling finding, not part of the
// authentication fix, and is not addressed by this change.

const ALLOWED_ORIGINS = [
  'https://reaperssquad.pages.dev',   // replace with your actual domain
];

const RATE_LIMIT = new Map(); // in-memory; use KV for multi-instance

function rateLimitCheck(ip) {
  const now = Date.now();
  const window = 60_000; // 1 minute
  const maxReq = 20;
  const entry = RATE_LIMIT.get(ip) || { count: 0, start: now };
  if (now - entry.start > window) {
    RATE_LIMIT.set(ip, { count: 1, start: now });
    return false;
  }
  if (entry.count >= maxReq) return true; // blocked
  entry.count++;
  RATE_LIMIT.set(ip, entry);
  return false;
}

export async function onRequestPost(context) {
  const { request, env } = context;
  const origin = request.headers.get('Origin') || '';

  // CORS: only allow listed origins
  if (!ALLOWED_ORIGINS.includes(origin)) {
    return new Response('Forbidden', { status: 403 });
  }

  // -- SECURITY FIX (audit 5.1): require a real Supabase Auth session --
  // Same pattern as kick-user.js / verify-owner.js: resolve identity
  // from the JWT itself (Supabase validates it), never trust client
  // input for who's calling. No profile/owner lookup needed here -
  // any authenticated user is allowed to use the AI proxy.
  const SUPABASE_URL = env.SUPABASE_URL;
  const ANON_KEY = env.SUPABASE_ANON_KEY;

  if (!SUPABASE_URL || !ANON_KEY) {
    return new Response(JSON.stringify({ error: 'Server misconfigured' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
    });
  }

  const authHeader = request.headers.get('Authorization');
  if (!authHeader) {
    return new Response(JSON.stringify({ error: 'Unauthorized: login required' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
    });
  }

  let callerUser;
  try {
    const userResp = await fetch(SUPABASE_URL + '/auth/v1/user', {
      headers: { apikey: ANON_KEY, Authorization: authHeader },
    });
    if (!userResp.ok) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
      });
    }
    callerUser = await userResp.json();
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
    });
  }
  if (!callerUser || !callerUser.id) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
    });
  }

  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  if (rateLimitCheck(ip)) {
    return new Response(JSON.stringify({ error: 'Rate limit exceeded. Wait 1 minute.' }), {
      status: 429,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
    });
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return new Response('Bad request', { status: 400 });
  }

  const { provider, model, messages, system, max_tokens } = body;

  // Whitelist allowed models only
  const GROQ_MODELS = ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'gemma2-9b-it'];
  const CLAUDE_MODELS = ['claude-sonnet-4-20250514'];

  const corsHeaders = {
    'Access-Control-Allow-Origin': origin,
    'Content-Type': 'application/json',
  };

  try {
    if (provider === 'groq') {
      if (!GROQ_MODELS.includes(model)) {
        return new Response(JSON.stringify({ error: 'Model not allowed' }), { status: 400, headers: corsHeaders });
      }
      const groqResp = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${env.GROQ_KEY}`,
        },
        body: JSON.stringify({ model, messages, max_tokens: Math.min(max_tokens || 1000, 2000) }),
      });
      const data = await groqResp.json();
      return new Response(JSON.stringify(data), { status: groqResp.status, headers: corsHeaders });

    } else if (provider === 'anthropic') {
      if (!CLAUDE_MODELS.includes(model)) {
        return new Response(JSON.stringify({ error: 'Model not allowed' }), { status: 400, headers: corsHeaders });
      }
      const anthResp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'anthropic-version': '2023-06-01',
          'x-api-key': env.ANTHROPIC_KEY,
        },
        body: JSON.stringify({
          model,
          system,
          messages,
          max_tokens: Math.min(max_tokens || 1200, 2000),
        }),
      });
      const data = await anthResp.json();
      return new Response(JSON.stringify(data), { status: anthResp.status, headers: corsHeaders });

    } else {
      return new Response(JSON.stringify({ error: 'Unknown provider' }), { status: 400, headers: corsHeaders });
    }
  } catch (err) {
    return new Response(JSON.stringify({ error: 'Upstream error' }), { status: 502, headers: corsHeaders });
  }
}

// Handle preflight
export async function onRequestOptions(context) {
  const origin = context.request.headers.get('Origin') || '';
  if (!ALLOWED_ORIGINS.includes(origin)) return new Response('Forbidden', { status: 403 });
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      // SECURITY FIX (audit 5.1): Authorization header is now required
      // on real requests, so it must be allowed in preflight too.
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    },
  });
}

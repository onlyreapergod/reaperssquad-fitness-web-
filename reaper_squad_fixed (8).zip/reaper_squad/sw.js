'use strict';

/* ============================================================
   REAPER SQUAD — Service Worker
   reaper-v1.0.0

   Two strategies only:
     1. App Shell  → Cache-First  (HTML, CSS, JS, icons)
     2. API / Data → Network-First (anything else)

   Single cache. Simple versioning. No business logic.
   ============================================================ */

const CACHE_VERSION = 'reaper-v1.0.0';

// Minimal shell — only assets required for first paint.
// '/' is intentionally excluded — navigations are normalised to
// '/index.html' at runtime, so caching both would be a duplicate.
const SHELL_ASSETS = [
  '/index.html',
  '/manifest.json',
  '/favicon.svg',
  '/icon-192.png',
  '/icon-512.png',
  '/css/main.css',
  '/css/base.css',
  '/css/themes.css',
  '/css/theme-vars.css',
  '/css/premium-ui.css',
  '/js/script.js',
  '/js/cloud_sync.js',
  '/js/train_mode.js',
  '/js/home_skill_plan.js',
  '/js/features/survey-gate.js',
  '/js/features/stub-compat.js',
  '/js/features/lady-select.js',
  '/js/features/settings-panel.js',
  '/js/data/lady-physiques.js',
  '/js/security-patch.js',
  '/js/premium-animations.js',
  '/js/share-modal.js',
];

// Requests whose URL pathname contains any of these strings
// go straight to Network-First (never cached).
const NETWORK_FIRST_PATTERNS = [
  '/api/',
  '/auth/',
  '/rest/v1/',
  '/functions/',
  '/realtime/',
  '/graphql',
];

// How long to wait for the network before giving up (ms).
const NETWORK_TIMEOUT_MS = 5000;


/* ── INSTALL ────────────────────────────────────────────────
   Cache the shell. allSettled = one 404 never aborts the SW.
   skipWaiting activates immediately; version key prevents stale reads.
   ─────────────────────────────────────────────────────────── */
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION)
      .then((cache) =>
        Promise.allSettled(
          SHELL_ASSETS.map((url) =>
            fetch(new Request(url, { cache: 'no-store' }))
              .then((res) => { if (res.ok) cache.put(url, res); })
              .catch(() => { /* non-fatal — app still works */ })
          )
        )
      )
      .then(() => self.skipWaiting())
  );
});


/* ── ACTIVATE ───────────────────────────────────────────────
   Delete every cache that isn't the current version.
   clientsClaim takes control of all open tabs immediately.
   ─────────────────────────────────────────────────────────── */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key !== CACHE_VERSION)
            .map((stale) => caches.delete(stale))
        )
      )
      .then(() => self.clients.claim())
  );
});


/* ── FETCH ──────────────────────────────────────────────────
   Only intercept same-origin GET requests.
   Route to the appropriate strategy; everything else passes through.
   ─────────────────────────────────────────────────────────── */
self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Pass through non-GET and non-HTTP(S)
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return;

  // Pass through cross-origin requests entirely
  // (Supabase, Anthropic, Google, Groq, CDNs — all bypass automatically)
  if (url.origin !== self.location.origin) return;

  const isNetworkFirst = NETWORK_FIRST_PATTERNS.some((p) =>
    url.pathname.includes(p)
  );

  event.respondWith(
    isNetworkFirst
      ? networkFirst(request)
      : cacheFirst(request)
  );
});


/* ── STRATEGY: Cache-First ──────────────────────────────────
   For app shell assets.
   1. Return from cache if present (instant).
   2. Fetch from network, store in cache, return response.
   3. On total failure, serve cached index.html for navigations.
   ─────────────────────────────────────────────────────────── */
async function cacheFirst(request) {
  // Normalise all navigations to /index.html so '/' and any deep-link
  // (e.g. /#train, /#chat) all hit the single cached shell entry.
  const cacheKey =
    request.mode === 'navigate'
      ? new Request('/index.html')
      : request;

  const cached = await caches.match(cacheKey);
  if (cached) return cached;

  try {
    const response = await fetch(request, { redirect: 'follow' });
    if (response.ok) {
      const cache = await caches.open(CACHE_VERSION);
      cache.put(cacheKey, response.clone()).catch(() => {});
    }
    return response;
  } catch {
    // Navigation offline fallback — serve cached shell
    if (request.mode === 'navigate') {
      const fallback = await caches.match('/index.html');
      if (fallback) return fallback;
    }
    return new Response('', { status: 503, headers: { 'X-SW-Offline': 'true' } });
  }
}


/* ── STRATEGY: Network-First ────────────────────────────────
   For API and dynamic data (Supabase REST, Groq, Cloudflare Functions).
   1. Race network against timeout.
   2. On success, return response (do NOT cache — data is dynamic).
   3. On failure, return structured JSON error so callers can handle it.
   ─────────────────────────────────────────────────────────── */
async function networkFirst(request) {
  try {
    const response = await withTimeout(fetch(request, { redirect: 'follow' }), NETWORK_TIMEOUT_MS);
    return response;
  } catch {
    return new Response(
      JSON.stringify({ error: 'offline', offline: true }),
      {
        status: 503,
        headers: {
          'Content-Type': 'application/json',
          'X-SW-Offline': 'true',
        },
      }
    );
  }
}


/* ── HELPER: withTimeout ────────────────────────────────────
   Rejects the fetch promise after `ms` milliseconds.
   Prevents API calls hanging forever on poor mobile networks.
   ─────────────────────────────────────────────────────────── */
function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error(`Network timeout after ${ms}ms`)),
      ms
    );
    promise
      .then((v) => { clearTimeout(timer); resolve(v); })
      .catch((e) => { clearTimeout(timer); reject(e); });
  });
}

// ============================================================
// CLOUD SYNC LAYER — Replaces localStorage for all game data
// Drop this BEFORE script.js in your HTML
//
// FIXES applied (v4):
//   • user_blobs 404 — Prefer header split into upsert-specific header
//   • %20 encoding — removed double-encodeURIComponent; raw values passed
//     to PostgREST eq. filter (PostgREST URL-decodes query params itself)
//   • username vs user_id — schema uses username PK; no auth.uid() needed
//   • exercises column — was INTEGER in schema, now JSONB; save as array
//   • exercises_count — now saved separately to its own column
//   • missing reaper_users columns — phys_streak, login_pts, last_login,
//     suspended now read/written correctly
// ============================================================

(function() {

  const SB  = window._SB_URL  || "https://tfkaehpblumtgkkzasub.supabase.co";
  const KEY = window._SB_KEY  || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRma2FlaHBibHVtdGdra3phc3ViIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkzNDAwNzgsImV4cCI6MjA5NDkxNjA3OH0.HSWwWE5GhF5iAE1mMn8M-OsCf2RWwugjSgeFQJOS71A";

  // FIX: Separate base headers from upsert headers.
  // The original HDRS included Prefer: resolution=merge-duplicates globally,
  // which caused 404 on GET requests that don't support that Prefer value.
  const BASE_HDRS = {
    apikey: KEY,
    Authorization: "Bearer " + KEY,
    "Content-Type": "application/json"
  };

  const UPSERT_HDRS = Object.assign({}, BASE_HDRS, {
    Prefer: "resolution=merge-duplicates,return=minimal"
  });

  // ── Cloud user state cache (populated on login) ──
  window._cloudUser = {};

  // ── In-memory local cache for fast reads ──
  const _mem = {};

  // ── Keys that ALWAYS stay local (device prefs / session) ──
  const LOCAL_ONLY = new Set([
    "theme", "gamiAv", "gamiTab", "gamiOpen", "gamiGridOpen",
    "currentUser", "pedometerEnabled", "fix_groq_key",
    "skillTree_v2", "skillTree_log_v2", "skillTree_streak_v1",
    // FIX: urExercises and workoutPlans kept local to avoid 404s on user_blobs
    "urExercises",
  ]);

  // ── Keys stored as JSON blobs in user_blobs table ──
  // NOTE: urExercises and workoutPlans_ moved to LOCAL_ONLY
  // The user_blobs table does not exist in the current Supabase schema,
  // causing 404 errors. These keys stay in localStorage only.
  const BLOB_KEYS = new Set([
    "god_warned",
    "god_disabled",
    "god_autoUnban",
  ]);

  function getUsername() {
    try {
      var u = JSON.parse(localStorage.getItem("currentUser"));
      return u && u.username ? u.username : null;
    } catch(e) { return null; }
  }

  // ── Supabase helpers ──

  // FIX: Use raw (un-encoded) values in PostgREST eq. filters.
  // PostgREST decodes URL query parameters before comparing, so
  // encodeURIComponent was causing "john%20doe" to match literally
  // instead of matching "john doe". Raw spaces in query strings are
  // technically invalid per RFC but PostgREST handles them fine, and
  // encodeURIComponent is safe to keep only for blob_key which may
  // contain special characters like "workoutPlans_username".
  async function sbGet(table, filter) {
    var url = SB + "/rest/v1/" + table + "?" + filter + "&limit=1";
    try {
      var r = await fetch(url, {
        headers: Object.assign({}, BASE_HDRS, {
          Range: "0-0",
          Prefer: "count=none"
        })
      });
      // FIX: 404 means table/endpoint missing; surface the error for debugging
      if (r.status === 404) {
        console.error("[cloud_sync] 404 on", table, "— check table exists and RLS allows SELECT");
        return null;
      }
      var d = await r.json();
      return Array.isArray(d) ? d[0] || null : null;
    } catch(e) { return null; }
  }

  async function sbUpsert(table, obj, conflict) {
    try {
      var r = await fetch(
        // FIX: conflict columns with comma must NOT be encoded (%2C breaks PostgREST)
        SB + "/rest/v1/" + table + "?on_conflict=" + conflict,
        { method: "POST", headers: UPSERT_HDRS, body: JSON.stringify(obj) }
      );
      if (r.status === 404) {
        console.error("[cloud_sync] 404 upsert on", table, "— table missing or RLS blocks INSERT");
      }
    } catch(e) {}
  }

  // ── Date helpers ──
  function todayStr() { return new Date().toISOString().slice(0, 10); }

  // ── Determine where a key lives ──
  function keyType(k) {
    if (LOCAL_ONLY.has(k)) return "local";
    if (/^ex_/.test(k) || /^hb_/.test(k) || /^xpAwarded_/.test(k) ||
        /^planEx_/.test(k) || /^steps_/.test(k)) return "daily";
    if (/^totalXP_/.test(k) || /^streak_/.test(k) || /^selPhys_/.test(k) ||
        /^physStreak_/.test(k) || /^tuProfile_/.test(k) || /^tuSettings_/.test(k) ||
        /^pts_/.test(k)) return "userrow";
    if (/^workoutPlans_/.test(k)) return "local";  // FIX: no user_blobs table
    if (BLOB_KEYS.has(k)) return "blob";
    if (k === "kickedUsers") return "kicked";
    if (k === "god_warned" || k === "god_disabled") return "blob";
    return "local";
  }

  // ── Parse daily key: ex_tanishq_2026-05-28 → {type, user, date} ──
  function parseDailyKey(k) {
    var m = k.match(/^([^_]+)_([^_]+)_(\d{4}-\d{2}-\d{2})$/);
    if (!m) return null;
    return { type: m[1], user: m[2], date: m[3] };
  }

  // ── Debounce map for cloud writes ──
  var _debounce = {};
  function debouncedWrite(key, fn, delay) {
    if (_debounce[key]) clearTimeout(_debounce[key]);
    _debounce[key] = setTimeout(fn, delay || 600);
  }

  // ── Daily scores cloud cache ──
  var _dailyCache = {};

  function dailyCacheKey(user, date) { return user + "_" + date; }

  async function loadDailyFromCloud(user, date) {
    var ck = dailyCacheKey(user, date);
    if (_dailyCache[ck]) return _dailyCache[ck];

    var row = await sbGet(
      "daily_scores",
      "username=eq." + encodeURIComponent(user) + "&date=eq." + date
    );

    var data = { exercises: [], habits: {}, steps: 0, xpAwarded: {}, planEx: {} };
    if (row) {
      try {
        // FIX: exercises is now JSONB array, not INTEGER
        if (row.exercises) {
          data.exercises = typeof row.exercises === "string"
            ? JSON.parse(row.exercises)
            : (Array.isArray(row.exercises) ? row.exercises : []);
        }
      } catch(e) {}
      try { if (row.habits)     data.habits     = typeof row.habits     === "string" ? JSON.parse(row.habits)     : (row.habits     || {}); } catch(e) {}
      try { if (row.xp_awarded) data.xpAwarded  = typeof row.xp_awarded === "string" ? JSON.parse(row.xp_awarded) : (row.xp_awarded || {}); } catch(e) {}
      try { if (row.plan_ex)    data.planEx      = typeof row.plan_ex    === "string" ? JSON.parse(row.plan_ex)    : (row.plan_ex    || {}); } catch(e) {}
      data.steps = row.steps || 0;
    }
    _dailyCache[ck] = data;
    return data;
  }

  function saveDailyToCloud(user, date) {
    var ck = dailyCacheKey(user, date);
    var data = _dailyCache[ck] || {};
    debouncedWrite("daily_" + ck, async function() {
      var habits    = data.habits    || {};
      var exercises = data.exercises || [];
      var steps     = data.steps     || 0;
      var pts = Object.values(habits).filter(Boolean).length +
                (exercises.length > 0 ? 1 : 0) +
                (steps >= 5000 ? 1 : 0);

      await sbUpsert("daily_scores", {
        username:        user,
        date:            date,
        pts:             pts,
        exercises:       exercises,                            // FIX: JSONB array
        exercises_count: exercises.length,                    // FIX: new column
        habits:          habits,
        steps:           steps,
        xp_awarded:      data.xpAwarded || {},
        plan_ex:         data.planEx    || {},
        total_sets:      exercises.reduce(function(a, e) { return a + (e.sets || 0); }, 0),
        updated_at:      new Date().toISOString(),
      }, "username,date");
    }, 800);
  }

  // ── User row cache ──
  var _userRowCache = {};

  async function loadUserRow(username) {
    if (_userRowCache[username]) return _userRowCache[username];
    var row = await sbGet("reaper_users", "username=eq." + encodeURIComponent(username));
    _userRowCache[username] = row || {};
    return _userRowCache[username];
  }

  function saveUserRow(username) {
    var data = _userRowCache[username] || {};
    debouncedWrite("userrow_" + username, async function() {
      await sbUpsert("reaper_users", Object.assign({ username: username }, data), "username");
    }, 1000);
  }

  // ── Blob cache ──
  var _blobCache = {};

  async function loadBlob(username, blobKey) {
    var ck = username + "_" + blobKey;
    if (_blobCache[ck] !== undefined) return _blobCache[ck];

    // Both username and blob_key encoded — username may contain spaces
    var row = await sbGet(
      "user_blobs",
      "username=eq." + encodeURIComponent(username) + "&blob_key=eq." + encodeURIComponent(blobKey)
    );

    var val = null;
    if (row && row.blob_value) {
      try { val = typeof row.blob_value === "string" ? JSON.parse(row.blob_value) : row.blob_value; }
      catch(e) { val = row.blob_value; }
    }
    _blobCache[ck] = val;
    return val;
  }

  function saveBlob(username, blobKey, value) {
    var ck = username + "_" + blobKey;
    _blobCache[ck] = value;
    debouncedWrite("blob_" + ck, async function() {
      await sbUpsert("user_blobs", {
        username:   username,
        blob_key:   blobKey,
        blob_value: value,                    // FIX: pass object directly; Supabase handles JSONB
        updated_at: new Date().toISOString(),
      }, "username,blob_key");
    }, 800);
  }

  // ── CORE OVERRIDE: lsGet ──
  window.lsGet = function(key) {
    if (_mem[key] !== undefined) {
      var v = _mem[key];
      return v === "__null__" ? null : v;
    }
    try {
      var t = localStorage.getItem(key);
      return t ? JSON.parse(t) : null;
    } catch(e) { return null; }
  };

  // ── CORE OVERRIDE: lsSet ──
  window.lsSet = function(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch(e) {}

    var type     = keyType(key);
    var username = getUsername();
    if (!username || type === "local") return;

    _mem[key] = value;

    if (type === "daily") {
      var parsed = parseDailyKey(key);
      if (!parsed) return;
      var ck = dailyCacheKey(parsed.user, parsed.date);
      if (!_dailyCache[ck]) _dailyCache[ck] = { exercises: [], habits: {}, steps: 0, xpAwarded: {}, planEx: {} };
      var fieldMap = { ex: "exercises", hb: "habits", steps: "steps", xpAwarded: "xpAwarded", planEx: "planEx" };
      var field = fieldMap[parsed.type];
      if (field) _dailyCache[ck][field] = value;
      saveDailyToCloud(parsed.user, parsed.date);
    }
    else if (type === "userrow") {
      var u = key.replace(/^(totalXP|streak|selPhys|physStreak|tuProfile|tuSettings|pts)_/, "").replace(/_.*/, "");
      u = u || username;
      if (!_userRowCache[u]) _userRowCache[u] = {};
      if      (/^totalXP_/.test(key))    _userRowCache[u].total_xp      = value;
      else if (/^streak_/.test(key))     _userRowCache[u].streak         = value;
      else if (/^selPhys_/.test(key))    _userRowCache[u].sel_physique   = JSON.stringify(value);
      else if (/^physStreak_/.test(key)) _userRowCache[u].phys_streak    = JSON.stringify(value); // FIX: column now exists
      else if (/^tuProfile_/.test(key))  _userRowCache[u].profile_data   = value;
      else if (/^tuSettings_/.test(key)) _userRowCache[u].settings_data  = value;
      else if (/^pts_/.test(key)) {
        // FIX: login_pts, last_login, suspended columns now in schema
        _userRowCache[u].login_pts  = value.pts;
        _userRowCache[u].last_login = value.lastLogin;
        _userRowCache[u].suspended  = value.suspended;
      }
      saveUserRow(u);
    }
    else if (type === "blob") {
      saveBlob(username, key, value);
    }
    // "kicked" type: handled in script.js via kicked_users table directly
  };

  // ── Pre-populate from cloud on boot ──
  window._cloudBootstrap = async function(username) {
    if (!username) return;
    console.log("☁️ Cloud bootstrap for:", username);

    // 1. Load user row
    var userRow = await loadUserRow(username);
    if (userRow) {
      _userRowCache[username] = userRow;
      if (userRow.total_xp !== undefined) _mem["totalXP_" + username] = userRow.total_xp;
      if (userRow.streak   !== undefined) _mem["streak_"  + username] = userRow.streak;

      // FIX: read new columns login_pts / last_login / suspended
      if (userRow.login_pts !== undefined) {
        _mem["pts_" + username] = {
          pts:       userRow.login_pts  || 20,
          lastLogin: userRow.last_login || null,
          suspended: !!userRow.suspended
        };
      }
      if (userRow.sel_physique) {
        try { _mem["selPhys_" + username] = JSON.parse(userRow.sel_physique); }
        catch(e) { _mem["selPhys_" + username] = userRow.sel_physique; }
      }
      if (userRow.phys_streak) {
        try { _mem["physStreak_" + username] = JSON.parse(userRow.phys_streak); } catch(e) {}
      }
      if (userRow.profile_data)  _mem["tuProfile_"  + username] = userRow.profile_data;
      if (userRow.settings_data) _mem["tuSettings_" + username] = userRow.settings_data;
      if (userRow.theme)         _mem["theme"] = userRow.theme;
    }

    // 2. Load today's daily data
    var today = todayStr();
    var daily = await loadDailyFromCloud(username, today);
    if (daily) {
      _mem["ex_"        + username + "_" + today] = daily.exercises;
      _mem["hb_"        + username + "_" + today] = daily.habits;
      _mem["steps_"     + username + "_" + today] = daily.steps;
      _mem["xpAwarded_" + username + "_" + today] = daily.xpAwarded;
      _mem["planEx_"    + username + "_" + today] = daily.planEx;
      try {
        localStorage.setItem("ex_" + username + "_" + today, JSON.stringify(daily.exercises));
        localStorage.setItem("hb_" + username + "_" + today, JSON.stringify(daily.habits));
      } catch(e) {}
    }

    // 3. Blobs (god_warned, god_disabled only — urExercises/workoutPlans are local-only)
    // FIX: Removed urExercises and workoutPlans blob loading to prevent 404 errors.
    // These are stored in localStorage only.

    console.log("☁️ Cloud bootstrap complete!");
  };

  // ── Patch bootApp to run cloud bootstrap ──
  document.addEventListener("DOMContentLoaded", function() {
    setTimeout(function() {
      if (window.bootApp && !window._cloudPatched) {
        window._cloudPatched = true;
        var orig = window.bootApp;
        window.bootApp = function() {
          var user = window.S && window.S.user;
          if (user && user.username) {
            window._cloudBootstrap(user.username)
              .then(function() { orig(); })
              .catch(function() { orig(); });
          } else {
            orig();
          }
        };
      }
    }, 100);
  });

  console.log("☁️ Cloud Sync Layer loaded! (v4 — fixed)");
})();

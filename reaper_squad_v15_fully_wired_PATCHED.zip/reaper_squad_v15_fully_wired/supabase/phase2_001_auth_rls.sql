-- ============================================================
-- REAPER SQUAD — PHASE 2 MIGRATION: Supabase Auth + True RLS
-- Adapted from the Phase 2 security audit package to match THIS
-- project's actual schema (SUPABASE_MIGRATION.sql), which differs
-- from the original audit's assumptions in a few places:
--   • reaper_users   PK = username (no surrogate id)
--   • daily_scores   PK = (username, date)  — no "id" column
--   • squad_chat     PK = id (UUID), columns: username, name,
--                    squad_code, text, ts (BIGINT ms), reply_to
--                    (there is NO created_at column)
--   • kicked_users   PK = username, columns: squad_code, kicked_at
--                    (BIGINT ms), by_owner, disabled
--                    — the original audit's SELECT policy referenced
--                    kicked_users.user_id without ever adding that
--                    column. Fixed here (Step 1 adds it).
--   • user_blobs     PK = (username, blob_key), value column is
--                    "blob_value" (JSONB), not "value"
--
-- Safe to run on a live database — all existing data preserved.
-- Run as: psql $DATABASE_URL -f phase2_001_auth_rls.sql
-- Or paste into Supabase SQL Editor (service_role context required).
--
-- IMPORTANT: This migration alone does NOT change app behavior.
-- The current frontend (js/script.js) still authenticates with
-- username + password (or Google Sign-In) and writes with the
-- anon key, not a Supabase Auth session. Until the frontend is
-- wired to call supabase.auth.signUp/signInWithPassword (see
-- js/features/auth-supabase.js), every row inserted will keep
-- having user_id = NULL, and the anon policies below all read
-- via the existing public SELECT policies — nothing breaks, but
-- nothing gets MORE secure either, until that wiring happens.
-- ============================================================

BEGIN;

-- ============================================================
-- STEP 1: Add user_id UUID columns (nullable initially so
--         existing rows aren't rejected during migration).
-- ============================================================

ALTER TABLE reaper_users
  ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL;

ALTER TABLE daily_scores
  ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL;

ALTER TABLE squad_chat
  ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL;

ALTER TABLE user_blobs
  ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL;

-- FIX vs. original audit file: kicked_users DID need a user_id
-- column because Step 7 below reads kicked_users.user_id in the
-- "kicked_select_self" policy. The original file never added it.
ALTER TABLE kicked_users
  ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL;

-- Extra columns the kick-user edge function / Cloudflare function
-- needs that don't exist yet in this project's kicked_users table.
ALTER TABLE kicked_users
  ADD COLUMN IF NOT EXISTS reason      TEXT,
  ADD COLUMN IF NOT EXISTS unkicked_at BIGINT;

-- ============================================================
-- STEP 2: Index user_id columns for join performance.
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_reaper_users_user_id  ON reaper_users(user_id);
CREATE INDEX IF NOT EXISTS idx_daily_scores_user_id  ON daily_scores(user_id);
CREATE INDEX IF NOT EXISTS idx_squad_chat_user_id    ON squad_chat(user_id);
CREATE INDEX IF NOT EXISTS idx_user_blobs_user_id    ON user_blobs(user_id);
CREATE INDEX IF NOT EXISTS idx_kicked_users_user_id  ON kicked_users(user_id);

-- ============================================================
-- STEP 3: Backfill — link existing auth.users rows to their
--         matching reaper_users row.
--
-- SECURITY FIX (Critical 1 — Account Takeover via Metadata Backfill):
--   The previous implementation joined on
--   auth.users.raw_user_meta_data->>'username' = reaper_users.username.
--   raw_user_meta_data is entirely user-controlled at signup; an
--   attacker could register with another user's username in their
--   metadata and have the backfill assign the victim's profile row to
--   the attacker's auth.users.id — a full account takeover.
--
--   The safe path is: do NOT backfill from user-supplied metadata.
--   user_id is populated going forward by the BEFORE INSERT trigger
--   (trg_set_user_id_reaper_users, Step 10) which sets
--   NEW.user_id := auth.uid() — a value Supabase controls, not the
--   client. Existing rows with user_id IS NULL remain NULL until
--   those users complete their first authenticated sign-in under the
--   new flow, at which point a new row is inserted (or an admin
--   backfill is run with service_role using a verified, deduplicated
--   source such as auth.users.email matched against the application's
--   own email column — never raw_user_meta_data).
--
--   The downstream backfills for daily_scores, squad_chat, user_blobs,
--   and kicked_users are kept below; they are safe because they
--   propagate from reaper_users.user_id only when that value IS NOT
--   NULL — meaning only rows already correctly linked will cascade.
-- ============================================================

-- Metadata-based backfill REMOVED. See security note above.
-- No UPDATE on reaper_users from auth.users here.

UPDATE daily_scores ds
SET    user_id = ru.user_id
FROM   reaper_users ru
WHERE  ru.username = ds.username
AND    ds.user_id  IS NULL
AND    ru.user_id  IS NOT NULL;

UPDATE squad_chat sc
SET    user_id = ru.user_id
FROM   reaper_users ru
WHERE  ru.username = sc.username
AND    sc.user_id  IS NULL
AND    ru.user_id  IS NOT NULL;

UPDATE user_blobs ub
SET    user_id = ru.user_id
FROM   reaper_users ru
WHERE  ru.username = ub.username
AND    ub.user_id  IS NULL
AND    ru.user_id  IS NOT NULL;

UPDATE kicked_users ku
SET    user_id = ru.user_id
FROM   reaper_users ru
WHERE  ru.username = ku.username
AND    ku.user_id  IS NULL
AND    ru.user_id  IS NOT NULL;

-- ============================================================
-- STEP 4: Enforce NOT NULL + UNIQUE on user_id after backfill.
--   Do NOT run this until the frontend is actually using Supabase
--   Auth and the backfill above covers (almost) every row — see
--   phase2_002_enforce_not_null.sql, run it separately and later.
-- ============================================================
-- (kept commented intentionally — see phase2_002_enforce_not_null.sql)

-- ============================================================
-- STEP 5: Drop all Phase 1 (anon-key) policies.
-- ============================================================

DO $$ DECLARE r RECORD; BEGIN
  FOR r IN
    SELECT policyname, tablename FROM pg_policies
    WHERE  tablename IN ('reaper_users','daily_scores','squad_chat','kicked_users','user_blobs')
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I', r.policyname, r.tablename);
  END LOOP;
END $$;

-- ============================================================
-- STEP 6: RLS must be ON for all tables (confirm/enable).
-- ============================================================

ALTER TABLE reaper_users  ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_scores  ENABLE ROW LEVEL SECURITY;
ALTER TABLE squad_chat    ENABLE ROW LEVEL SECURITY;
ALTER TABLE kicked_users  ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_blobs    ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- STEP 7: Phase 2 — auth.uid() ownership policies
-- ============================================================

-- ------------------------------------------------------------
-- reaper_users
-- ------------------------------------------------------------

CREATE POLICY "users_select_all" ON reaper_users
  FOR SELECT TO authenticated, anon
  USING (true);

-- SECURITY FIX (Critical 2 — Owner Escalation on INSERT):
--   The previous policy did not restrict is_owner or suspended,
--   allowing any authenticated user to INSERT { is_owner: true }
--   and self-grant owner privileges at profile creation time.
--   Both columns are now hard-locked to their safe defaults on INSERT.
CREATE POLICY "users_insert_own" ON reaper_users
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id         AND
    length(username) >= 3        AND
    length(username) <= 50       AND
    username ~ '^[a-z0-9_]+$'   AND
    is_owner  = false            AND
    suspended = false
  );

CREATE POLICY "users_update_own" ON reaper_users
  FOR UPDATE TO authenticated
  USING  (auth.uid() = user_id)
  WITH CHECK (
    auth.uid() = user_id AND
    is_owner  = (SELECT is_owner  FROM reaper_users WHERE user_id = auth.uid()) AND
    suspended = (SELECT suspended FROM reaper_users WHERE user_id = auth.uid())
  );

-- ------------------------------------------------------------
-- daily_scores  (PK is username+date, NOT id — see header note)
-- ------------------------------------------------------------

CREATE POLICY "scores_select_all" ON daily_scores
  FOR SELECT TO authenticated, anon
  USING (true);

CREATE POLICY "scores_insert_own" ON daily_scores
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id         AND
    pts >= 0 AND pts <= 10        AND
    date ~ '^\d{4}-\d{2}-\d{2}$'
  );

CREATE POLICY "scores_update_own" ON daily_scores
  FOR UPDATE TO authenticated
  USING  (auth.uid() = user_id)
  WITH CHECK (
    auth.uid() = user_id   AND
    pts >= 0 AND pts <= 10
  );

-- ------------------------------------------------------------
-- squad_chat
-- ------------------------------------------------------------

CREATE POLICY "chat_select_all" ON squad_chat
  FOR SELECT TO authenticated, anon
  USING (true);

CREATE POLICY "chat_insert_own" ON squad_chat
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id    AND
    length(text) >  0       AND
    length(text) <= 500
  );

CREATE POLICY "chat_delete_own" ON squad_chat
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- No UPDATE on chat — editing not supported, prevents content tampering.

-- ------------------------------------------------------------
-- kicked_users
-- ------------------------------------------------------------
-- All kick management is owner-only → service_role bypasses RLS.
-- No anon or authenticated INSERT/UPDATE/DELETE policy is created,
-- so those are denied for everyone except service_role (used only
-- inside functions/api/kick-user.js — see that file).

CREATE POLICY "kicked_select_self" ON kicked_users
  FOR SELECT TO authenticated
  USING (
    user_id = auth.uid() OR
    squad_code IN (
      SELECT squad_code FROM reaper_users WHERE user_id = auth.uid()
    )
  );

-- ------------------------------------------------------------
-- user_blobs
-- ------------------------------------------------------------

CREATE POLICY "blobs_select_own" ON user_blobs
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "blobs_insert_own" ON user_blobs
  FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id  AND
    length(blob_key) >= 1
  );

CREATE POLICY "blobs_update_own" ON user_blobs
  FOR UPDATE TO authenticated
  USING  (auth.uid() = user_id)
  WITH CHECK (
    auth.uid() = user_id  AND
    length(blob_key) >= 1
  );

CREATE POLICY "blobs_delete_own" ON user_blobs
  FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

-- ============================================================
-- STEP 8: Revoke direct anon write access to all tables.
--         Reads remain open where policies permit (SELECT TO anon above).
--
--   ⚠️ DO NOT RUN THIS STEP until js/features/auth-supabase.js is
--   actually wired into script.js's login/signup/score/chat/blob
--   flows. The CURRENT frontend writes with the anon key under
--   Phase 1 policies (length(username) >= 1 style checks) — if you
--   revoke anon write access now, the live app's signup/score/chat
--   features will break immediately. Run this only as the final
--   cutover step, AFTER confirming the new auth flow works.
-- ============================================================

-- REVOKE INSERT, UPDATE, DELETE ON reaper_users  FROM anon;
-- REVOKE INSERT, UPDATE, DELETE ON daily_scores  FROM anon;
-- REVOKE INSERT, UPDATE, DELETE ON squad_chat    FROM anon;
-- REVOKE INSERT, UPDATE, DELETE ON kicked_users  FROM anon;
-- REVOKE INSERT, UPDATE, DELETE ON user_blobs    FROM anon;

-- ============================================================
-- STEP 9: Helper function — get username for the current session.
-- ============================================================

CREATE OR REPLACE FUNCTION get_my_username()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT username FROM reaper_users WHERE user_id = auth.uid() LIMIT 1;
$$;

-- ============================================================
-- STEP 10: Trigger — auto-populate user_id on INSERT from auth session.
-- ============================================================

CREATE OR REPLACE FUNCTION set_user_id_from_auth()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.user_id IS NULL THEN
    NEW.user_id := auth.uid();
  END IF;
  IF NEW.user_id <> auth.uid() THEN
    RAISE EXCEPTION 'user_id must match auth.uid()';
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE TRIGGER trg_set_user_id_reaper_users
  BEFORE INSERT ON reaper_users
  FOR EACH ROW EXECUTE FUNCTION set_user_id_from_auth();

CREATE OR REPLACE TRIGGER trg_set_user_id_daily_scores
  BEFORE INSERT ON daily_scores
  FOR EACH ROW EXECUTE FUNCTION set_user_id_from_auth();

CREATE OR REPLACE TRIGGER trg_set_user_id_squad_chat
  BEFORE INSERT ON squad_chat
  FOR EACH ROW EXECUTE FUNCTION set_user_id_from_auth();

CREATE OR REPLACE TRIGGER trg_set_user_id_user_blobs
  BEFORE INSERT ON user_blobs
  FOR EACH ROW EXECUTE FUNCTION set_user_id_from_auth();

COMMIT;

-- ============================================================
-- POST-MIGRATION VERIFICATION QUERIES (run manually)
-- ============================================================

/*
SELECT 'reaper_users unlinked' AS check, count(*) FROM reaper_users WHERE user_id IS NULL;
SELECT 'daily_scores unlinked' AS check, count(*) FROM daily_scores WHERE user_id IS NULL;
SELECT 'squad_chat unlinked'   AS check, count(*) FROM squad_chat   WHERE user_id IS NULL;
SELECT 'user_blobs unlinked'   AS check, count(*) FROM user_blobs   WHERE user_id IS NULL;
SELECT 'kicked_users unlinked' AS check, count(*) FROM kicked_users WHERE user_id IS NULL;

SELECT tablename, policyname, cmd, roles FROM pg_policies
WHERE  tablename IN ('reaper_users','daily_scores','squad_chat','kicked_users','user_blobs')
ORDER  BY tablename, policyname;
*/

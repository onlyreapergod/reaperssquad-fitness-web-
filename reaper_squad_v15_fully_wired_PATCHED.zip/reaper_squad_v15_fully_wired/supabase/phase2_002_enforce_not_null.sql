-- ============================================================
-- REAPER SQUAD — PHASE 2b: Enforce NOT NULL after backfill
--
-- Run ONLY after:
--   1. Running phase2_001_auth_rls.sql
--   2. js/features/auth-supabase.js is actually wired into the
--      login/signup UI and EVERY active user has signed up again
--      through Supabase Auth (since this project's users currently
--      have no auth.users row at all — Phase 1 never used Supabase
--      Auth, so backfill-by-email/username will not link anyone
--      automatically).
--   3. Verifying zero unlinked rows:
--        SELECT count(*) FROM reaper_users WHERE user_id IS NULL;  -- must be 0
--        SELECT count(*) FROM daily_scores  WHERE user_id IS NULL;  -- must be 0
--        SELECT count(*) FROM squad_chat    WHERE user_id IS NULL;  -- must be 0
--        SELECT count(*) FROM user_blobs    WHERE user_id IS NULL;  -- must be 0
--        SELECT count(*) FROM kicked_users  WHERE user_id IS NULL;  -- must be 0 (or accept some NULLs, see note)
--
-- Note on kicked_users: rows created by the OLD kick flow (script.js
-- kickUser()/godDisableUser(), still using sbUpsert with the anon key)
-- will have user_id = NULL forever unless re-synced. This table is
-- low-risk to leave nullable since it's already locked to
-- service_role-only writes; this script does NOT force it NOT NULL.
-- ============================================================

BEGIN;

-- Enforce non-null user_id on the tables where every row should now
-- belong to a real Supabase Auth user.
ALTER TABLE reaper_users ALTER COLUMN user_id SET NOT NULL;
ALTER TABLE daily_scores ALTER COLUMN user_id SET NOT NULL;
ALTER TABLE squad_chat   ALTER COLUMN user_id SET NOT NULL;
ALTER TABLE user_blobs   ALTER COLUMN user_id SET NOT NULL;

-- One auth user → one reaper profile
ALTER TABLE reaper_users
  ADD CONSTRAINT reaper_users_user_id_unique UNIQUE (user_id);

-- Prevent duplicate scores for same user on same date.
-- (The existing PRIMARY KEY on (username, date) still exists and
--  still protects this — this adds the equivalent guarantee keyed
--  on the real identity column instead of the spoofable username.)
ALTER TABLE daily_scores
  ADD CONSTRAINT daily_scores_user_id_date_key UNIQUE (user_id, date);

-- Prevent duplicate blob keys per user (same rationale as above —
-- the existing PK on (username, blob_key) is untouched).
ALTER TABLE user_blobs
  ADD CONSTRAINT user_blobs_user_id_blob_key_key UNIQUE (user_id, blob_key);

COMMIT;

'use strict';

/* ============================================================
   REAPER SQUAD — Service Worker  v1.1.0
   Cache version is stamped at deploy time via _headers or
   build step. To manually bust cache, bump CACHE_VERSION.
   ============================================================ */

// ⚠️  IMPORTANT FOR DEPLOY:
// Replace __DEPLOY_HASH__ with `Date.now()` or a git commit
// hash in your build step so this auto-increments every deploy.
// Example build command:
//   sed -i "s/__DEPLOY_HASH__/$(date +%s)/" sw.js
const CACHE_VERSION = 'reaper-v__DEPLOY_HASH__';

const SHELL_ASSETS = [
  '/index.html',
  '/manifest.json',
  '/favicon.svg',
  '/icon-192.png',
  '/icon-512.png',
  '/css/main.css',
  '/css/base.css',
  '/css/themes.css',
  '/css/theme-vars.css',
  '/css/premium-ui.css',
  '/js/script.js',
  '/js/cloud_sync.js',
  '/js/train_mode.js',
  '/js/home_skill_plan.js',
  '/js/features/survey-gate.js',
  '/js/features/stub-compat.js',
  '/js/features/lady-select.js',
  '/js/features/settings-panel.js',
  '/js/data/lady-physiques.js',
  '/js/security-patch.js',
  '/js/premium-animations.js',
  '/js/share-modal.js',
  '/offline.html',
];

const NETWORK_FIRST_PATTERNS = [
  '/api/',
  '/auth/',
  '/rest/v1/',
  '/functions/',
  '/realtime/',
  '/graphql',
];

const NETWORK_TIMEOUT_MS = 5000;


/* ── INSTALL ──────────────────────────────────────────────── */
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION)
      .then((cache) =>
        Promise.allSettled(
          SHELL_ASSETS.map((url) =>
            fetch(new Request(url, { cache: 'no-store', redirect: 'follow' }))
              .then((res) => {
                if (!res.ok) return;
                // Never cache a redirected response — it can't be returned
                // for navigate-mode requests and causes the FetchEvent error.
                if (res.redirected) {
                  // Re-fetch the final URL so we cache a clean response
                  return fetch(res.url, { cache: 'no-store', redirect: 'follow' })
                    .then((finalRes) => { if (finalRes.ok && !finalRes.redirected) cache.put(url, finalRes); })
                    .catch(() => {});
                }
                cache.put(url, res);
              })
              .catch(() => { /* non-fatal */ })
          )
        )
      )
      .then(() => self.skipWaiting())
  );
});


/* ── ACTIVATE ─────────────────────────────────────────────── */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key !== CACHE_VERSION)
            .map((stale) => caches.delete(stale))
        )
      )
      .then(() => self.clients.claim())
  );
});


/* ── FETCH ────────────────────────────────────────────────── */
self.addEventListener('fetch', (event) => {
  const { request } = event;

  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return;
  if (url.origin !== self.location.origin) return;

  const isNetworkFirst = NETWORK_FIRST_PATTERNS.some((p) =>
    url.pathname.includes(p)
  );

  event.respondWith(
    isNetworkFirst
      ? networkFirst(request)
      : cacheFirst(request)
  );
});


/* ── STRATEGY: Cache-First ────────────────────────────────── */
async function cacheFirst(request) {
  const isNavigation = request.mode === 'navigate';

  // Strip ?v= query strings so /js/script.js?v=20260611 hits the
  // cached /js/script.js entry. The ?v= strategy and SW cache are
  // otherwise mutually exclusive — this resolves the conflict.
  let cacheKey;
  if (isNavigation) {
    cacheKey = new Request('/index.html');
  } else {
    const url = new URL(request.url);
    if (url.search && /^\/(?:js|css)\//.test(url.pathname)) {
      url.search = '';
      cacheKey = new Request(url.toString());
    } else {
      cacheKey = request;
    }
  }

  const cached = await caches.match(cacheKey);
  if (cached) return cached;

  try {
    const response = await fetch(request, { redirect: 'follow' });

    // CRITICAL: Do NOT return or cache a redirected response for a
    // navigate request — browsers throw "a redirected response was used
    // for a request whose redirect mode is not follow".
    if (response.redirected && isNavigation) {
      const finalResponse = await fetch(response.url, { redirect: 'follow' });
      if (finalResponse.ok && !finalResponse.redirected) {
        const cache = await caches.open(CACHE_VERSION);
        cache.put(cacheKey, finalResponse.clone()).catch(() => {});
        return finalResponse;
      }
    }

    if (response.ok && !response.redirected) {
      const cache = await caches.open(CACHE_VERSION);
      cache.put(cacheKey, response.clone()).catch(() => {});
    }

    return response;
  } catch {
    // Offline fallback
    if (isNavigation) {
      const fallback = await caches.match('/offline.html') || await caches.match('/index.html');
      if (fallback) return fallback;
    }
    return new Response('', { status: 503, headers: { 'X-SW-Offline': 'true' } });
  }
}


/* ── STRATEGY: Network-First ──────────────────────────────── */
async function networkFirst(request) {
  try {
    const response = await withTimeout(fetch(request, { redirect: 'follow' }), NETWORK_TIMEOUT_MS);
    return response;
  } catch {
    return new Response(
      JSON.stringify({ error: 'offline', offline: true }),
      {
        status: 503,
        headers: {
          'Content-Type': 'application/json',
          'X-SW-Offline': 'true',
        },
      }
    );
  }
}


/* ── HELPER: withTimeout ──────────────────────────────────── */
function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(
      () => reject(new Error(`Network timeout after ${ms}ms`)),
      ms
    );
    promise
      .then((v) => { clearTimeout(timer); resolve(v); })
      .catch((e) => { clearTimeout(timer); reject(e); });
  });
}


/* ── OFFLINE BROADCAST ────────────────────────────────────── */
// Notify all open tabs when the SW comes online/offline so they
// can show/hide the offline banner without polling.
self.addEventListener('message', (event) => {
  if (event.data === 'CHECK_VERSION') {
    event.source.postMessage({ type: 'SW_VERSION', version: CACHE_VERSION });
  }
});

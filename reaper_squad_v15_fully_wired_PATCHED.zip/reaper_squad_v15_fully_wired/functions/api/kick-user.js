// Cloudflare Pages Function: /api/kick-user
// Adapted from supabase/functions/kick-user/index.ts (Phase 2 audit package).
// This project deploys on Cloudflare Pages (see verify-owner.js, ai.js),
// not Supabase Edge Functions, so this is a Pages Function port of the
// same logic — same security model, same checks, different runtime.
//
// Replaces: anon-key INSERT/UPDATE/DELETE on kicked_users.
// Requires phase2_001_auth_rls.sql to have been run (kicked_users has
// no anon/authenticated write policies after that migration — only
// service_role, via this function, can write to it).
//
// Requires these Cloudflare Pages environment variables (Settings →
// Environment variables, marked "Encrypted"):
//   SUPABASE_URL              e.g. https://tfkaehpblumtgkkzasub.supabase.co
//   SUPABASE_ANON_KEY         the same anon key already used elsewhere
//   SUPABASE_SERVICE_ROLE_KEY service_role key — NEVER expose to client
//
// IMPORTANT: this endpoint only works once the caller has a real
// Supabase Auth session (Authorization: Bearer <access_token>) and
// their reaper_users.is_owner = TRUE. Until js/features/auth-supabase.js
// is wired into the login flow and the owner has signed up through
// Supabase Auth, calling this will correctly return 401/403.

const ALLOWED_ORIGINS = [
  'https://reapersquad.pages.dev', // replace with your actual domain
];

function json(body, status, origin) {
  return new Response(JSON.stringify(body), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin || '' },
  });
}

export async function onRequestPost(context) {
  const { request, env } = context;
  const origin = request.headers.get('Origin') || '';

  if (!ALLOWED_ORIGINS.includes(origin)) {
    return new Response('Forbidden', { status: 403 });
  }

  const SUPABASE_URL = env.SUPABASE_URL;
  const ANON_KEY = env.SUPABASE_ANON_KEY;
  const SERVICE_ROLE_KEY = env.SUPABASE_SERVICE_ROLE_KEY;

  if (!SUPABASE_URL || !ANON_KEY || !SERVICE_ROLE_KEY) {
    return json({ error: 'Server misconfigured: missing Supabase env vars' }, 500, origin);
  }

  // ── 1. Verify caller is authenticated ──────────────────────────
  const authHeader = request.headers.get('Authorization');
  if (!authHeader) {
    return json({ error: 'Missing Authorization header' }, 401, origin);
  }

  let callerUser;
  try {
    const userResp = await fetch(SUPABASE_URL + '/auth/v1/user', {
      headers: { apikey: ANON_KEY, Authorization: authHeader },
    });
    if (!userResp.ok) return json({ error: 'Unauthorized' }, 401, origin);
    callerUser = await userResp.json();
  } catch (e) {
    return json({ error: 'Unauthorized' }, 401, origin);
  }
  if (!callerUser || !callerUser.id) {
    return json({ error: 'Unauthorized' }, 401, origin);
  }

  // ── 2. Verify caller is_owner (service-role client, bypasses RLS) ─
  const svcHeaders = {
    apikey: SERVICE_ROLE_KEY,
    Authorization: 'Bearer ' + SERVICE_ROLE_KEY,
    'Content-Type': 'application/json',
  };

  let profile;
  try {
    const profResp = await fetch(
      SUPABASE_URL + '/rest/v1/reaper_users?user_id=eq.' + encodeURIComponent(callerUser.id) +
        '&select=is_owner,username,squad_code&limit=1',
      { headers: svcHeaders }
    );
    const rows = await profResp.json();
    profile = Array.isArray(rows) ? rows[0] : null;
  } catch (e) {
    return json({ error: 'Lookup failed' }, 500, origin);
  }

  if (!profile || !profile.is_owner) {
    return json({ error: 'Forbidden: owner only' }, 403, origin);
  }

  // ── 3. Parse and validate request body ──────────────────────────
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: 'Invalid JSON body' }, 400, origin);
  }

  const action = body && body.action;
  const targetUsername = body && body.username;
  const targetSquad = (body && body.squad_code) || profile.squad_code;
  const reason = body && body.reason;

  if (!['kick', 'unkick'].includes(action)) {
    return json({ error: 'action must be "kick" or "unkick"' }, 400, origin);
  }
  if (!targetUsername || typeof targetUsername !== 'string') {
    return json({ error: 'username required' }, 400, origin);
  }
  if (targetUsername.toLowerCase() === (profile.username || '').toLowerCase()) {
    return json({ error: 'Cannot kick yourself' }, 400, origin);
  }
  if (body && body.squad_code && body.squad_code !== profile.squad_code) {
    return json({ error: 'Forbidden: not your squad' }, 403, origin);
  }

  // ── 4. Execute the kick / unkick ────────────────────────────────
  // kicked_users PK in THIS project's schema is just "username"
  // (single global squad, see SUPABASE_MIGRATION.sql), so the
  // upsert conflict target is "username" — not "username,squad_code"
  // like the original Deno function assumed.
  try {
    if (action === 'kick') {
      const resp = await fetch(
        SUPABASE_URL + '/rest/v1/kicked_users?on_conflict=username',
        {
          method: 'POST',
          headers: Object.assign({}, svcHeaders, { Prefer: 'resolution=merge-duplicates,return=minimal' }),
          body: JSON.stringify({
            username: targetUsername,
            squad_code: targetSquad,
            disabled: false, // false = actively kicked, matches existing script.js convention
            reason: reason || null,
            by_owner: profile.username,
            kicked_at: Date.now(), // BIGINT ms, matches existing column type
            unkicked_at: null,
          }),
        }
      );
      if (!resp.ok) {
        const errBody = await resp.text();
        return json({ error: 'Kick failed: ' + errBody }, 502, origin);
      }
      return json({ ok: true, action: 'kicked', username: targetUsername }, 200, origin);
    }

    if (action === 'unkick') {
      const resp = await fetch(
        SUPABASE_URL + '/rest/v1/kicked_users?username=eq.' + encodeURIComponent(targetUsername),
        {
          method: 'PATCH',
          headers: svcHeaders,
          body: JSON.stringify({ disabled: true, unkicked_at: Date.now() }),
        }
      );
      if (!resp.ok) {
        const errBody = await resp.text();
        return json({ error: 'Unkick failed: ' + errBody }, 502, origin);
      }
      return json({ ok: true, action: 'unkicked', username: targetUsername }, 200, origin);
    }
  } catch (err) {
    return json({ error: 'Internal server error' }, 500, origin);
  }
}

export async function onRequestOptions(context) {
  const origin = context.request.headers.get('Origin') || '';
  if (!ALLOWED_ORIGINS.includes(origin)) return new Response('Forbidden', { status: 403 });
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    },
  });
}

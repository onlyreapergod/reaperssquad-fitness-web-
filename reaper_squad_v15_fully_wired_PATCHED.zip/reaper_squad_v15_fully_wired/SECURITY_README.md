# 🔐 REAPER SQUAD — Security Fixes Applied

## ⚡ IMMEDIATE ACTION REQUIRED (Do This RIGHT NOW)

### 1. Groq API Key — REVOKE IMMEDIATELY
The old key `gsk_lVoFNKawZD0eyo0uTaFoWGdyb3FY...` was exposed in JS source.

**Steps:**
1. Go to https://console.groq.com → API Keys
2. Find and click **Revoke** on the exposed key
3. Create a new key
4. Either:
   - Set up a Cloudflare Worker proxy (recommended), OR
   - Replace `GROQ_KEY="REVOKED_USE_PROXY"` with new key temporarily

### 2. Supabase RLS — Run Fixed SQL
Run the new `SUPABASE_MIGRATION.sql` in your Supabase SQL Editor.
The old policies allowed ANYONE to read/write ALL data.

### 3. Supabase Allowed Origins
Go to: Supabase Dashboard → Settings → API → Allowed Origins
Add ONLY your production domain (e.g. `https://yourdomain.netlify.app`)

---

## ✅ Fixes Applied in This Build

| # | Issue | Severity | Status |
|---|-------|----------|--------|
| 1 | Groq API key exposed | CRITICAL | ⚠️ Key placeholder — revoke old key |
| 2 | Password synced to Supabase | HIGH | ✅ Removed from all upsert calls |
| 3 | RLS policies open to all | CRITICAL | ✅ Fixed SQL provided |
| 4 | CSP headers missing | MEDIUM | ✅ Added to _headers |
| 5 | Security headers missing | LOW | ✅ Added X-Frame-Options etc |

---

## 🔄 Remaining (Manual Action Needed)

### Owner Authentication Fix (Issue #6)
The owner check is still username-based (`"reaper god"` string match).
To fix properly:
1. Run the SQL to set `is_owner = TRUE` for your account
2. After login, add a Supabase check to verify is_owner

### Password Hashing (Issue #5)
Passwords are still stored as `btoa()` (base64) in localStorage.
- **Short term**: Fine since passwords aren't going to Supabase anymore
- **Long term**: Move to Supabase Auth (`supabase.auth.signUp`)

### localStorage Bypass (Issue #7)
Kicked/banned users can still bypass by clearing localStorage.
- **Fix**: Check kick status from Supabase on every login (already partially done in code)

---

## 📋 Files Changed
- `script.js` — Groq key removed, passwords removed from Supabase upserts
- `_headers` — CSP + security headers added
- `SUPABASE_MIGRATION.sql` — Fixed RLS policies
- `SECURITY_README.md` — This file

---

## 🔐 Phase 2 — Supabase Auth (added, NOT yet activated)

A follow-up security audit package was merged in. It moves data ownership
from "matches a username string" to "matches `auth.uid()` on a real
Supabase Auth session" — see `PHASE2_AUDIT.md` for the full finding-by-finding
breakdown.

**What was added to this repo:**
- `supabase/phase2_001_auth_rls.sql` — adds `user_id` columns + `auth.uid()`-based
  RLS policies to all 5 tables (adapted to this project's actual schema; fixes
  a bug in the original audit file where `kicked_users.user_id` was referenced
  but never created).
- `supabase/phase2_002_enforce_not_null.sql` — tightens `user_id` to `NOT NULL` +
  unique, run only after every active user has re-registered through Supabase
  Auth.
- `functions/api/kick-user.js` — Cloudflare Pages Function (ported from the
  audit's Deno/Supabase-Edge-Function version) that does owner-verified
  kick/unkick using the service-role key server-side only.
- `js/features/auth-supabase.js` — browser helper exposing `window.ReaperAuth`
  (signUp/signIn/signOut/getMyProfile/upsertScore/sendChatMessage/upsertBlob/
  kickUser/...), loaded via CDN `supabase-js`. **This file only sets up the
  client — it does not call any of these functions on its own.**

**What was deliberately NOT done — and why:**
`doLogin()` / `doSignup()` / `kickUser()` in `script.js`, and the login/signup
forms in `index.html`, still use the original username+password (+ optional
Google Sign-In) flow against the anon key. Switching them over to
`window.ReaperAuth` would mean:
1. Adding an email field to the signup form (Supabase Auth requires one;
   none exists today).
2. Every existing user re-registering, since none of them have an
   `auth.users` row yet (Phase 1 never used Supabase Auth).
3. Running `phase2_001_auth_rls.sql`'s Step 8 (`REVOKE ... FROM anon`),
   which would break the *current* signup/score/chat flow the moment it runs,
   until step 2 is complete for the whole squad.

That's a live-breaking, all-or-nothing cutover for every user — not something
to flip silently. The plumbing is in place and tested for syntax; ask for it
explicitly when you're ready to do the actual UI cutover (new login/signup
screen, owner re-registration, then run Step 8).

**Deployment order if/when you do the cutover:**
```
1. Run supabase/phase2_001_auth_rls.sql in the Supabase SQL editor
   (Step 8's REVOKE lines stay commented out for now)
2. Set SUPABASE_SERVICE_ROLE_KEY, SUPABASE_URL, SUPABASE_ANON_KEY as
   encrypted env vars in the Cloudflare Pages dashboard
3. Wire index.html's login/signup forms + script.js's doLogin/doSignup/
   kickUser to window.ReaperAuth (adds an email field)
4. Have the owner + all members re-register through the new flow
5. Verify: SELECT count(*) FROM reaper_users WHERE user_id IS NULL; → 0
6. Run supabase/phase2_002_enforce_not_null.sql
7. Uncomment + run the REVOKE statements in phase2_001_auth_rls.sql Step 8
```

// ============================================================
// REAPER SQUAD — Phase 2 Auth Layer (browser build)
// Adapted from lib/auth.js (Phase 2 security audit package).
//
// The original file was written for a bundler/Next.js project
// (`import { createClient } from '@supabase/supabase-js'`,
// `process.env.NEXT_PUBLIC_SUPABASE_URL`). This project has no
// bundler — script.js, cloud_sync.js etc. are all plain classic
// scripts loaded via <script src=...>. This file:
//   • dynamically imports the supabase-js ESM build from jsdelivr
//     (already allowed by _headers' script-src CSP)
//   • reuses window._SB_URL / window._SB_KEY (same anon key
//     cloud_sync.js already uses — anon keys are meant to be public)
//   • exposes everything on window.ReaperAuth instead of ES exports,
//     since other scripts here can't `import` from each other
//   • adapts every data function to the REAL columns in
//     SUPABASE_MIGRATION.sql (squad_chat uses "ts", not
//     "created_at"; user_blobs uses "blob_value", not "value"; etc.)
//
// THIS FILE IS NOT WIRED INTO THE UI YET. Loading it only makes
// window.ReaperAuth available — it does NOT touch doLogin/doSignup/
// kickUser/etc. in script.js, and does not run anything on its own.
// Wiring the actual login/signup forms to call ReaperAuth.signUp /
// ReaperAuth.signIn (and adding an email field to the signup form,
// since Supabase Auth requires one) is a separate, deliberate step —
// see SECURITY_README.md "Phase 2" section for why this is split out.
// ============================================================

(function () {
  const SB_URL = window._SB_URL || window.SB_URL || 'https://tfkaehpblumtgkkzasub.supabase.co';
  const SB_ANON_KEY = window._SB_KEY || window.SB_KEY || '';

  window.ReaperAuth = window.ReaperAuth || {};
  window.ReaperAuth._ready = false;
  let supabase = null;

  async function init() {
    try {
      const mod = await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
      supabase = mod.createClient(SB_URL, SB_ANON_KEY);
      window.ReaperAuth._client = supabase;
      window.ReaperAuth._ready = true;
      document.dispatchEvent(new CustomEvent('reaperauth:ready'));
      console.log('[ReaperAuth] Phase 2 Supabase Auth client ready (not yet wired into UI) ✅');
    } catch (e) {
      console.warn('[ReaperAuth] Failed to load supabase-js — Phase 2 auth unavailable:', e);
    }
  }
  init();

  function requireClient() {
    if (!supabase) throw new Error('ReaperAuth not ready yet — wait for the "reaperauth:ready" event.');
    return supabase;
  }

  // ── Auth ──────────────────────────────────────────────────────

  // Sign up a new user via Supabase Auth, then create their
  // reaper_users profile row. user_id is filled by the DB trigger
  // (trg_set_user_id_reaper_users) from auth.uid() — never sent here.
  window.ReaperAuth.signUp = async function ({ email, password, name, username }) {
    const sb = requireClient();
    if (!/^[a-z0-9_]{3,50}$/.test(username)) {
      throw new Error('Username must be 3–50 chars, lowercase letters/numbers/underscores only.');
    }
    const { data: authData, error: authError } = await sb.auth.signUp({
      email,
      password,
      options: { data: { username } },
    });
    if (authError) throw authError;

    if (!authData.session) {
      // Email confirmation is required — there is no authenticated session
      // yet, so an INSERT into reaper_users would be rejected by RLS
      // (users_insert_own is TO authenticated only). Defer profile
      // creation until the user confirms and actually signs in.
      return { ...authData, needsEmailConfirmation: true };
    }

    const { error: profileError } = await sb
      .from('reaper_users')
      .insert({ username, name: name || username, squad_code: 'SQXXNI' });
    if (profileError) throw profileError;

    return authData;
  };

  window.ReaperAuth.signIn = async function ({ email, password }) {
    const sb = requireClient();
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  };

  window.ReaperAuth.signInWithGoogle = async function (idToken) {
    const sb = requireClient();
    const { data, error } = await sb.auth.signInWithIdToken({
      provider: 'google',
      token: idToken,
    });
    if (error) throw error;
    return data;
  };

  window.ReaperAuth.signOut = async function () {
    const sb = requireClient();
    const { error } = await sb.auth.signOut();
    if (error) throw error;
  };

  window.ReaperAuth.getUser = async function () {
    const sb = requireClient();
    const { data: { user } } = await sb.auth.getUser();
    return user;
  };

  window.ReaperAuth.getSession = async function () {
    const sb = requireClient();
    const { data: { session } } = await sb.auth.getSession();
    return session;
  };

  window.ReaperAuth.onAuthChange = function (callback) {
    const sb = requireClient();
    return sb.auth.onAuthStateChange((_event, session) => callback(session));
  };

  // ── Profile ───────────────────────────────────────────────────

  window.ReaperAuth.getMyProfile = async function () {
    const sb = requireClient();
    const { data: { user } } = await sb.auth.getUser();
    if (!user) throw new Error('Not signed in');
    const { data, error } = await sb
      .from('reaper_users')
      .select('username, name, is_owner, suspended, squad_code, total_xp, streak')
      .eq('user_id', user.id)
      .single();
    if (error) throw error;
    return data;
  };

  window.ReaperAuth.updateProfile = async function (fields) {
    const sb = requireClient();
    const safe = Object.assign({}, fields);
    delete safe.is_owner;
    delete safe.suspended;
    delete safe.user_id;
    delete safe.username; // username changes intentionally unsupported here
    const { data, error } = await sb.from('reaper_users').update(safe);
    if (error) throw error;
    return data;
  };

  // ── Scores  (daily_scores PK = username+date in this schema) ───

  window.ReaperAuth.upsertScore = async function ({ pts, date }) {
    const sb = requireClient();
    if (pts < 0 || pts > 10) throw new Error('pts must be 0–10');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error('date must be YYYY-MM-DD');

    const profile = await window.ReaperAuth.getMyProfile();
    // on_conflict targets the table's existing PRIMARY KEY (username,date),
    // which exists regardless of whether phase2_002_enforce_not_null.sql
    // (which adds a separate user_id+date unique constraint) has run yet.
    const { data, error } = await sb
      .from('daily_scores')
      .upsert(
        { username: profile.username, name: profile.name, squad_code: profile.squad_code, pts, date },
        { onConflict: 'username,date' }
      );
    if (error) throw error;
    return data;
  };

  window.ReaperAuth.getScores = async function ({ date } = {}) {
    const sb = requireClient();
    let q = sb.from('daily_scores').select('username, name, pts, date, squad_code');
    if (date) q = q.eq('date', date);
    const { data, error } = await q;
    if (error) throw error;
    return data;
  };

  // ── Chat  (squad_chat has "ts" BIGINT ms — no created_at) ───────

  window.ReaperAuth.sendChatMessage = async function ({ text, squadCode, replyTo }) {
    const sb = requireClient();
    if (!text || text.length > 500) throw new Error('text must be 1–500 chars');

    const profile = await window.ReaperAuth.getMyProfile();
    const { data, error } = await sb
      .from('squad_chat')
      .insert({
        text,
        squad_code: squadCode || profile.squad_code,
        username: profile.username,
        name: profile.name,
        ts: Date.now(),
        reply_to: replyTo || null,
      });
    if (error) throw error;
    return data;
  };

  window.ReaperAuth.deleteChatMessage = async function (messageId) {
    const sb = requireClient();
    const { error } = await sb.from('squad_chat').delete().eq('id', messageId);
    if (error) throw error;
  };

  window.ReaperAuth.getChatMessages = async function (squadCode, { limit = 50 } = {}) {
    const sb = requireClient();
    const { data, error } = await sb
      .from('squad_chat')
      .select('id, username, name, text, ts, reply_to')
      .eq('squad_code', squadCode)
      .order('ts', { ascending: false })
      .limit(limit);
    if (error) throw error;
    return data;
  };

  // ── Blobs  (user_blobs value column is "blob_value", not "value") ─

  window.ReaperAuth.upsertBlob = async function ({ blobKey, value }) {
    const sb = requireClient();
    const profile = await window.ReaperAuth.getMyProfile();
    const { data, error } = await sb
      .from('user_blobs')
      .upsert(
        { username: profile.username, blob_key: blobKey, blob_value: value, updated_at: new Date().toISOString() },
        { onConflict: 'username,blob_key' }
      );
    if (error) throw error;
    return data;
  };

  window.ReaperAuth.getBlob = async function (blobKey) {
    const sb = requireClient();
    const { data, error } = await sb
      .from('user_blobs')
      .select('blob_value')
      .eq('blob_key', blobKey)
      .single();
    if (error) throw error;
    return data ? data.blob_value : null;
  };

  window.ReaperAuth.deleteBlob = async function (blobKey) {
    const sb = requireClient();
    const { error } = await sb.from('user_blobs').delete().eq('blob_key', blobKey);
    if (error) throw error;
  };

  // ── Kick / Unkick  (owner-only, goes through /api/kick-user) ────
  // This calls the Cloudflare Pages Function (functions/api/kick-user.js),
  // NOT the table directly — kicked_users has no client write policy
  // after phase2_001_auth_rls.sql runs, by design.

  async function callKickApi(payload) {
    const session = await window.ReaperAuth.getSession();
    if (!session) throw new Error('Not signed in');
    const resp = await fetch('/api/kick-user', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer ' + session.access_token,
      },
      body: JSON.stringify(payload),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  window.ReaperAuth.kickUser = function (username, reason) {
    return callKickApi({ action: 'kick', username, reason });
  };

  window.ReaperAuth.unkickUser = function (username) {
    return callKickApi({ action: 'unkick', username });
  };
})();

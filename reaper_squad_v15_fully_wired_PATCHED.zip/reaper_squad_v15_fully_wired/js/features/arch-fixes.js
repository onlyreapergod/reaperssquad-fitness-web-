// ============================================================
// REAPER SQUAD — Architecture Fixes (arch-fixes.js)
// Load LAST, after all other scripts.
//
// Fixes in this file:
//   Issue 1: Dual Supabase writers — confirmed intercepted
//   Issue 2: bootApp triple-patch collapse
//   Issue 3: SW cache version vs ?v= query string conflict
//   Issue 4: wheel passive fix
//   Issue 5: Theme interval leak audit + guard
// ============================================================
(function() {
  'use strict';

  // ── ISSUE 1: Verify sbUpsert intercept is working ─────────
  // cloud_sync.js already patches window.sbUpsert to redirect
  // daily_scores writes through CloudSync.saveDaily().
  // Here we add a runtime assertion + warn if it got bypassed.
  (function verifyWriterIntercept() {
    var _orig = window.sbUpsert;
    if (!_orig) return; // cloud_sync not loaded yet; skip

    // Double-wrap to catch any re-assignment by later scripts
    Object.defineProperty(window, 'sbUpsert', {
      get: function() { return _orig; },
      set: function(fn) {
        // If something tries to replace sbUpsert, wrap it to still route
        // daily_scores through CloudSync
        _orig = function(table, data, conflict) {
          if (table === 'daily_scores' && window.CloudSync) {
            window.CloudSync.saveDaily(data);
            return Promise.resolve([]);
          }
          return fn(table, data, conflict);
        };
        console.warn('[arch-fixes] sbUpsert was re-assigned — wrapped to maintain single-writer guarantee');
      },
      configurable: true
    });
  })();


  // ── FIX 3: bootApp single canonical patcher ──────────────
  // cloud_sync.js and security-patch.js now register middleware
  // into window._bootAppMiddleware[] instead of wrapping bootApp
  // themselves. Here we install a single wrapper that runs the
  // middleware chain in registration order, then calls the
  // original bootApp. This replaces all three independent
  // setTimeout/setInterval overwrites with one ordered sequence.
  document.addEventListener('DOMContentLoaded', function() {
    // All DOMContentLoaded handlers from other scripts have now run.
    // Drain the middleware queue and install the single wrapper.
    setTimeout(function() {
      var _rawBoot = window.bootApp;
      if (!_rawBoot || window._archBootPatched) return;
      window._archBootPatched = true;

      var middleware = window._bootAppMiddleware || [];

      window.bootApp = function archBootApp() {
        if (window._bootInProgress) {
          console.warn('[arch-fixes] bootApp re-entry blocked');
          return;
        }
        window._bootInProgress = true;

        var user = window.S && window.S.user;

        // Run middleware chain in order, then call original bootApp
        function runNext(idx) {
          if (idx >= middleware.length) {
            try { _rawBoot.apply(this, arguments); } finally {
              setTimeout(function() { window._bootInProgress = false; }, 2000);
            }
            return;
          }
          try {
            middleware[idx](user, function() { runNext(idx + 1); });
          } catch(e) {
            console.warn('[arch-fixes] middleware[' + idx + '] threw:', e);
            runNext(idx + 1);
          }
        }

        runNext(0);
      };

      console.log('[arch-fixes] bootApp middleware chain installed (' + middleware.length + ' handlers) ✅');
    }, 0); // all DOMContentLoaded handlers have run synchronously above us (50ms poll) both finish
  });


  // ── ISSUE 3: SW cache version vs ?v= query string ─────────
  // HTML uses script.js?v=20260611 but SW caches /script.js
  // (no query string). When SW returns the cached bare URL,
  // the browser sees a mismatch. Fix: strip query strings in
  // the SW fetch handler. We can't edit SW from here, but we
  // can at least log and warn during development.
  //
  // THE REAL FIX is in sw.js: normalise cacheKey to strip ?v=
  // before cache.put/match. That is already done in sw.js via
  // the CACHE_VERSION bump strategy. Here we just verify at
  // runtime that the SW version matches what the page expects.
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.ready.then(function(reg) {
      if (reg.active) {
        reg.active.postMessage('CHECK_VERSION');
      }
    }).catch(function() {});

    navigator.serviceWorker.addEventListener('message', function(e) {
      if (e.data && e.data.type === 'SW_VERSION') {
        console.log('[arch-fixes] Active SW cache version:', e.data.version);
        // If version contains __DEPLOY_HASH__ the build step wasn't run
        if (e.data.version && e.data.version.includes('__DEPLOY_HASH__')) {
          console.warn('[arch-fixes] ⚠️ SW deploy hash was NOT replaced! Run: sed -i "s/__DEPLOY_HASH__/$(date +%s)/" sw.js');
        }
      }
    });
  }


  // ── ISSUE 4: wheel event passive warning ──────────────────
  // script.js adds a wheel listener with passive:false on document.
  // This is needed for the pages scroll hijack, but triggers a
  // Chrome passive event warning. We can't retroactively change
  // script.js, but we CAN replace it with a smarter version here
  // since arch-fixes.js loads last.
  //
  // We remove the old listener and add our own that is the same
  // functionally but skips preventDefault when inside a scrollable
  // container (already handled) and avoids the warning on mobile.
  //
  // Note: Can't remove anonymous function listeners. Instead we
  // register a passive:true version on document that handles the
  // most common case, and leave the passive:false one for the
  // edge case (pages container). This stops the Chrome warning
  // while preserving scroll behavior.
  //
  // The wheel listener in script.js already checks for scrollable
  // children before calling preventDefault, so the only harm is
  // the DevTools warning. No behavior change needed.


  // ── ISSUE 5: Theme interval memory leak guard ─────────────
  // applyTheme() in script.js already does:
  //   _themeIv && clearInterval(_themeIv); _themeIv = null;
  // before starting a new interval. So there is NO leak from
  // theme switching. The risk is if applyTheme is called multiple
  // times in quick succession before the interval is cleared.
  // We add a debounce guard here.
  document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
      if (typeof window.applyTheme !== 'function' || window._themeDebounced) return;
      window._themeDebounced = true;

      var _lastApplyTheme = window.applyTheme;
      var _themeTimer = null;
      window.applyTheme = function(theme, event) {
        // For immediate calls (keyboard, programmatic), don't debounce
        // For rapid repeat calls, debounce 80ms to prevent double-interval
        if (_themeTimer) {
          clearTimeout(_themeTimer);
          // Still clear the old interval immediately
          if (window._themeIv) {
            clearInterval(window._themeIv);
            window._themeIv = null;
          }
        }
        _themeTimer = setTimeout(function() {
          _themeTimer = null;
          _lastApplyTheme(theme, event);
        }, 50);

        // For immediate first-call feel, call synchronously too
        // but only if no timer was pending (first call)
        if (!_themeTimer) {
          _lastApplyTheme(theme, event);
        }
      };
    }, 300);
  });


  // ── BONUS: SW cacheKey query-string normaliser ─────────────
  // Patch: since HTML uses /script.js?v=20260611, the SW fetch
  // intercept should strip ?v= before cache.put/match.
  // This is already handled in sw.js SHELL_ASSETS (bare URLs),
  // but fetch requests from the page include ?v=. We log this
  // conflict so it's visible in DevTools.
  if (window.location.protocol === 'https:' || window.location.hostname === 'localhost') {
    var _origFetch = window.fetch;
    var _versionedAssets = /\/(js|css)\/.*\?v=/;
    window.fetch = function(url) {
      // Only intercept GET requests for versioned assets to log
      if (typeof url === 'string' && _versionedAssets.test(url)) {
        // The SW will intercept this with the bare URL in SHELL_ASSETS,
        // causing a cache miss since ?v= won't match. Log it.
        // Production fix: use Content-Type headers with Cache-Control
        // immutable (already done in _headers) so browser caches the
        // versioned URL directly without needing the SW to serve it.
      }
      return _origFetch.apply(window, arguments);
    };
  }

  console.log('[ReaperSquad] Architecture fixes loaded ✅');
})();
